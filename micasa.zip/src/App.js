import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import SignUp from "./Components/SignUp";
import "./App.css";
import Propertilisting from "./Components/Propertilisting";
import Preinscription from "./Components/Preinscription";
import Listingdocs from "./Components/Listingdocs";
import PartnerFirms from "./Components/PartnerFirms";
import Escrow from "./Components/Escrow";
import SignIn from "./Components/SignIn";
import Postinspection from "./Components/Postinspection";
import Appraisalloan from "./Components/Appraisalloan";
import FinishLine from "./Components/FinishLine";
import Offertable from "./Components/Offertable";
import Test from "./Components/Test";
import Document from "./Components/createoffer/Document";
import AgentInformation from "./Components/createoffer/AgentInformation";
import PurchasePrice from "./Components/createoffer/PurchasePrice";
import Contingencies from "./Components/createoffer/Contingencies";
import FinalReview from "./Components/createoffer/FinalReview";
import MessagetoAgent from "./Components/createoffer/MessagetoAgent";
// import Pp from './Components/createoffer/Pp'
import BuyerHome from "./Components/BuyerHome";
import Offerpage from "./Components/Offerpage";
import Home from "./Components/Home";
// import Test2 from "./Components/Test2";

const App = () => {
  return (
    <>
      {/* <SignUp /> */}

      <BrowserRouter>
        <Routes>
          <Route path="/Propertilisting" element={<Propertilisting />} />
          <Route path="/preinscription" element={<Preinscription />} />
          <Route path="/listingdocs" element={<Listingdocs />} />
          <Route path="/partnerFirms" element={<PartnerFirms />} />
          <Route path="/escrow" element={<Escrow />} />
          <Route path="/" element={<SignUp />} />
          <Route path="/login" element={<SignIn />} />
          <Route path="/postinspections" element={<Postinspection />} />
          <Route path="/appraisalloan" element={<Appraisalloan />} />
          <Route path="/finishline" element={<FinishLine />} />
          <Route path="/purchaseprice" element={<PurchasePrice />} />
          <Route path="/finalreview" element={<FinalReview />} />
          <Route path="/Contingencies" element={<Contingencies />} />
          <Route path="/offertable" element={<Offertable />} />
          <Route path="/test" element={<Test />} />
          {/* <Route path="/test2" element={<Test2 />} /> */}

          <Route path="/buyerhome" element={<BuyerHome />} />
          <Route path="/agentinformation" element={<AgentInformation />} />
          <Route path="/document" element={<Document />} />
          <Route path="/messagetoagent" element={<MessagetoAgent />} />
          <Route path="/Offertable" element={<Offertable />} />
          <Route path="/test" element={<Test />} />
          <Route path="/Offerpage/:id" element={<Offerpage />} />
          <Route path="/home" element={<Home />} />
        </Routes>
      </BrowserRouter>
    </>
  );
};

export default App;
