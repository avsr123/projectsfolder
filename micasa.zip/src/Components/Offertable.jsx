import React, { useState, useEffect } from "react";
import Header from "./Header";
import Slider from "react-slick";

import Sidebar from "./Sidebar";
import axios from "axios";
import "./custom-slider-styles.css";
import { useNavigate } from "react-router-dom";

const Offertable = () => {
  const carouselSettings = {
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    centerMode: true,
    dots: true,
    speed: 500,
    autoplay: true,
    autoplaySpeed: 3000,
    // appendDots: (dots) => <ul style={{ bottom: "10px" }}>{dots}</ul>,
    rtl: true, // Add this line to enable right-to-left mode
  };
  const navigate = useNavigate();

  const [userdata, setUserdata] = useState([]);

  const handleOffer = () => {
    const accessToken = localStorage.getItem("accessToken");
    const config = {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Token ${accessToken}`,
        Accept: "application/json",
      },
    };

    axios
      .get("http://192.168.0.13:8000/AllOfferApi/", config)
      .then((res) => {
        setUserdata(res.data.data);
        console.log("Response:", res.data);
      })
      .catch((err) => {
        console.error("Error:", err);
      });
  };

  useEffect(() => {
    handleOffer();
  }, []);

  const handelpage = (e) => {
    navigate(`/offerpage/${e}`);
  };

  return (
    <section className="bg-banner-dashborad">
      <Header />
      <div className="bg-main-offers-borad">
        <div className="row mx-0 position-box">
          <div className="col-sm-2 px-0">
            <Sidebar />
          </div>
          <div className="col-sm-10">
            <div className="glass-banner p-4">
              <div className="row mx-0">
                <div className="col-2">
                  <div className="table-head">
                    <ul>
                      <li>Agent Name</li>
                      <li>Email</li>
                      <li>Phone Number</li>
                      <li>License Number</li>
                      <li>Price</li>
                      <li>Initial Deposit</li>
                      <li>Finance Type</li>
                      <li>Loan Amount</li>
                      <li>Percent Down</li>
                      <li>Down Payment</li>
                      <li>Down Payment Balance</li>
                      <li>Finance Contingency</li>
                      <li>Appraisal Contingency</li>
                      <li>Inspection Contingency</li>
                      <li>Home Sale Contingency</li>
                      <li>Close of Escrow</li>
                      <li>Submitted On</li>
                      <li>Special Terms</li>
                    </ul>
                  </div>
                </div>
                <div className="col-10">
                  <Slider {...carouselSettings}>
                    {userdata?.map((val, index) => {
                      return (
                        <div className="col">
                          <div className="multidatabox-data">
                            <ul key={index} onClick={() => handelpage(index)}>
                              <li>Agent Name</li>
                              <li>Email</li>
                              <li>Phone Number</li>
                              <li>License Number</li>
                              <li>Price</li>
                              <li>$40,000</li>
                              <li>Loan</li>
                              <li>{val.initial_deposite}</li>
                              <li>{val.finance_type}</li>
                              <li>{val.loan_amount}</li>
                              <li>Percent Down</li>
                              <li>Down payment</li>
                              <li>Down payment balance</li>
                              <li>{val.no_finance_contingency}</li>
                              <li>{val.appraisal_contingency}</li>
                              <li>{val.no_inspection_contingency}</li>
                              <li>{val.homesale_contingency}</li>
                              <li>{val.days_to_close_of_escrow}</li>
                              {/* <li>Submitted on</li> */}
                              <li>{val.special_terms}</li>
                            </ul>
                          </div>
                        </div>
                      );
                    })}
                  </Slider>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Offertable;
