import React, { useState } from 'react';
import { Container, Row, Col, Form, Card } from 'react-bootstrap';
import axios from 'axios';

const PurchasePrice = () => {
  const [formData, setFormData] = useState({
    purchase_price: '',
    initial_deposit: '',
    finance_type: 'LOAN',
    loan_amount: '',
    property: '1',
  });

  const handleOffer = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://192.168.0.13:8000/PostOfferApi/", formData);
      console.log("Response:", response.data);
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <div className='mx-5'>
      <div className="text-center">
        <h3>Create Offer</h3>
        <h6>PURCHASE PRICE</h6>
        <p>Provide the term for the Purchase Price.</p>
      </div>
      
      {/* <input type="range" className="form-range blue-range" id="customRange" />
      <input type="range" class="form-control-range" id="formControlRange"/> */}

      <form onSubmit={handleOffer}>
        <Row>
        
          <Col sm={6} className="p-5">
         
             <Form.Group>
              <Form.Label>PURCHASE PRICE</Form.Label>
              <div className="input-group mb-3">
                <div className="input-group-prepend">
                  <span className="input-group-text" id="basic-addon1">$</span>
                </div>
                <input
                  type="text"
                  className="form-control1"
                  placeholder="Enter a price"
                  aria-label="Purchase Price"
                  aria-describedby="basic-addon1"
                  onChange={(e) => setFormData({ ...formData, purchase_price: e.target.value })}
                />
              </div>
              
            </Form.Group> 
         


            <Form.Group>
              <Form.Label>INITIAL DEPOSIT</Form.Label>
              <div className="input-group mb-3">
                <div className="input-group-prepend">
                  <span className="input-group-text" id="basic-addon2">$</span>
                </div>
                <input
                  type="text"
                  className="form-control1"
                  placeholder="Enter initial deposit"
                  aria-label="Initial Deposit"
                  aria-describedby="basic-addon2"
                  onChange={(e) => setFormData({ ...formData, initial_deposit: e.target.value })}
                />
              </div>
            </Form.Group>

            <Form.Group>
              <Form.Label>FINANCE TYPE</Form.Label>
              <div className="input-group mb-3">
                <div className="input-group-prepend">
                  <span className="input-group-text" id="basic-addon3">$</span>
                </div>
                <select
                  className="form-control1"
                  onChange={(e) => setFormData({ ...formData, finance_type: e.target.value })}
                >
                  <option value="LOAN">Loan</option>
                  <option value="1"> 1</option>
                  <option value="2"> 2</option>
                </select>
              </div>
            </Form.Group>

            <Form.Group>
              <Form.Label>LOAN AMOUNT</Form.Label>
              <div className="input-group mb-3">
                <div className="input-group-prepend">
                  <span className="input-group-text" id="basic-addon4">$</span>
                </div>
                <input
                  type="text"
                  className="form-control1"
                  placeholder="Enter loan amount"
                  aria-label="Loan Amount"
                  aria-describedby="basic-addon4"
                  onChange={(e) => setFormData({ ...formData, loan_amount: e.target.value })}
                />
              </div>
            </Form.Group>
          </Col>

          <Col sm={6} className="p-5">
            <Card className="bg-light text-black">
              <Card.Body>
                <Card.Title>CALCULATED VALUES</Card.Title>
                <Card.Text>
                  For your reference, these values will be calculated as you enter the required fields.
                </Card.Text>
              <Row>
                <Col sm={6}>
                  <h5>PERCENT DOWN</h5>
                  <h5>% -</h5>
                  <p>BALANCE OF DOWN PAYMENT</p>
                  <h5>$ -</h5>
                </Col>
                <Col sm={6}>
                  <p>DOWN PAYMENT</p>
                  <h5>$ -</h5>
                </Col>
              </Row>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        <div className="d-flex justify-content-between w-50 mx-auto">
          <button className="sign-in" type="button">
            DISCARD & EXIT
          </button>
          <button className="sign-in" type="button">
            BACK
          </button>
          <button className="sign-in" type="submit">
            SAVE & EXIT
          </button>
          <button className="sign-in" type="button">
            Next Page
          </button>
        </div>
      </form>
    </div>
  );
};

export default PurchasePrice;
