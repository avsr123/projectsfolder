import axios from "axios";
import React, { useEffect, useState } from "react";
import { Container, Row, Col, Form, Card } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

const Contingencies = () => {
  const navigation = useNavigate();

  const [formData, setFormData] = useState({
    finance_contingency: "",
    no_finance_contingency: "",
    inspection_contingency: "",
    appraisal_contingency: "",
    homesale_contingency: "",
    days_to_close_of_escrow: "",
    special_terms: "",
    offer_doc: "",
    short_note: "",
  });

  console.log("nikita", formData);

 

  const handeloffer = (e) => {
    e.preventDefault();
    const accessToken = localStorage.getItem("accessToken");
    axios
      .patch(`http://192.168.0.13:8000/UpdateOfferApi/${6}/`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Token ${accessToken}`,
          Accept: "application/json",
        },
      })
      .then((res) => {
        console.log("Response:", res.data);
        navigation("./AgentInformation");
      })
      .catch((err) => {
        console.error("Error:", err);
      });
  };

  return (
    <div>
      <div className='text-center'>
      <h3>Create Offer</h3>
      <h6>CONTINGENCIES</h6>
      <p>Provide the term for the Purchase Price.</p>
      </div>
     
       
      <div className='row mx-0 justify-content-center' >
   
        <div className='col-sm-6 '>
        <input type="range" className="form-range blue-range" id="customRange" />
          <form onSubmit={handeloffer}>
            <div className="row mt-5">
              <div className="col-sm-6">
                <label for="inputState">FINANCE Contingencies</label>
                <select id="inputState" className="form-control mb-3" onChange={(e) => setFormData({ ...formData, finance_contingency: e.target.value })}>
                  <option selected>1</option>
                  <option selected>2</option>
                </select>
              </div>
              <div className="col-sm-6">
                <label for="inputState">DAYS</label>
                <select id="inputState" className="form-control mb-3" >
                  <option selected>Choose...</option>
                  <option>...</option>
                </select>
              </div>
            </div>

            <div className="col-sm-12">
              <label for="inputState">APPRAISAL CONTINGENCIES</label>
              <select id="inputState" className="form-control mb-3" onChange={(e) => setFormData({ ...formData, appraisal_contingency: e.target.value })}>
                <option selected>2</option>
                <option selected>3</option>
              </select>
            </div>
            <div className="col">
              <label for="inputState">INSPECTION CONTINGENCIES</label>
              <select id="inputState" className="form-control mb-3" onChange={(e) => setFormData({ ...formData, inspection_contingency: e.target.value })}>
                <option selected>3</option>
                <option selected>2</option>
              </select>
            </div>
            <div className="col">
              <label for="inputState">DAYS</label>
              <select id="inputState" className="form-control mb-3">
                <option selected>1</option>
                <option selected>2</option>
              </select>
            </div>


            <div className="col">
              <label for="inputState">HOME SALE CONTINGENCIES</label>
              <select id="inputState" className="form-control mb-3" onChange={(e) => setFormData({ ...formData, homesale_contingency: e.target.value })}>
                <option selected>3</option>
                <option selected>5</option>
              </select>
            </div>


            <div className="col">
              <label for="inputState">DAYS TO CLOSE OF ESCROW</label>
              <select id="inputState" className="form-control mb-3" onChange={(e) => setFormData({ ...formData, days_to_close_of_escrow: e.target.value })}>
                <option selected>5</option>
                <option selected>3</option>
              </select>
            </div>

            <div className="col">
              <label for="inputState">SPECIAL TERMS</label>
              <textarea className='form-control1' name="" onChange={(e) => setFormData({ ...formData, special_terms: e.target.value })} id="" ></textarea>

            </div>

            <button className="sign-in mx-2" >
              DISCARD & EXIT
            </button>
            <button className="sign-in mx-2" >
              BACK
            </button>
            <button className="sign-in mx-2" type='submit' >
              SAVE & EXIT
            </button>
            <button className="sign-in mx-2">
              Next Page
            </button>
          </form >
        </div>
      </div>


    </div >
  )
}

export default Contingencies;
