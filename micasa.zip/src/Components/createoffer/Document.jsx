import React, { useState } from 'react';
import { Container, Row, Col } from 'react-bootstrap';

const Document = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState(null);

  const handleDragEnter = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    setSelectedFiles(files);
  };

  const clearSelection = () => {
    setSelectedFiles(null);
  };

  return (
    <Container className="mt-5">
      <Row>
        <Col md={{ span: 6, offset: 3 }}>
          <div
            className={`file-drop-zone text-center p-5 border border-secondary ${
              isDragging ? 'border-primary' : ''
            }`}
            onDragOver={(e) => e.preventDefault()}
            onDragEnter={handleDragEnter}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            {selectedFiles ? (
              <div className="selected-file">
                <p className="mb-3">
                  Selected File: {selectedFiles[0].name}
                </p>
                <button
                  className="btn btn-danger"
                  onClick={clearSelection}
                >
                  Clear Selection
                </button>
              </div>
            ) : (
              <div>
                <input
                  type="file"
                  accept="image/*"
                  className="form-control"
                  placeholder='enusgag'
                />
                <p className="mb-0">
                  {isDragging
                    ? 'Release to Upload'
                    : 'Drag and drop file here or click to select file'}
                </p>
              </div>
            )}
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default Document;
