import React, { useEffect, useState } from "react";
import axios from "axios";
import { Container, Row, Col } from "react-bootstrap";

const FinalReview = () => {
  const [userdata, setUserdata] = useState([]);
  console.log("userdata", userdata);
  const handeloffer = () => {
    const accessToken = localStorage.getItem("accessToken");
    const config = {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Token ${accessToken}`,
        Accept: "application/json",
      },
    };

    axios.get(`http://192.168.0.13:8000/GetOfferApi/${7}/`, config)  
      .then((res) => {
        setUserdata(res.data.data);
        console.log("Response:", res.data);
      })
      .catch((err) => {
        console.error("Error:", err);
      });
  };
  useEffect(() => {
    handeloffer();
  }, []);

  return (
    
  <div className='mx-5'>
      <div className="text-center">
        <h3>Create Offer</h3>
        <h6>FINAL REVIEW</h6>
        <p>Please confirm the following is correct </p>
      </div>
   <Container>
      <Row>
        <Col>
       
         
          {
            userdata?.map((val)=>{
              return(
                <>
                  <div
                    style={{
                      border: "1px solid #ccc",
                      padding: "10px",
                      width: "50%",
                    }}
                  >
                    <h3>Summary of term</h3>
                    <h6>INTIAL DEPOSITE</h6>
                    <p>{val.initial_deposite}</p>
                    <h6>FINANCE TYPE</h6>
                    <p>{val.finance_type}</p>
                    <h6>LOAN AMOUNT</h6>
                    <p>{val.loan_amount}</p>
                    <h6>PERCENT DOWN</h6>
                    <p></p>
                    <h6>DOWN PAYMENT</h6>
                    <p></p>
                    <h6>BALANCE OF DOWNPAYMENT</h6>
                    <p></p>
                    <h6>FINANCE CONTINGENCIES</h6>
                    <p>{val.no_finance_contingency}</p>
                    <h6>APPRICAL CONTINGENCIES</h6>
                    <p>{val.appraisal_contingency}</p>
                    <h6>INSPECTION CONTINGENCIES</h6>
                    <p>{val.no_inspection_contingency}</p>
                    <h6>HOME SALE CONTINGENCIES</h6>
                    <p>{val.homesale_contingency}</p>
                    <h6>CLOSE OF ESCROW</h6>
                    <p>{val.days_to_close_of_escrow}</p>
                    <h6>SUBMITTED ON</h6>
                    <p></p>
                    <h6>SPECIAL TERM</h6>
                    <p>{val.special_terms}</p>
                  </div>
                </>
              )
            })

          }
       
         
        
        </Col>
        <Col>
          <div style={{ border: '1px solid #ccc', padding: '10px' }}>
            PRESENTED B
          </div>
        </Col>
      </Row>
    </Container>

    </div>
  );
};

export default FinalReview;
