import React from "react";
import { Row, Col, Form, Button, Container } from "react-bootstrap";

const AgentInformation = () => {
  const handelOffer = (e) => {
    e.preventDefault();
    // Handle form submission here
  };

  const moveToNextPage = () => {
    // Handle navigation to the next page
  };

  return (
    <div className="container-fluid">
      <div className="text-center">
        <h3>Create Offer</h3>
        <h6>Agent Information</h6>
        <p>Provide Contact and brokerage info for the Buyer Agent.</p>
      </div>

      <Row>
        <input type="range" class="form-control-range" id="formControlRange" />

        <h3>PRESENTED BY</h3>
        <Col sm={6} className="p-5 bg-secondary  text-black  light border">
          <Form onSubmit={handelOffer}>
            <Form.Group className="mb-4">
              <Form.Label>NAME</Form.Label>
              <Form.Control type="text" placeholder="Name" />
            </Form.Group>

            <Form.Group className="mb-4">
              <Form.Label>LICENSE NUMBER</Form.Label>
              <Form.Control type="text" placeholder="License Number" />
            </Form.Group>

            <Form.Group className="mb-4">
              <Form.Label>Email</Form.Label>
              <Form.Control type="text" placeholder="Email" />
            </Form.Group>

            <Form.Group className="mb-4">
              <Form.Label>PHONE NUMBER</Form.Label>
              <Form.Control type="text" placeholder="Phone Number" />
            </Form.Group>

            <Form.Group className="mb-4">
              <Form.Label>AGENT PHOTO</Form.Label>
              <Form.Control type="file" />
            </Form.Group>

            <button className="sign-in">REPLACE</button>
            <button className="sign-in">REMOVE</button>
          </Form>
        </Col>

        <Col sm={6} className="p-5 bg-secondary  text-black  light border">
          <h3>BROKERAGE INFO</h3>

          <Form onSubmit={handelOffer}>
            <Form.Group className="mb-4">
              <Form.Control type="text" placeholder="Name" />
            </Form.Group>

            <Form.Group className="mb-4">
              <Form.Label>LICENSE NUMBER</Form.Label>
              <Form.Control type="text" placeholder="License Number" />
            </Form.Group>

            <Form.Group className="mb-4">
              <Form.Label>ADDRESS LINE 1</Form.Label>
              <Form.Control type="text" placeholder="Address Line 1" />
            </Form.Group>

            <Form.Group className="mb-4">
              <Form.Label>ADDRESS LINE 2</Form.Label>
              <Form.Control type="text" placeholder="Address Line 2" />
            </Form.Group>

            <Form.Group className="mb-4">
              <Form.Label>BROKERAGE LOGO</Form.Label>
              <Form.Control type="file" />
            </Form.Group>

            <button className="sign-in">REPLACE</button>
            <button className="sign-in">REMOVE</button>
          </Form>
        </Col>
      </Row>
    </div>
  );
};

export default AgentInformation;
