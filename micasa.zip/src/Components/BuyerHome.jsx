import React, { useEffect, useState } from 'react';
import axios from 'axios';

const BuyerHome = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('http://192.168.0.13:8000/AllProperties/')
      .then(response => {
        setData(response.data.data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
        setLoading(false);
      });
  }, []);

  return (
    <div>
      <h1>BuyerHome</h1>
      {loading ? (
        <p>Loading data...</p>
      ) : (
        <ul>
          {data.map(property => (
            <li key={property.id}>
              <h2>{property.street_address}</h2>
              <p>Unit: {property.unit}</p>
              <p>Zip Code: {property.zip_code}</p>
              <p>Year Built: {property.year_built}</p>
              <p>Bedrooms: {property.bedroom}</p>
              <p>Bathrooms: {property.bathroom}</p>
              <p>Square Footage: {property.squar_foot}</p>
              <p>Lot Size: {property.lot_size}</p>
              <p>Asking Price: {property.asking_price}</p>
              <p>Description: {property.descriptions}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default BuyerHome;
