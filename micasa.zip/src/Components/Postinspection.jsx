import React, { useEffect, useState } from "react";
import download from "../Images/download.svg";
import download1 from "../Images/download-1.svg";
import download2 from "../Images/download-2.svg";
import uploadicon from "../Images/Uploadicon.svg";
import uploadicon1 from "../Images/Uploadicon-1.svg";
import uploadicon2 from "../Images/Uploadicon-2.svg";
import Header from "./Header";
import Sidebar from "./Sidebar";
import axios from "axios";
import uploadsvg from "../Images/Uploadicon-2.svg";

const FinishLine = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedFile1, setSelectedFile1] = useState(null);
  const [selectedFile2, setSelectedFile2] = useState(null);
  const [selectedFile3, setSelectedFile3] = useState(null);
  const [checkboxChecked, setCheckboxChecked] = useState(false);
  const [checkboxChecked1, setCheckboxChecked1] = useState(false);
  const [checkboxChecked2, setCheckboxChecked2] = useState(false);
  const [checkboxChecked3, setCheckboxChecked3] = useState(false);
  const [checkboxChecked4, setCheckboxChecked4] = useState(false);
  const [checkboxChecked5, setCheckboxChecked5] = useState(false);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    setSelectedFile(file);
  };

  const handleFileChange1 = (event) => {
    const file = event.target.files[0];
    setSelectedFile1(file);
  };
  const handleFileChange2 = (event) => {
    const file = event.target.files[0];
    setSelectedFile2(file);
  };
  const handleFileChange3 = (event) => {
    const file = event.target.files[0];
    setSelectedFile3(file);
  };
  const handleUpload = () => {
    const token = localStorage.getItem("accessToken");

    if (token) {
      const config = {
        headers: {
          Authorization: `token ${token}`,
        },
      };
      if (selectedFile) {
        const formData = new FormData();
        formData.append("page_no", 7);
        formData.append("seller_uploaded_doc_id", 1);
        formData.append("full_inspection_report", 10);
        formData.append("full_inspection_report_doc", selectedFile);
        formData.append("fully_executed_report", 18);
        formData.append("fully_executed_report_doc", selectedFile1);
        formData.append("inspection_contingency_removal", 19);
        formData.append("inspection_contingency_removal_doc", selectedFile2);
        formData.append("supplemental", 20);
        formData.append("supplemental_doc", selectedFile3);
        //   formData.append("upload_documents", selectedFile);

        axios
          .post(
            "http://192.168.0.13:8000/Add_Post_inspection/",
            formData,
            config,
            {}
          )
          .then((response) => {
            console.log(response.data);
          })
          .catch((error) => {
            console.log(error);
          });
      }
    }
  };

  const [data, setData] = useState([]);
  const baseurl = "http://192.168.0.13:8000";

  useEffect(() => {
    const token = localStorage.getItem("accessToken");

    if (token) {
      const config = {
        headers: {
          Authorization: `token ${token}`,
        },
      };
      axios
        .get("http://192.168.0.13:8000/GetPropertyListingApi/1/7/", config)
        .then((response) => {
          setData(response.data.property_docs);
          console.log(response.data.property_docs);
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        });
    }
  }, []);

  // Create a function to filter data for "Inspector" documents
  const filteradditionaldocDocuments = (data) => {
    return data.filter(
      (item) => item.document_type_name.name === "Full Inspection Repport Doc"
    );
  };

  const filterConditionInspectionDocuments = (data) => {
    return data.filter(
      (item) => item.document_type_name.name === "Executed request for user"
    );
  };
  const filterWirereceiptdocDocuments = (data) => {
    return data.filter(
      (item) => item.document_type_name.name === "Contingency Removal Doc"
    );
  };
  const filterSellerestimatedocDocuments = (data) => {
    return data.filter(
      (item) => item.document_type_name.name === "Additional Doc"
    );
  };

  return (
    <section className="bg-banner-dashborad">
      <Header />
      <div className="bg-main">
        <div className="row mx-0 position-box">
          <div className="col-sm-2 px-0">
            <Sidebar />
          </div>
          <div className="col-sm-7">
            <div className="main">
              <div>
                <h5 className="head-label">Things Left to do</h5>
                <div>
                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault1"
                      />
                      <label
                        className="form-check-label"
                        htmlFor="flexCheckDefault1"
                      >
                        <i>
                          {" "}
                          The transaction is almost complete, Upload all
                          contingency removals!
                        </i>
                      </label>
                    </div>
                  </div>
                  <div>
                    <div>
                      <div className="form-check my-4">
                        <label className="form-check-label">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            checked={checkboxChecked1}
                            onChange={() =>
                              setCheckboxChecked1(!checkboxChecked1)
                            }
                          />
                          Upload the Full Inspection Report (optional)
                        </label>
                      </div>
                      <fieldset className="ps-4" disabled={!checkboxChecked1}>
                        <img src={uploadsvg} className="upload-icon" alt="" />
                        <input
                          type="file"
                          name="upload_documents"
                          id="upload_documents"
                          onChange={handleFileChange}
                        />
                      </fieldset>
                    </div>
                  </div>
                  <div>
                    <div className="form-check my-4">
                      <label className="form-check-label">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          checked={checkboxChecked2}
                          onChange={() =>
                            setCheckboxChecked2(!checkboxChecked2)
                          }
                        />
                        Upload the Fully Executed Request For Repair
                      </label>
                    </div>
                    <fieldset className="ps-4" disabled={!checkboxChecked2}>
                      <img src={uploadsvg} className="upload-icon" alt="" />

                      <input
                        type="file"
                        name="upload_documents"
                        id="upload_documents"
                        onChange={handleFileChange1}
                      />
                    </fieldset>
                  </div>

                  <div>
                    <div className="form-check my-4">
                      <label className="form-check-label">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          checked={checkboxChecked5}
                          onChange={() =>
                            setCheckboxChecked5(!checkboxChecked5)
                          }
                        />
                        Upload the Fully Executed Inspection Contingency Removal
                      </label>
                    </div>
                    <fieldset className="ps-4" disabled={!checkboxChecked5}>
                      <img src={uploadsvg} className="upload-icon" alt="" />

                      <input
                        type="file"
                        name="upload_documents"
                        id="upload_documents"
                        onChange={handleFileChange2}
                      />
                    </fieldset>
                  </div>

                  <div>
                    <div className="form-check my-4">
                      <label className="form-check-label">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          checked={checkboxChecked}
                          onChange={() => setCheckboxChecked(!checkboxChecked)}
                        />
                        Upload additional supplemental documents
                      </label>
                    </div>
                    <fieldset className="ps-4" disabled={!checkboxChecked}>
                      <img src={uploadsvg} className="upload-icon" alt="" />

                      <input
                        type="file"
                        name="upload_documents"
                        id="upload_documents"
                        onChange={handleFileChange3}
                      />
                    </fieldset>
                  </div>
                  <div className="text-center">
                    <button
                      className="mt-4 sign-in"
                      type="button"
                      onClick={handleUpload}
                    >
                      Save
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-3">
            <div className="sidebox-right">
              <h1>Key Documnet</h1>
              <div className="side-keydocument">
                <div className="buttonone">
                  {filteradditionaldocDocuments(data).map((item) => (
                    <a href={baseurl + item.upload_documents}>
                      <div className="background">
                        <img src={download2} alt="" />
                        <p className="mb-0">
                          {" "}
                          Full Inspection Report
                        </p>
                      </div>
                    </a>
                  ))}

                  <div className="upload-button">
                    <img src={uploadicon2} alt="" />
                  </div>
                </div>
                <div className="buttontwo">
                  {filterConditionInspectionDocuments(data).map((item) => (
                    <a href={baseurl + item.upload_documents}>
                      <div className="background">
                        <img src={download1} alt="" />
                        <p className="mb-0">
                        Fully Executed Request For Repair
                        </p>
                      </div>
                    </a>
                  ))}

                  <div className="upload-button">
                    <img src={uploadicon1} alt="" />
                  </div>
                </div>
                <div className="buttonthree">
                  {filterWirereceiptdocDocuments(data).map((item) => (
                    <a href={baseurl + item.upload_documents}>
                      <div className="background">
                        <img src={download} alt="" />
                        <p className="mb-0">
                        Fully Executed Inspection Contingency Removal
                        </p>
                      </div>
                    </a>

                    // You can display other properties of the item as needed
                  ))}

                  <div className="upload-button">
                    <img src={uploadicon} alt="" />
                  </div>
                </div>
                <div className="buttonone">
                  {filterSellerestimatedocDocuments(data).map((item) => (
                    <a href={baseurl + item.upload_documents}>
                      <div className="background">
                        <img src={download2} alt="" />
                        <p className="mb-0">
                        additional supplemental documents
                        </p>
                      </div>
                    </a>
                  ))}

                  <div className="upload-button">
                    <img src={uploadicon2} alt="" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FinishLine;
