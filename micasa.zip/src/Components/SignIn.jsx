import React, { useEffect, useState } from "react";
import Header from "./Header";
import sidelogo from "../Images/logo-micasa-deepgreen.png";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

const SignIn = () => {
  const navigation = useNavigate()
  const [userdata, setuserData] = useState([])
  useEffect(() => {
    if (userdata.token) {
    }
  }, []);

  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });

  const handleSignIn = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "  http://192.168.0.13:8000/LoginApi/",
        formData
      );
      console.log("Signin Response:", response.data);
      setuserData(response.data);
      localStorage.setItem("accessToken", response.data.token);
      localStorage.setItem("username", response.data.username);
     
      toast.success(response.data.message);


      navigation('/propertilisting')
    } catch (error) {
      console.error("Signin Error:", error);
    }
  };

  return (
    <div>
      <section className="sign-up-login">
        <div className="row mx-0 justify-content-center my-100">
          <div className="col-sm-11">
            <Header />
            <div className="bg-main-primary">
              <div className="row mx-0 align-items-center">
                <div className="col-sm-5 ps-5">
                  <div className="sign-left-box ">
                    <img src={sidelogo} alt="" />
                    <h3>your AI realtor</h3>
                  </div>
                </div>
                <div className="col-sm-7 px-0">
                  <div className="right-box">
                    <div className="row mx-0 justify-content-center">
                      <div className="col-sm-8">
                        <form onSubmit={handleSignIn}>
                          <h5 className="head-label">Sign In</h5>
                          <div className="row mx-0">
                            <div className="mb-3 col-sm-12 ps-0">
                              <label className="form-label">USERNAME</label>
                              <input
                                type="text"
                                className="form-control"
                                onChange={(e) =>
                                  setFormData({
                                    ...formData,
                                    username: e.target.value,
                                  })
                                }
                              />
                            </div>
                            <div className="mb-3 col-sm-12 ps-0">
                              <label className="form-label">PASSWORD</label>
                              <input
                                type="password"
                                className="form-control"
                                onChange={(e) =>
                                  setFormData({
                                    ...formData,
                                    password: e.target.value,
                                  })
                                }
                              />
                            </div>
                          </div>
                          <button className="sign-in" type="">Login</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SignIn;
