import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import download from "../Images/download.svg";
import download1 from "../Images/download-1.svg";
import download2 from "../Images/download-2.svg";
import uploadicon from "../Images/Uploadicon.svg";
import uploadicon1 from "../Images/Uploadicon-1.svg";
import uploadicon2 from "../Images/Uploadicon-2.svg";
import Header from "./Header";
import Sidebar from "./Sidebar";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { toast } from "react-toastify";

const Escrow = () => {
  const [properties, setproperties] = useState();
  const [acceptance, setacceptance] = useState();
  const [buyer_inspection, setbuyer_inspection] = useState();
  const [buyer_closing_fund, setbuyer_closing_fund] = useState();
  const [earnest_money_deposite, setearnest_money_deposite] = useState();
  const [buyer_appraisal, setbuyer_appraisal] = useState();
  const [close_of_escrow, setclose_of_escrow] = useState();
  const [seller_disclosures, setseller_disclosures] = useState();
  const [buyer_loan_contingency, setbuyer_loan_contingency] = useState();
  const [special_term_1, setspecial_term_1] = useState();
  const [home_sale_contingency, sethome_sale_contingency] = useState();
  const [special_term_2, setspecial_term_2] = useState();

  const navigate = useNavigate();

  let handleSubmit = async (e) => {
    e.preventDefault();

    const token = localStorage.getItem("accessToken");
    var data = new FormData();
    // data.append("properties", properties);
    data.append("acceptance", acceptance);
    data.append("buyer_inspection", buyer_inspection);
    data.append("buyer_closing_fund", buyer_closing_fund);
    data.append("earnest_money_deposite", earnest_money_deposite);
    data.append("buyer_appraisal", buyer_appraisal);
    data.append("close_of_escrow", close_of_escrow);
    data.append("seller_disclosures", seller_disclosures);
    data.append("buyer_loan_contingency", buyer_loan_contingency);
    data.append("special_term_1", special_term_1);
    data.append("home_sale_contingency", home_sale_contingency);
    data.append("special_term_2", special_term_2);

    const config = {
      method: "post",
      url: "http://192.168.0.13:8000/EscrowApi/",
      headers: {
        "Content-Type": "multipart/form-data",
        Accept: "application/json",
        Authorization: `token ${token}`, // Include the token in the Authorization header
      },
      data: data,
    };

    axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
        toast.success("SuccessFull");
        // navigate("/login");
      })
      .catch(function (error) {
        console.log(error);
        toast.error("falied " + error.message);
      });
  };
  return (
    <section className="bg-banner-dashborad">
      <Header />
      <div className="bg-main">
        <div className="row mx-0 position-box">
          <div className="col-sm-2 px-0">
            <Sidebar />
          </div>
          <div className="col-sm-7">
            <div className="main">
              <div>
                <h5 className="head-label">Things Left to do</h5>
                <Form onSubmit={handleSubmit}>
                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault1"
                      />
                      <label
                        className="form-check-label"
                        htmlFor="flexCheckDefault1"
                      >
                        <i>
                          Welcome to Escrow - Congratulation! Below is the
                          purchase agreement along with the escrow calendar with
                          important dates for your transaction.
                        </i>
                      </label>
                    </div>
                  </div>
                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault4"
                      />
                      <label
                        className="form-check-label"
                        htmlFor="flexCheckDefault4"
                      >
                        Upload your General Inspection Report
                      </label>
                    </div>
                    <div className="upload-file">
                      <label htmlFor="filetype">
                        <svg
                          width="48"
                          height="48"
                          viewBox="0 0 48 48"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <mask
                            id="mask0_106_3038"
                            maskUnits="userSpaceOnUse"
                            x="0"
                            y="0"
                            width="48"
                            height="48"
                          >
                            <circle cx="24" cy="24" r="24" fill="#D9D9D9" />
                          </mask>
                          <g mask="url(#mask0_106_3038)">
                            <circle cx="24" cy="24" r="24" fill="#408F81" />
                            <path
                              d="M16.1999 33.5999C15.7199 33.5999 15.2999 33.4199 14.9399 33.0599C14.5799 32.6999 14.3999 32.2799 14.3999 31.7999V27.5099H16.1999V31.7999H31.7999V27.5099H33.5999V31.7999C33.5999 32.2799 33.4199 32.6999 33.0599 33.0599C32.6999 33.4199 32.2799 33.5999 31.7999 33.5999H16.1999ZM23.0999 29.0099V17.8799L19.4999 21.4799L18.2099 20.1899L23.9999 14.3999L29.7899 20.1899L28.4999 21.4799L24.8999 17.8799V29.0099H23.0999Z"
                              fill="white"
                            />
                          </g>
                        </svg>
                      </label>

                      <input type="file" id="filetype" />
                    </div>
                  </div>
                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault1"
                      />
                      <label
                        className="form-check-label"
                        htmlFor="flexCheckDefault1"
                      >
                        <i>
                          Important Dates In The Transaction: Provide all the
                          important dates for the transaction.
                        </i>
                      </label>
                    </div>
                    <div className="dates-section">
                      <div className="row">
                        <div className="col-sm-4 mb-3">
                          <div className="label-dates-escrow">
                            <label htmlFor="">Acceptance</label>
                            <input
                              value={acceptance}
                              type="date"
                              name=""
                              className="form-control"
                              id=""
                              onChange={(e) => setacceptance(e.target.value)}
                            />
                          </div>
                        </div>
                        <div className="col-sm-4 mb-3">
                          <div className="label-dates-escrow">
                            <label htmlFor="">
                              Buyer Inspection Contingency
                            </label>
                            <input
                              value={buyer_inspection}
                              type="date"
                              name=""
                              className="form-control"
                              id=""
                              onChange={(e) =>
                                setbuyer_inspection(e.target.value)
                              }
                            />
                          </div>
                        </div>
                        <div className="col-sm-4 mb-3">
                          <div className="label-dates-escrow">
                            <label htmlFor="">Buyer Closing Funds Due</label>
                            <input
                              value={buyer_closing_fund}
                              type="date"
                              name=""
                              className="form-control"
                              id=""
                              onChange={(e) =>
                                setbuyer_closing_fund(e.target.value)
                              }
                            />
                          </div>
                        </div>
                        <div className="col-sm-4 mb-3">
                          <div className="label-dates-escrow">
                            <label htmlFor="">Earnest Money Deposit</label>
                            <input
                              value={earnest_money_deposite}
                              type="date"
                              name=""
                              className="form-control"
                              id=""
                              onChange={(e) =>
                                setearnest_money_deposite(e.target.value)
                              }
                            />
                          </div>
                        </div>
                        <div className="col-sm-4 mb-3">
                          <div className="label-dates-escrow">
                            <label htmlFor="">
                              Buyer Appraisal Contingency
                            </label>
                            <input
                              value={buyer_appraisal}
                              type="date"
                              name=""
                              className="form-control"
                              id=""
                              onChange={(e) =>
                                setbuyer_appraisal(e.target.value)
                              }
                            />
                          </div>
                        </div>
                        <div className="col-sm-4 mb-3">
                          <div className="label-dates-escrow">
                            <label htmlFor="">Close Of Escrow</label>
                            <input
                              value={close_of_escrow}
                              type="date"
                              name=""
                              className="form-control"
                              id=""
                              onChange={(e) =>
                                setclose_of_escrow(e.target.value)
                              }
                            />
                          </div>
                        </div>
                        <div className="col-sm-4 mb-3">
                          <div className="label-dates-escrow">
                            <label htmlFor="">Seller Disclosures</label>
                            <input
                              value={seller_disclosures}
                              type="date"
                              name=""
                              className="form-control"
                              id=""
                              onChange={(e) =>
                                setseller_disclosures(e.target.value)
                              }
                            />
                          </div>
                        </div>
                        <div className="col-sm-4 mb-3">
                          <div className="label-dates-escrow">
                            <label htmlFor="">Buyer Loan Contingency</label>
                            <input
                              value={buyer_loan_contingency}
                              type="date"
                              name=""
                              className="form-control"
                              id=""
                              onChange={(e) =>
                                setbuyer_loan_contingency(e.target.value)
                              }
                            />
                          </div>
                        </div>
                        <div className="col-sm-4 mb-3">
                          <div className="label-dates-escrow">
                            <label htmlFor="">Special Term (1)</label>
                            <input
                              value={special_term_1}
                              type="date"
                              name=""
                              className="form-control"
                              id=""
                              onChange={(e) =>
                                setspecial_term_1(e.target.value)
                              }
                            />
                          </div>
                        </div>
                        <div className="col-sm-4 mb-3">
                          <div className="label-dates-escrow">
                            <label htmlFor="">Home Sale Contingency</label>
                            <input
                              value={home_sale_contingency}
                              type="date"
                              name=""
                              className="form-control"
                              id=""
                              onChange={(e) =>
                                sethome_sale_contingency(e.target.value)
                              }
                            />
                          </div>
                        </div>
                        <div className="col-sm-4 mb-3">
                          <div className="label-dates-escrow">
                            <label htmlFor="">Special Term (2)</label>
                            <input
                              value={special_term_2}
                              type="date"
                              name=""
                              className="form-control"
                              id=""
                              onChange={(e) =>
                                setspecial_term_2(e.target.value)
                              }
                            />
                          </div>
                        </div>
                      </div>
                      <button className="sign-in px-5" type="submit">
                        Submit
                      </button>
                    </div>
                  </div>
                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault4"
                      />
                      <label
                        className="form-check-label"
                        htmlFor="flexCheckDefault4"
                      >
                        Upload the receipt of earnest money deposit
                      </label>
                    </div>
                    <div className="side-keydocument">
                      <div className="buttonone">
                        <div className="background">
                          <img src={download2} alt="" />
                          <p className="mb-0">
                            Custom Escrow Transaction Timeline
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault4"
                      />
                      <label
                        className="form-check-label"
                        htmlFor="flexCheckDefault4"
                      >
                        Download and share your very own custom escrow
                        transaction timeline to the buyer’s agent and your
                        client so everyone is on the same page.
                      </label>
                    </div>
                    <div className="upload-file">
                      <label htmlFor="filetype">
                        <svg
                          width="48"
                          height="48"
                          viewBox="0 0 48 48"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <mask
                            id="mask0_106_3038"
                            maskUnits="userSpaceOnUse"
                            x="0"
                            y="0"
                            width="48"
                            height="48"
                          >
                            <circle cx="24" cy="24" r="24" fill="#D9D9D9" />
                          </mask>
                          <g mask="url(#mask0_106_3038)">
                            <circle cx="24" cy="24" r="24" fill="#408F81" />
                            <path
                              d="M16.1999 33.5999C15.7199 33.5999 15.2999 33.4199 14.9399 33.0599C14.5799 32.6999 14.3999 32.2799 14.3999 31.7999V27.5099H16.1999V31.7999H31.7999V27.5099H33.5999V31.7999C33.5999 32.2799 33.4199 32.6999 33.0599 33.0599C32.6999 33.4199 32.2799 33.5999 31.7999 33.5999H16.1999ZM23.0999 29.0099V17.8799L19.4999 21.4799L18.2099 20.1899L23.9999 14.3999L29.7899 20.1899L28.4999 21.4799L24.8999 17.8799V29.0099H23.0999Z"
                              fill="white"
                            />
                          </g>
                        </svg>
                      </label>

                      <input type="file" id="filetype" />
                    </div>
                  </div>

                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault3"
                      />
                      <label
                        className="form-check-label"
                        htmlFor="flexCheckDefault3"
                      >
                        Complete all the necessary escrow documents
                      </label>
                    </div>
                    <div className="row justify-content-evenly">
                      <div className="col-sm-5">
                        <div className="buttonone">
                          <div className="background">
                            <img src={download2} alt="" />
                            <p className="mb-0">General Inspection Report</p>
                          </div>
                          <div className="upload-button">
                            <img src={uploadicon2} alt="" />
                          </div>
                        </div>
                      </div>
                      <div className="col-sm-5">
                        <div className="buttonone">
                          <div className="background">
                            <img src={download2} alt="" />
                            <p className="mb-0">General Inspection Report</p>
                          </div>
                          <div className="upload-button">
                            <img src={uploadicon2} alt="" />
                          </div>
                        </div>
                      </div>
                      <div className="col-sm-5">
                        <div className="buttonone">
                          <div className="background">
                            <img src={download2} alt="" />
                            <p className="mb-0">General Inspection Report</p>
                          </div>
                          <div className="upload-button">
                            <img src={uploadicon2} alt="" />
                          </div>
                        </div>
                      </div>
                      <div className="col-sm-5">
                        <div className="buttonone">
                          <div className="background">
                            <img src={download2} alt="" />
                            <p className="mb-0">General Inspection Report</p>
                          </div>
                          <div className="upload-button">
                            <img src={uploadicon2} alt="" />
                          </div>
                        </div>
                      </div>
                      <div className="col-sm-5">
                        <div className="buttonone">
                          <div className="background">
                            <img src={download2} alt="" />
                            <p className="mb-0">General Inspection Report</p>
                          </div>
                          <div className="upload-button">
                            <img src={uploadicon2} alt="" />
                          </div>
                        </div>
                      </div>
                      <div className="col-sm-5">
                        <div className="buttonone">
                          <div className="background">
                            <img src={download2} alt="" />
                            <p className="mb-0">General Inspection Report</p>
                          </div>
                          <div className="upload-button">
                            <img src={uploadicon2} alt="" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </Form>
              </div>
            </div>
          </div>
          <div className="col-sm-3">
            <div className="sidebox-right">
              <h1>Key Documnet</h1>
              <div className="side-keydocument">
                <div className="buttonone">
                  <div className="background">
                    <img src={download2} alt="" />
                    <p className="mb-0">General Inspection Report</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon2} alt="" />
                  </div>
                </div>
                <div className="buttontwo">
                  <div className="background">
                    <img src={download1} alt="" />
                    <p className="mb-0">General Inspection Report</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon1} alt="" />
                  </div>
                </div>
                <div className="buttonthree">
                  <div className="background">
                    <img src={download} alt="" />
                    <p className="mb-0">General Inspection Report</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon} alt="" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Escrow;
