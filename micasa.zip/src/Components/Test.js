import React, { useEffect, useState } from "react";
import axios from "axios";
import uploadsvg from "../Images/Uploadicon-2.svg";

const Test = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedFile1, setSelectedFile1] = useState(null);
  const [selectedFile2, setSelectedFile2] = useState(null);
  const [checkboxChecked1, setCheckboxChecked1] = useState(false);
  const [checkboxChecked2, setCheckboxChecked2] = useState(false);
  const [checkboxChecked5, setCheckboxChecked5] = useState(false);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    setSelectedFile(file);
  };

  const handleFileChange1 = (event) => {
    const file = event.target.files[0];
    setSelectedFile1(file);
  };
  const handleFileChange2 = (event) => {
    const file = event.target.files[0];
    setSelectedFile2(file);
  };
  const handleUpload = () => {
    const token = localStorage.getItem("accessToken");

    if (token) {
      // const apiUrl = BaseUrl + "/ThirdPartyTypesApi/2/";

      const config = {
        headers: {
          Authorization: `token ${token}`,
        },
      };

      if (selectedFile) {
        const formData = new FormData();
        formData.append("page_no", 2);
        formData.append("seller_uploaded_doc_id", 1);
        formData.append("genral_inspection", 3);
        formData.append("genral_inspection_doc", selectedFile);
        formData.append("inspection_report", 2);
        formData.append("inspection_report_doc", selectedFile1);
        formData.append("inspection_type_id", 1);
        formData.append("inspection_type_doc", selectedFile2);
        //   formData.append("upload_documents", selectedFile);

        axios
          .post(
            "http://192.168.0.13:8000/AddPreinspection/",
            formData,
            config,
            {}
          )
          .then((response) => {
            console.log(response.data);
          })
          .catch((error) => {
            console.log(error);
          });
      }
    }
  };

  const [data, setData] = useState([]);
  const baseurl = "http://192.168.0.13:8000";
  useEffect(() => {
    const token = localStorage.getItem("accessToken");

    if (token) {
      // const apiUrl = BaseUrl + "/ThirdPartyTypesApi/2/";

      const config = {
        headers: {
          Authorization: `token ${token}`,
        },
      };
      axios
        .get("http://192.168.0.13:8000/GetPropertyListingApi/1/2/", config)
        .then((response) => {
          setData(response.data.property_docs);
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        });
    }
  }, []);
  return (
    <>
      <div>
        <div>
          <div className="form-check my-4">
            <label className="form-check-label">
              <input
                className="form-check-input"
                type="checkbox"
                checked={checkboxChecked1}
                onChange={() => setCheckboxChecked1(!checkboxChecked1)}
              />
              Upload your General Inspection Report
            </label>
          </div>
          <fieldset className="ps-4" disabled={!checkboxChecked1}>
            <img src={uploadsvg} className="upload-icon" alt="" />
            <input
              type="file"
              name="upload_documents"
              id="upload_documents"
              onChange={handleFileChange}
            />
          </fieldset>
        </div>
      </div>
      <div>
        <div className="form-check my-4">
          <label className="form-check-label">
            <input
              className="form-check-input"
              type="checkbox"
              checked={checkboxChecked2}
              onChange={() => setCheckboxChecked2(!checkboxChecked2)}
            />
            Upload your Termite Inspection Report
          </label>
        </div>
        <fieldset className="ps-4" disabled={!checkboxChecked2}>
          <img src={uploadsvg} className="upload-icon" alt="" />

          <input
            type="file"
            name="upload_documents"
            id="upload_documents"
            onChange={handleFileChange1}
          />
        </fieldset>
        <div>
          <div className="form-check my-4">
            <label className="form-check-label">
              <input
                className="form-check-input"
                type="checkbox"
                checked={checkboxChecked5}
                onChange={() => setCheckboxChecked5(!checkboxChecked5)}
              />
              Upload your Asbatose Inspection Report
            </label>
          </div>
          <fieldset className="ps-4" disabled={!checkboxChecked5}>
            <img src={uploadsvg} className="upload-icon" alt="" />

            <input
              type="file"
              name="upload_documents"
              id="upload_documents"
              onChange={handleFileChange2}
            />
          </fieldset>
        </div>
        <button className="mt-4" type="button" onClick={handleUpload}>
          Save
        </button>
      </div>
      <div>
        <h1>Property Listing</h1>
        <ul>
          {data.map((item) => (
            <>
              <li>{item.document_type_name.name}</li>
              <li key={item.id}>
                <a href={baseurl + item.upload_documents}>
                  {baseurl + item.upload_documents}
                </a>
              </li>
            </>
            // You can display other properties of the item as needed
          ))}
        </ul>
      </div>
    </>
  );
};

export default Test;
