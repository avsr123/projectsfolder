import React, { useEffect, useState } from "react";
import axios from "axios";

function Test1() {
  const [data, setData] = useState([]);
  const baseurl = "http://192.168.0.13:8000";

  useEffect(() => {
    const token = localStorage.getItem("accessToken");

    if (token) {
      const config = {
        headers: {
          Authorization: `token ${token}`,
        },
      };
      axios
        .get("http://192.168.0.13:8000/GetPropertyListingApi/1/9/", config)
        .then((response) => {
          setData(response.data.property_docs);
          console.log(response.data.property_docs);
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        });
    }
  }, []);

  // Create a function to filter data for "Inspector" documents
  const filteradditionaldocDocuments = (data) => {
    return data.filter(
      (item) => item.document_type_name.name === "additional doc"
    );
  };

  const filterConditionInspectionDocuments = (data) => {
    return data.filter(
      (item) => item.document_type_name.name === "Condition Inspection"
    );
  };
  const filterWirereceiptdocDocuments = (data) => {
    return data.filter(
      (item) => item.document_type_name.name === "Wire receipt doc"
    );
  };
  const filterSellerestimatedocDocuments = (data) => {
    return data.filter(
      (item) => item.document_type_name.name === "Seller estimate doc"
    );
  };
  return (
    <div>
      <ul>
        {filteradditionaldocDocuments(data).map((item) => (
          <li key={item.id}>
            <a href={baseurl + item.upload_documents}>
              {baseurl + item.upload_documents}
            </a>
            <p>{item.document_type_name.name}</p>
          </li>
          // You can display other properties of the item as needed
        ))}
      </ul>

      <ul>
        {filterConditionInspectionDocuments(data).map((item) => (
          <li key={item.id}>
            <a href={baseurl + item.upload_documents}>
              {baseurl + item.upload_documents}
            </a>
            <p>{item.document_type_name.name}</p>
          </li>
          // You can display other properties of the item as needed
        ))}
      </ul>

      <ul>
        {filterWirereceiptdocDocuments(data).map((item) => (
          <li key={item.id}>
            <a href={baseurl + item.upload_documents}>
              {baseurl + item.upload_documents}
            </a>
            <p>{item.document_type_name.name}</p>
          </li>
          // You can display other properties of the item as needed
        ))}
      </ul>
      <ul>
        {filterSellerestimatedocDocuments(data).map((item) => (
          <li key={item.id}>
            <a href={baseurl + item.upload_documents}>
              {baseurl + item.upload_documents}
            </a>
            <p>{item.document_type_name.name}</p>
          </li>
          // You can display other properties of the item as needed
        ))}
      </ul>
    </div>
  );
}

export default Test1;
