import React, { useEffect, useState } from "react";
import Form from "react-bootstrap/Form";
import AddImage from "../Images/add_photo_alternate_BASELINE_P900_FILL0_wght400_GRAD0_opsz48 1.png";
import { RxCross1 } from "react-icons/rx";
import arrow1 from "../Images/bulb-icon-2.svg";
import arrow2 from "../Images/bulb-icon-1.svg";
import arrow3 from "../Images/bulb-icon.svg";
import Header from "./Header";
import Sidebar from "./Sidebar";
import axios from "axios";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { Image } from "react-bootstrap";
import BaseUrl from "../Components/BaseUrl";

const Propertilisting = () => {
  const apiUrl = process.env.REACT_APP_API_URL;
  const accessToken = localStorage.getItem("accessToken");

  console.log(accessToken);
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);
  const [selectedState, setSelectedState] = useState("");
  const [selectedCity, setSelectedCity] = useState("");
  const [street_address, setstreet_address] = useState();
  const [unit, setunit] = useState();
  const [zip_code, setzip_code] = useState();
  // const [property_type, setproperty_type] = useState();
  const [year_built, setyear_built] = useState();
  const [bedroom, setbedroom] = useState();
  const [bathroom, setbathroom] = useState();
  const [squar_foot, setsquar_foot] = useState();
  const [lot_size, setlot_size] = useState();
  const [lot_size_type, setlot_size_type] = useState();
  const [asking_price, setasking_price] = useState();
  const [asking_price_type, setasking_price_type] = useState();
  const [descriptions, setdescriptions] = useState();
  const [company_name, setcompany_name] = useState();
  const [escrow_officer_name, setescrow_officer_name] = useState();
  const [escrow_officer_phone, setescrow_officer_phone] = useState();
  const [escrow_officer_email, setescrow_officer_email] = useState();
  const [escrow_number, setescrow_number] = useState();
  const [images, setImages] = useState([]);
  const [imagePreviews, setImagePreviews] = useState([]);
  const [prototypes, setPrototypes] = useState([]);
  const [selectedPrototype, setSelectedPrototype] = useState("");

  // const handleImageChange = (e) => {
  //   const selectedImages = e.target.files;
  //   const imagePreviews = Array.from(selectedImages).map((image) =>
  //     URL.createObjectURL(image)
  //   );
  //   setImages([...images, ...imagePreviews]);
  // };

  const handleImageChange = (e) => {
    const selectedImages = e.target.files;
    const imagePreviews = Array.from(selectedImages).map((image) =>
      URL.createObjectURL(image)
    );

    setImages((prevImages) => [...prevImages, ...selectedImages]);
    setImagePreviews((prevPreviews) => [...prevPreviews, ...imagePreviews]);
  };

  const removeImage = (index) => {
    const updatedImages = [...images];
    updatedImages.splice(index, 1);
    setImages(updatedImages);
  };

  const isImageSelected = images.length > 0;

  // const navigate = useNavigate();

  let handleSubmit = async (e) => {
    e.preventDefault();

    var data = new FormData();
    data.append("state", selectedState); // Use the primary key value of the selected state
    data.append("city", selectedCity); // Use the primary key value of the selected city
    data.append("street_address", street_address);
    data.append("unit", unit);
    data.append("zip_code", zip_code);
    // data.append("property_type", property_type);
    data.append("prototypes", prototypes);
    data.append("year_built", year_built);
    data.append("bedroom", bedroom);
    data.append("bathroom", bathroom);
    data.append("squar_foot", squar_foot);
    data.append("lot_size", lot_size);
    data.append("lot_size_type", lot_size_type);
    data.append("asking_price", asking_price);
    data.append("asking_price_type", asking_price_type);
    data.append("descriptions", descriptions);
    data.append("company_name", company_name);
    data.append("escrow_officer_name", escrow_officer_name);
    data.append("escrow_officer_phone", escrow_officer_phone);
    data.append("escrow_officer_email", escrow_officer_email);
    data.append("escrow_number", escrow_number);
    // data.append("images", images);
    images.forEach((images) => {
      data.append(`images`, images);
    });

    var config = {
      method: "post",
      maxBodyLength: Infinity,
      url: BaseUrl + "/PostPropertyListingApi/",
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Token ${accessToken}`,
        // Accept: "application/json",
      },
      data: data,
    };

    axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
        toast.success("SuccessFull");
        // navigate("/login");
      })
      .catch(function (error) {
        console.log(error);
        toast.error("falied " + error.message);
      });
  };

  useEffect(() => {
    axios
      .get(BaseUrl + `/StateApi/`)
      .then((response) => {
        console.log("12122", response.data.data);
        setStates(response.data.data);
      })
      .catch((error) => {
        console.error("Error fetching data from the API:", error);
      });
  }, []);

  useEffect(() => {
    if (selectedState) {
      axios
        .get(BaseUrl + `/GetCityApi/${selectedState}/`)
        .then((response) => {
          setCities(response.data.data);
        })
        .catch((error) => {
          console.error("Error fetching cities from the API:", error);
        });
    }
  }, [selectedState]);

  useEffect(() => {
    axios
      .get("http://192.168.0.13:8000/PropertyTypesApi/")
      .then((response) => {
        setPrototypes(response.data.data);
      })
      .catch((error) => {
        console.error("Error fetching data from the API:", error);
      });
  }, []);

  return (
    <section className="bg-banner-dashborad">
      <Header />
      <div className="bg-main">
        <div className="row mx-0 position-box">
          <div className="col-sm-2 px-0">
            <Sidebar />
          </div>
          <div className="col-sm-7">
            <div className="main">
              <div>
                <h5 className="head-label">Things Left to do</h5>
                <Form onSubmit={handleSubmit}>
                  <div className="form-check mb-4">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      value=""
                      id="flexCheckDefault"
                    />
                    <label
                      className="form-check-label"
                      htmlFor="flexCheckDefault"
                    >
                      Add the property listing below
                    </label>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridEmail" className="form-label">
                        STREET ADDRESS
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder=""
                        onChange={(e) => setstreet_address(e.target.value)}
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridPassword" className="form-label">
                        UNIT
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) => setunit(e.target.value)}
                        placeholder=""
                      />
                    </div>
                    <div className="col-md-4 mb-3">
                      <label htmlFor="formGridState" className="form-label">
                        State
                      </label>
                      <select
                        className="form-select"
                        id="formGridState"
                        value={selectedState}
                        onChange={(e) => setSelectedState(e.target.value)}
                      >
                        <option value="" disabled>
                          Choose...
                        </option>
                        {states.map((state) => (
                          <option key={state.id} value={state.id}>
                            {state.state_name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="col-md-4 mb-3">
                      <label htmlFor="formGridCity" className="form-label">
                        City
                      </label>
                      <select
                        className="form-select"
                        id="formGridCity"
                        value={selectedCity}
                        onChange={(e) => setSelectedCity(e.target.value)}
                      >
                        <option value="" disabled>
                          Choose...
                        </option>
                        {cities.map((city) => (
                          <option key={city.id} value={city.id}>
                            {city.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="col-md-4 mb-3">
                      <label htmlFor="formGridZip" className="form-label">
                        Zip
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) => setzip_code(e.target.value)}
                      />
                    </div>
                    {/* <div className="col-md-6 mb-3">
                      <label htmlFor="formGridEmail" className="form-label">
                        PROPERTY TYPE
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) => setproperty_type(e.target.value)}
                        placeholder=""
                      />
                    </div> */}
                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridState" className="form-label">
                        PROPERTY TYPE
                      </label>
                      <select
                        className="form-select"
                        id="formGridState"
                        value={selectedPrototype}
                        onChange={(e) => setSelectedPrototype(e.target.value)}
                      >
                        <option value="" disabled>
                          Choose...
                        </option>
                        {prototypes.map((prototype) => (
                          <option key={prototype.id} value={prototype.id}>
                            {prototype.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridPassword" className="form-label">
                        YEAR BUILT
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) => setyear_built(e.target.value)}
                        placeholder=""
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridEmail" className="form-label">
                        BEDROOMS
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) => setbedroom(e.target.value)}
                        placeholder=""
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridPassword" className="form-label">
                        BATHROOMS
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) => setbathroom(e.target.value)}
                        placeholder=""
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridEmail" className="form-label">
                        SQUARE FOOT
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) => setsquar_foot(e.target.value)}
                        placeholder=""
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridPassword" className="form-label">
                        LOT SIZE
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) => setlot_size(e.target.value)}
                        placeholder=""
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridPassword" className="form-label">
                        LOT SIZE type
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) => setlot_size_type(e.target.value)}
                        placeholder=""
                      />
                    </div>

                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridPassword" className="form-label">
                        asking_price_type
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) => setasking_price_type(e.target.value)}
                        placeholder=""
                      />
                    </div>
                    <div className="col-sm-12 mb-3">
                      <div className="form-group mb-3">
                        <label
                          htmlFor="exampleForm.ControlTextarea1"
                          className="form-label"
                        ></label>
                        <div className="input-group">
                          <span className="input-group-text">$</span>
                          <input
                            type="text"
                            className="form-control"
                            id="exampleForm.ControlTextarea1"
                            onChange={(e) => setasking_price(e.target.value)}
                            placeholder="ex.1500,000"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="col-sm-12 ">
                      <div className="form-group mb-3">
                        <label
                          htmlFor="exampleForm.ControlTextarea1"
                          className="form-label"
                        >
                          Description
                        </label>
                        <textarea
                          className="form-control"
                          id="exampleForm.ControlTextarea1"
                          rows="4"
                          onChange={(e) => setdescriptions(e.target.value)}
                        ></textarea>
                      </div>
                    </div>
                    <div className="col my-4 ">
                      <div>
                        <label className="image-upload-button">
                          {isImageSelected ? (
                            "Add More Images"
                          ) : (
                            <div className="image-box">
                              <img src={AddImage} alt="My Website Logo" />
                            </div>
                          )}
                          <input
                            type="file"
                            accept="image/*"
                            multiple
                            onChange={handleImageChange}
                          />
                        </label>
                        <div className="image-previews">
                          <div className="row">
                            {imagePreviews.map((image, index) => (
                              <div className="col-sm-3" key={index}>
                                <div className="image-box">
                                  <Image src={image} alt={`Image ${index}`} />
                                  <button onClick={() => removeImage(index)}>
                                    <RxCross1 />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-sm-12 mb-3">
                      <div className="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          value=""
                          id="flexCheckDefault"
                        />
                        <label
                          className="form-check-label"
                          htmlFor="flexCheckDefault"
                        >
                          Declare an escrow vendor. If you don’t have one in
                          mind, there are some potential firms below
                        </label>
                      </div>
                    </div>

                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridPassword" className="form-label">
                        COMPANY NAME
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) => setcompany_name(e.target.value)}
                        placeholder=""
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridEmail" className="form-label">
                        ESCROW OFFICER NAME
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) => setescrow_officer_name(e.target.value)}
                        placeholder=""
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridPassword" className="form-label">
                        ESCROW OFFICER PHONE
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) =>
                          setescrow_officer_phone(e.target.value)
                        }
                        placeholder=""
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridEmail" className="form-label">
                        ESCROW OFFICER EMAIL
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) =>
                          setescrow_officer_email(e.target.value)
                        }
                        id="formGridEmail"
                        placeholder=""
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="formGridPassword" className="form-label">
                        ESCROW NUMBER (OPTIONAL)
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        onChange={(e) => setescrow_number(e.target.value)}
                        id="formGridPassword"
                        placeholder=""
                      />
                    </div>
                  </div>

                  <h6 className="label-text">OTHER POTENTIAL ESCROW FIRMS</h6>

                  <div className="row">
                    <div className="col">
                      <button className="btn btn-green  ">
                        <img src={arrow1} alt="" /> ABC Escrow
                      </button>
                    </div>
                    <div className="col">
                      <button className="btn btn-yellow  ">
                        <img src={arrow2} alt="" /> Angelo Escrow Group
                      </button>
                    </div>
                    <div className="col">
                      <button className="btn btn-red  ">
                        <img src={arrow3} alt="" /> Escrow Daily
                      </button>
                    </div>
                  </div>
                  <div className="text-center">
                    <button type="submit" className="sign-in">
                      Save & Continue
                    </button>
                  </div>
                </Form>
              </div>
            </div>
          </div>
          <div className="col-sm-3">
            <div className="sidebox-right">
              <h1>Key Documnet</h1>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Propertilisting;
