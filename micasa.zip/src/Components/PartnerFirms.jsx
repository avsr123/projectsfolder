import React, { useState, useEffect } from "react";
import Form from "react-bootstrap/Form";
import arrow1 from "../Images/bulb-icon-2.svg";
import arrow2 from "../Images/bulb-icon-1.svg";
import arrow3 from "../Images/bulb-icon.svg";
import download from "../Images/download.svg";
import download1 from "../Images/download-1.svg";
import download2 from "../Images/download-2.svg";
import uploadicon from "../Images/Uploadicon.svg";
import uploadicon1 from "../Images/Uploadicon-1.svg";
import uploadicon2 from "../Images/Uploadicon-2.svg";
import Header from "./Header";
import Sidebar from "./Sidebar";

const PartnerFirms = () => {
  const [photographyData, setPhotographyData] = useState([]);
  const [homeTourData, setHomeTourData] = useState([]);
  const [forSaleSignData, setForSaleSignData] = useState([]);
  const [cleaningServiceData, setCleaningServiceData] = useState([]);
  const [stagingServiceData, setStagingServiceData] = useState([]);

     useEffect(() => {
    fetch("http://192.168.0.13:8000/ThirdPartyTypesApi/4/")
      .then((response) => response.json())
      .then((responseData) => {
        const filteredData = {
          Photography: responseData.data.filter(
            (item) => item.types.name === "Photography"
          ),
          HomeTour: responseData.data.filter(
            (item) => item.types.name === "360 Home Tour"
          ),
          ForSaleSign: responseData.data.filter(
            (item) => item.types.name === "For Sale Sign"
          ),
          CleaningService: responseData.data.filter(
            (item) => item.types.name === "Cleaning Service"
          ),
          StagingService: responseData.data.filter(
            (item) => item.types.name === "Staging Service"
          ),
        };

        setPhotographyData(filteredData.Photography);
        setHomeTourData(filteredData.HomeTour);
        setForSaleSignData(filteredData.ForSaleSign);
        setCleaningServiceData(filteredData.CleaningService);
        setStagingServiceData(filteredData.StagingService);
        console.log(filteredData.Photography);
        console.log(filteredData.HomeTour);
        console.log(filteredData.ForSaleSign);
        console.log(filteredData.CleaningService);
        console.log(filteredData.StagingService);
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
      });
  }, []);

  return (
    <section className="bg-banner-dashborad">
      <Header />
      <div className="bg-main">
        <div className="row mx-0 position-box">
          <div className="col-sm-2 px-0">
            <Sidebar />
          </div>
          <div className="col-sm-7">
            <div className="main">
              <div>
                <h5 className="head-label">Things Left to do</h5>
                <Form>
                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault1"
                      />
                      <label
                        className="form-check-label"
                        htmlFor="flexCheckDefault1"
                      >
                        Add any special services to enhance your listing
                      </label>
                    </div>
                  </div>
                  <div className="partner-firms-heade-text mb-4 ps-4">
                    <h2>Photography</h2>
                    <div className="row">
                      {photographyData.map((item) => {
                        let buttonClass, imageClass;

                        switch (item.id) {
                          case 13:
                            buttonClass = "btn-green";
                            imageClass = arrow1;
                            break;
                          case 14:
                            buttonClass = "btn-yellow";
                            imageClass = arrow2;
                            break;
                          case 15:
                            buttonClass = "btn-red";
                            imageClass = arrow3;
                            break;
                          default:
                            buttonClass = "btn-default";
                            imageClass = arrow1;
                            break;
                        }

                        return (
                          <div className="col-sm-4" key={item.id}>
                            <button className={`btn ${buttonClass}`}>
                              <img src={imageClass} alt="" /> {item.name}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="partner-firms-heade-text mb-4 ps-4">
                    <h2>360 Home Tour</h2>
                    <div className="row">
                      {homeTourData.map((item) => {
                        let buttonClass, imageClass;

                        switch (item.id) {
                          case 16:
                            buttonClass = "btn-green";
                            imageClass = arrow1;
                            break;
                          case 17:
                            buttonClass = "btn-yellow";
                            imageClass = arrow2;
                            break;
                          case 18:
                            buttonClass = "btn-red";
                            imageClass = arrow3;
                            break;
                          case 20:
                            buttonClass = "btn-green";
                            imageClass = arrow1;
                            break;
                          default:
                            buttonClass = "btn-default";
                            imageClass = arrow1;
                            break;
                        }

                        return (
                          <div className="col-sm-4" key={item.id}>
                            <button className={`btn ${buttonClass}`}>
                              <img src={imageClass} alt="" /> {item.name}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  <div className="partner-firms-heade-text mb-4 ps-4">
                    <h2>forSaleSignData</h2>
                    <div className="row">
                      {forSaleSignData.map((item) => {
                        let buttonClass, imageClass;

                        switch (item.id) {
                          case 19:
                            buttonClass = "btn-green";
                            imageClass = arrow1;
                            break;
                          case 21:
                            buttonClass = "btn-yellow";
                            imageClass = arrow2;
                            break;

                          default:
                            buttonClass = "btn-default";
                            imageClass = arrow1;
                            break;
                        }

                        return (
                          <div className="col-sm-4" key={item.id}>
                            <button className={`btn ${buttonClass}`}>
                              <img src={imageClass} alt="" /> {item.name}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  <div className="partner-firms-heade-text mb-4 ps-4">
                    <h2>Cleaning Service</h2>
                    <div className="row">
                      {cleaningServiceData.map((item) => {
                        let buttonClass, imageClass;

                        switch (item.id) {
                          case 22:
                            buttonClass = "btn-green";
                            imageClass = arrow1;
                            break;
                          case 23:
                            buttonClass = "btn-yellow";
                            imageClass = arrow2;
                            break;
                          case 24:
                            buttonClass = "btn-red";
                            imageClass = arrow3;
                            break;
                          default:
                            buttonClass = "btn-default";
                            imageClass = arrow1;
                            break;
                        }

                        return (
                          <div className="col-sm-4" key={item.id}>
                            <button className={`btn ${buttonClass}`}>
                              <img src={imageClass} alt="" /> {item.name}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  <div className="partner-firms-heade-text mb-4 ps-4">
                    <h2>Staging Service</h2>
                    <div className="row">
                      {stagingServiceData.map((item) => {
                        let buttonClass, imageClass;

                        switch (item.id) {
                          case 25:
                            buttonClass = "btn-green";
                            imageClass = arrow1;
                            break;
                          case 26:
                            buttonClass = "btn-yellow";
                            imageClass = arrow2;
                            break;
                          case 27:
                            buttonClass = "btn-red";
                            imageClass = arrow3;
                            break;
                          default:
                            buttonClass = "btn-default";
                            imageClass = arrow1;
                            break;
                        }

                        return (
                          <div className="col-sm-4" key={item.id}>
                            <button className={`btn ${buttonClass}`}>
                              <img src={imageClass} alt="" /> {item.name}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </Form>
              </div>
            </div>
          </div>
          <div className="col-sm-3">
            <div className="sidebox-right">
              <h1>Key Documnet</h1>
              <div className="side-keydocument">
                <div className="buttonone">
                  <div className="background">
                    <img src={download2} alt="" />
                    <p className="mb-0">General Inspection Report</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon2} alt="" />
                  </div>
                </div>
                <div className="buttontwo">
                  <div className="background">
                    <img src={download1} alt="" />
                    <p className="mb-0">General Inspection Report</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon1} alt="" />
                  </div>
                </div>
                <div className="buttonthree">
                  <div className="background">
                    <img src={download} alt="" />
                    <p className="mb-0">General Inspection Report</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon} alt="" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PartnerFirms;
