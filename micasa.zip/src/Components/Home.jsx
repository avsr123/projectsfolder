import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Document, Page,pdfjs } from 'react-pdf'; 


const Home = () => {
  const [user, setUser] = useState([]);


  const handleOffer = () => {
    const accessToken = localStorage.getItem("accessToken");
    const config = {
      headers: {
        "Authorization": `Token ${accessToken}`,
        "Accept": "application/json"
      }
    };


    axios.get(`http://192.168.0.13:8000/GetPropertyListingApi/1/9/`, config)
      .then((res) => {
        setUser(res.data.property_docs);
        console.log('Images:', res.data.property_docs);
      })
      .catch((err) => {
        console.error('Error:', err);
      });
  };

  useEffect(() => {
    handleOffer();
  }, []);


  

  return (
    <div>
        {
            user.map((val,index)=>{
                return(
                    <>
                    
     
                  
                    </>
                )
            })
        }
        
       
     </div>
  );
};

export default Home;

