import React, { useState } from "react";
import Header from "./Header";
import sidelogo from "../Images/logo-micasa-deepgreen.png";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const SignUp = () => {
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    first_name: "",
    last_name: "",
    password: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSignUp = async () => {
    try {
      const response = await axios.post(
        "http://192.168.0.13:8000/RegisterApi/",
        formData
      );
      const token = response.data.token;
      localStorage.setItem("token", token);
      console.log("Signup Response:", response.data);
    } catch (error) {
      console.error("Signup Error:", error);
    }
  };

  return (
    <>
      <section className="sign-up-login">
        <div className="row mx-0 justify-content-center my-100">
          <div className="col-sm-11">
            <Header />
            <div className="bg-main-primary">
              <div className="row mx-0 align-items-center">
                <div className="col-sm-5 ps-5">
                  <div className="sign-left-box">
                    <img src={sidelogo} alt="" />
                    <h3>your AI realtor</h3>
                  </div>
                </div>
                <div className="col-sm-7 px-0">
                  <div className="right-box">
                    <div className="row mx-0 justify-content-center">
                      <div className="col-sm-8">
                        <form action="">
                          <h5 className="head-label">Sign Up</h5>
                          <div className="row mx-0">
                            <div className="mb-3 col-sm-6 ps-0">
                              <label className="form-label">Username</label>
                              <input
                                type="text"
                                className="form-control"
                                name="username"
                                value={formData.username}
                                onChange={handleInputChange}
                              />
                            </div>
                            <div className="mb-3 col-sm-6 ps-0">
                              <label className="form-label">Email</label>
                              <input
                                type="email"
                                className="form-control"
                                name="email"
                                value={formData.email}
                                onChange={handleInputChange}
                              />
                            </div>
                            <div className="mb-3 col-sm-6 ps-0">
                              <label className="form-label">First Name</label>
                              <input
                                type="text"
                                className="form-control"
                                name="first_name"
                                value={formData.first_name}
                                onChange={handleInputChange}
                              />
                            </div>
                            <div className="mb-3 col-sm-6 ps-0">
                              <label className="form-label">Last Name</label>
                              <input
                                type="text"
                                className="form-control"
                                name="last_name"
                                value={formData.last_name}
                                onChange={handleInputChange}
                              />
                            </div>
                            <div className="mb-3 col-sm-12 ps-0">
                              <label className="form-label">Password</label>
                              <input
                                type="password"
                                className="form-control"
                                name="password"
                                value={formData.password}
                                onChange={handleInputChange}
                              />
                            </div>
                            <div>
                              <button
                                type="button"
                                className="sign-in"
                                onClick={handleSignUp}
                              >
                                Sign Up
                              </button>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default SignUp;
