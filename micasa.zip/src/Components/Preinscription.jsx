import React, { useEffect, useState } from "react";
import Form from "react-bootstrap/Form";
import arrow1 from "../Images/bulb-icon-2.svg";
import arrow2 from "../Images/bulb-icon-1.svg";
import arrow3 from "../Images/bulb-icon.svg";
import download from "../Images/download.svg";
import download1 from "../Images/download-1.svg";
import download2 from "../Images/download-2.svg";
import uploadicon from "../Images/Uploadicon.svg";
import uploadicon1 from "../Images/Uploadicon-1.svg";
import uploadicon2 from "../Images/Uploadicon-2.svg";
import uploadsvg from "../Images/Uploadicon-2.svg";
import Header from "./Header";
import Sidebar from "./Sidebar";
import axios from "axios";
import BaseUrl from "../Components/BaseUrl";

const Preinscription = () => {
  const [asbatoseData, setAsbatoseData] = useState([]);
  const [inspectorData, setInspectorData] = useState([]);
  const [TermaniteData, setTermaniteData] = useState([]);
  const [checkboxChecked, setCheckboxChecked] = useState(false);
  const [checkboxChecked1, setCheckboxChecked1] = useState(false);
  const [checkboxChecked2, setCheckboxChecked2] = useState(false);
  const [checkboxChecked3, setCheckboxChecked3] = useState(false);
  const [checkboxChecked4, setCheckboxChecked4] = useState(false);
  const [checkboxChecked5, setCheckboxChecked5] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem("accessToken");

      if (token) {
        const apiUrl = BaseUrl + "/ThirdPartyTypesApi/2/";

        const config = {
          headers: {
            Authorization: `token ${token}`,
          },
        };

        try {
          const response = await axios.get(apiUrl, config);
          const responseData = response.data.data;
          console.log(responseData);
          // Filter the data based on specific names
          const filteredData = responseData.filter((item) => {
            return (
              item.types.name === "Asbatose" ||
              item.types.name === "inspector" ||
              item.types.name === "Termanite"
            );
          });

          const asbatoseData = filteredData.filter(
            (item) => item.types.name === "Asbatose"
          );
          const inspectorData = filteredData.filter(
            (item) => item.types.name === "inspector"
          );
          const TermaniteData = filteredData.filter(
            (item) => item.types.name === "Termanite"
          );

          setAsbatoseData(asbatoseData);
          setInspectorData(inspectorData);
          setTermaniteData(TermaniteData);

          console.log("Asbatose Data:", asbatoseData);
          console.log("Inspector Data:", inspectorData);
          console.log("Termanite Data:", TermaniteData);
        } catch (error) {
          console.error("Axios error:", error);
        }
      } else {
        console.error("Token not found in localStorage");
      }
    };

    fetchData();
  }, []);

  // ------------------
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedFile1, setSelectedFile1] = useState(null);
  const [selectedFile2, setSelectedFile2] = useState(null);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    setSelectedFile(file);
  };

  const handleFileChange1 = (event) => {
    const file = event.target.files[0];
    setSelectedFile1(file);
  };
  const handleFileChange2 = (event) => {
    const file = event.target.files[0];
    setSelectedFile2(file);
  };
  const handleUpload = () => {
    const token = localStorage.getItem("accessToken");

    if (token) {
      const config = {
        headers: {
          Authorization: `token ${token}`,
        },
      };
      if (selectedFile) {
        const formData = new FormData();
        formData.append("page_no", 2);
        formData.append("seller_uploaded_doc_id", 1);
        formData.append("genral_inspection", 3);
        formData.append("genral_inspection_doc", selectedFile);
        formData.append("inspection_report", 2);
        formData.append("inspection_report_doc", selectedFile1);
        formData.append("inspection_type_id", 1);
        formData.append("inspection_type_doc", selectedFile2);
        //   formData.append("upload_documents", selectedFile);

        axios
          .post(
            "http://192.168.0.13:8000/AddPreinspection/",
            formData,
            config,
            {}
          )
          .then((response) => {
            console.log(response.data);
          })
          .catch((error) => {
            console.log(error);
          });
      }
    }
  };

  // -------------------------

  const [inspectionTypes, setInspectionTypes] = useState([]);
  const [selectedType, setSelectedType] = useState("");
  const [filteredData, setFilteredData] = useState([]);

  const buttonImages = [arrow1, arrow2, arrow3];

  useEffect(() => {
    axios
      .get("http://192.168.0.13:8000/InspectionTypes/")
      .then((response) => {
        setInspectionTypes(response.data.data);
        if (response.data.data.length > 0) {
          const initialType = response.data.data[0].id;
          setSelectedType(initialType);
          fetchFilteredData(initialType);
        }
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);

  const fetchFilteredData = (typeId) => {
    if (typeId) {
      axios
        .get(`http://192.168.0.13:8000/InspectionNames/${typeId}`)
        .then((response) => {
          setFilteredData(response.data.data);
        })
        .catch((error) => {
          console.error("Error fetching filtered data:", error);
        });
    } else {
      setFilteredData([]);
    }
  };

  const handleSelectChange = (event) => {
    setSelectedType(event.target.value);
    // Fetch filtered data when an option is selected
    fetchFilteredData(event.target.value);
  };

  // -----------------------------------

  const [data, setData] = useState([]);
  const baseurl = "http://192.168.0.13:8000";

  useEffect(() => {
    const token = localStorage.getItem("accessToken");

    if (token) {
      const config = {
        headers: {
          Authorization: `token ${token}`,
        },
      };
      axios
        .get("http://192.168.0.13:8000/GetPropertyListingApi/1/2/", config)
        .then((response) => {
          setData(response.data.property_docs);
          console.log(response.data.property_docs);
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        });
    }
  }, []);

  // Create a function to filter data for "Inspector" documents
  const filterInspectorDocuments = (data) => {
    return data.filter((item) => item.document_type_name.name === "inspector");
  };

  const filterTermaniteDocuments = (data) => {
    return data.filter((item) => item.document_type_name.name === "Termanite");
  };
  const filterAsbatoseDocuments = (data) => {
    return data.filter((item) => item.document_type_name.name === "Asbatose");
  };

  return (
    <section className="bg-banner-dashborad">
      <Header />
      <div className="bg-main">
        <div className="row mx-0 position-box">
          <div className="col-sm-2 px-0">
            <Sidebar />
          </div>
          <div className="col-sm-7">
            <div className="main">
              <div>
                <h5 className="head-label">Things Left to do</h5>
                <div>
                  <div>
                    <div>
                      <div className="form-check my-4">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          value=""
                          id="flexCheckDefault1"
                          checked={checkboxChecked}
                          onChange={() => setCheckboxChecked(!checkboxChecked)}
                        />
                        <label
                          className="form-check-label"
                          htmlFor="flexCheckDefault1"
                        >
                          Choose a locally licensed General Inspector who will
                          further help you understand what necessary inspections
                          you may need for the property. Schedule with the
                          inspector a time slot from the calendar above that
                          both you and the seller are available. Make sure your
                          inspector gives you a report.
                        </label>
                      </div>

                      <fieldset className="ps-4" disabled={!checkboxChecked}>
                        <div className="row">
                          {asbatoseData.map((item) => {
                            let buttonClass, imageClass;

                            switch (item.id) {
                              case 1:
                                buttonClass = "btn-green";
                                imageClass = arrow1;
                                break;
                              case 2:
                                buttonClass = "btn-yellow";
                                imageClass = arrow2;
                                break;
                              case 3:
                                buttonClass = "btn-red";
                                imageClass = arrow3;
                                break;
                              default:
                                buttonClass = "btn-default";
                                imageClass = arrow1;
                                break;
                            }

                            return (
                              <div className="col" key={item.id}>
                                <button className={`btn ${buttonClass}`}>
                                  <img src={imageClass} alt="" /> {item.name}
                                </button>
                              </div>
                            );
                          })}
                        </div>
                      </fieldset>
                    </div>
                  </div>

                  <div>
                    <div className="form-check my-4">
                      <label className="form-check-label">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          checked={checkboxChecked1}
                          onChange={() =>
                            setCheckboxChecked1(!checkboxChecked1)
                          }
                        />
                        Upload your General Inspection Report
                      </label>
                    </div>
                    <fieldset className="ps-4" disabled={!checkboxChecked1}>
                      <img src={uploadsvg} className="upload-icon" alt="" />
                      <input
                        type="file"
                        name="upload_documents"
                        id="upload_documents"
                        onChange={handleFileChange}
                      />
                      {filterInspectorDocuments(data).map((item) => (
                        <li key={item.id}>
                          <a href={baseurl + item.upload_documents}>
                            {baseurl + item.upload_documents}
                          </a>
                          <p>{item.document_type_name.name}</p>
                        </li>
                      ))}
                    </fieldset>
                  </div>
                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault11"
                        checked={checkboxChecked3}
                        onChange={() => setCheckboxChecked3(!checkboxChecked3)}
                      />
                      <label
                        className="form-check-label"
                        htmlFor="flexCheckDefault11"
                      >
                        Obtain a Free Termite Inspection
                      </label>
                    </div>
                    <fieldset className="ps-4" disabled={!checkboxChecked3}>
                      <div className="row  ">
                        {inspectorData.map((item) => {
                          let buttonClass, imageClass;

                          switch (item.id) {
                            case 4:
                              buttonClass = "btn-green";
                              imageClass = arrow1;
                              break;
                            case 5:
                              buttonClass = "btn-yellow";
                              imageClass = arrow2;
                              break;
                            case 6:
                              buttonClass = "btn-red";
                              imageClass = arrow3;
                              break;
                            default:
                              buttonClass = "btn-default";
                              imageClass = arrow1;
                              break;
                          }

                          return (
                            <div className="col" key={item.id}>
                              <button className={`btn ${buttonClass}`}>
                                <img src={imageClass} alt="" /> {item.name}
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </fieldset>
                  </div>
                  <div>
                    <div className="form-check my-4">
                      <label className="form-check-label">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          checked={checkboxChecked2}
                          onChange={() =>
                            setCheckboxChecked2(!checkboxChecked2)
                          }
                        />
                        Upload your Termite Inspection Report
                      </label>
                    </div>
                    <fieldset className="ps-4" disabled={!checkboxChecked2}>
                      <img src={uploadsvg} className="upload-icon" alt="" />

                      <input
                        type="file"
                        name="upload_documents"
                        id="upload_documents"
                        onChange={handleFileChange1}
                      />
                      {filterTermaniteDocuments(data).map((item) => (
                        <li key={item.id}>
                          <a href={baseurl + item.upload_documents}>
                            {baseurl + item.upload_documents}
                          </a>
                          <p>{item.document_type_name.name}</p>
                        </li>
                        // You can display other properties of the item as needed
                      ))}
                    </fieldset>
                  </div>

                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault3"
                        checked={checkboxChecked4}
                        onChange={() => setCheckboxChecked4(!checkboxChecked4)}
                      />
                      <label
                        className="form-check-label"
                        htmlFor="flexCheckDefault3"
                      >
                        Now that you have your general inspection report, you
                        have a good general idea of the condition of the home.
                        You may want to perform a specialized inspection based
                        of some of the listed issues sceen on the report. Keep
                        in mind this is completely optional.
                      </label>
                    </div>
                    <div>
                      <fieldset className="ps-4" disabled={!checkboxChecked4}>
                        <div>
                          <h5 className="inscpet-type">
                            SELECT AN INSPECTION TYPE
                          </h5>
                          <div className="col-sm-4">
                            <select
                              className="form-select"
                              value={selectedType}
                              onChange={handleSelectChange}
                            >
                              {inspectionTypes.map((inspectionType) => (
                                <option
                                  key={inspectionType.id}
                                  value={inspectionType.id}
                                >
                                  {inspectionType.name}
                                </option>
                              ))}
                            </select>
                          </div>
                          {selectedType && (
                            <div>
                              {/* <h2>Filtered Data for ID {selectedType}:</h2> */}
                              <div className="row mt-3">
                                {filteredData.map((item, index) => (
                                  <div className="col" key={item.id}>
                                    <button
                                      className={`btn ${
                                        ["btn-green", "btn-yellow", "btn-red"][
                                          index % 3
                                        ]
                                      }`}
                                    >
                                      <img
                                        src={buttonImages[index % 3]}
                                        alt=""
                                      />{" "}
                                      {item.name}
                                    </button>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </fieldset>
                    </div>
                  </div>
                  <div>
                    <div className="form-check my-4">
                      <label className="form-check-label">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          checked={checkboxChecked5}
                          onChange={() =>
                            setCheckboxChecked5(!checkboxChecked5)
                          }
                        />
                        Upload your Special Inspection Report
                      </label>
                    </div>
                    <fieldset className="ps-4" disabled={!checkboxChecked5}>
                      <img src={uploadsvg} className="upload-icon" alt="" />

                      <input
                        type="file"
                        name="upload_documents"
                        id="upload_documents"
                        onChange={handleFileChange2}
                      />
                      {filterAsbatoseDocuments(data).map((item) => (
                        <li key={item.id}>
                          <a href={baseurl + item.upload_documents}>
                            {baseurl + item.upload_documents}
                          </a>
                          <p>{item.document_type_name.name}</p>
                        </li>
                        // You can display other properties of the item as needed
                      ))}
                    </fieldset>
                  </div>
                </div>
                <div className="text-center">
                  <button
                    className="mt-4 sign-in"
                    type="button"
                    onClick={handleUpload}
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-3">
            <div className="sidebox-right">
              <h1>Key Documnet</h1>
              <div className="side-keydocument">
                <div className="buttonone">
                  {filterInspectorDocuments(data).map((item) => (
                    <a href={baseurl + item.upload_documents}>
                      <div className="background">
                        <img src={download2} alt="" />
                        <p className="mb-0">General Inspection Report</p>
                      </div>
                    </a>
                  ))}

                  <div className="upload-button">
                    <img src={uploadicon2} alt="" />
                  </div>
                </div>
                <div className="buttontwo">
                  {filterTermaniteDocuments(data).map((item) => (
                    <a href={baseurl + item.upload_documents}>
                      <div className="background">
                        <img src={download1} alt="" />
                        <p className="mb-0">Termite Inspection Report</p>
                      </div>
                    </a>
                  ))}

                  <div className="upload-button">
                    <img src={uploadicon1} alt="" />
                  </div>
                </div>
                <div className="buttonthree">
                  {filterAsbatoseDocuments(data).map((item) => (
                    <a href={baseurl + item.upload_documents}>
                      <div className="background">
                        <img src={download} alt="" />
                        <p className="mb-0">Special Inspection Report</p>
                      </div>
                    </a>

                    // You can display other properties of the item as needed
                  ))}

                  <div className="upload-button">
                    <img src={uploadicon} alt="" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Preinscription;
