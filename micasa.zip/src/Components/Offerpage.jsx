import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Sidebar from "./Sidebar";
import Header from "./Header";
import download2 from "../Images/download-2.svg";
import uploadicon1 from "../Images/Uploadicon-1.svg";

const Offerpage = () => {
  const paramName = useParams();
  const paramId = paramName.id;
  console.log(paramId);

  const [userdata, setUserdata] = useState([]);

  const handleOffer = () => {
    const accessToken = localStorage.getItem("accessToken");
    const config = {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Token ${accessToken}`,
        Accept: "application/json",
      },
    };

    axios
      .get(`http://192.168.0.13:8000/GetOfferApi/${paramId}/`, config)
      .then((res) => {
        setUserdata(res.data.data);
        console.log("Response:", res.data.data);
      })
      .catch((err) => {
        console.error("Error:", err);
      });
  };

  useEffect(() => {
    handleOffer();
  }, [paramName]);

  return (
    <section className="bg-banner-dashborad">
      <Header />
      <div className="bg-main">
        <div className="row mx-0 position-box">
          <div className="col-sm-2 px-0">
            <Sidebar />
          </div>
          <div className="col-sm-7">
            <div className="main">
              <div>
                <h5 className="head-label">Things Left to do</h5>
                <div>
                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault1"
                      />
                      <label
                        className="form-check-label"
                        htmlFor="flexCheckDefault1"
                      >
                        <i>
                          Offers: Review all your offers for X (property
                          address)
                        </i>
                      </label>
                    </div>
                  </div>
                  <div>
                    {userdata?.map((val, index) => {
                      return (
                        <div className="col-sm-4">
                          <div className="ooferpage-details">
                            <ul key={index}>
                              <li>Agent Name:</li>
                              <li>Email:</li>
                              <li>Phone Number:</li>
                              <li>License Number:</li>
                              <li>Price</li>
                              <li className="my-3">
                                <div className="buttonone d-block">
                                  <div className="background gap-3">
                                    <img src={download2} alt="" />
                                    <p className="mb-0">View offer</p>
                                  </div>
                                </div>
                              </li>
                              <li className="my-3">
                                <div className="buttontwo">
                                  <div className="background d-flex align-items-center gap-3">
                                    <img src={uploadicon1} alt="" />
                                    <p className="mb-0">
                                      Respond to Offer (sco)
                                    </p>
                                  </div>
                                  <div className="upload-button"></div>
                                </div>
                              </li>
                              <li> <u> initial Deposit </u></li>
                              {val.initial_deposite}
                              <li> <u> Finance type </u></li>
                              {val.finance_type}
                              <li> <u> Loan amount  </u></li>
                              {val.loan_amount}
                              <li> <u> Percent Down </u></li>
                              <li> <u> Down payment </u></li>
                              <li> <u> Down payment balance </u></li>
                              <li> <u> Finance Contingency </u></li>
                              {val.no_finance_contingency}
                              <li> <u> Appraisal Contingency </u></li>
                              {val.appraisal_contingency}
                              <li> <u> inspection contingency </u></li>
                              {val.no_inspection_contingency}
                              <li> <u> Homesale Contingency </u></li>
                              {val.homesale_contingency}
                              <li> <u> Close Of Escrow </u></li>
                              {val.days_to_close_of_escrow}
                              <li> <u> Submitted on </u></li>
                              <li> <u> Special Terms </u></li>
                              {val.special_terms}
                            </ul>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-3">
            <div className="sidebox-right">
              <h1>Key Documnet</h1>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Offerpage;
