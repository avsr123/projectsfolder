const BaseUrl = "http://192.168.0.13:8000";

export default BaseUrl;