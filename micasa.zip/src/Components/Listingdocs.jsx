import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import arrow1 from "../Images/bulb-icon-2.svg";
import arrow2 from "../Images/bulb-icon-1.svg";
import arrow3 from "../Images/bulb-icon.svg";
import download from "../Images/download.svg";
import download1 from "../Images/download-1.svg";
import download2 from "../Images/download-2.svg";
import uploadicon from "../Images/Uploadicon.svg";
import uploadicon1 from "../Images/Uploadicon-1.svg";
import uploadicon2 from "../Images/Uploadicon-2.svg";

import Header from "./Header";
import Sidebar from "./Sidebar";
const Listingdocs = () => {
  return (
    <section className="bg-banner-dashborad">
      <Header />
      <div className="bg-main">
        <div className="row mx-0 position-box">
          <div className="col-sm-2 px-0">
            <Sidebar />
          </div>
          <div className="col-sm-7">
            <div className="main">
              <div>
                <h5 className="head-label">Things Left to do</h5>
                <Form>
                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault1"
                      />
                      <label className="form-check-label" htmlFor="flexCheckDefault1">
                        Based off of seller preliminary questionnaire, you must
                        fill out the appropriate disclosure documents through
                        Docusign, These documents will later be sent to a buyer
                        who has made an offer on your property, informing them
                        the condition of property, etc
                      </label>
                      <label>
                        <b>
                          Be sure to be truthful when filling out the Disclosure
                          Package
                        </b>
                      </label>
                    </div>
                  </div>
                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault4"
                      />
                      <label className="form-check-label" htmlFor="flexCheckDefault4">
                        Accept our Brokerage/Escrow Relationship Disclosure
                      </label>
                    </div>
                    <div className="upload-file ps-4">
                      <label htmlFor="filetype">
                        {" "}
                        <svg
                          width="48"
                          height="48"
                          viewBox="0 0 48 48"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <mask
                            id="mask0_106_3038"
                            maskUnits="userSpaceOnUse"
                            x="0"
                            y="0"
                            width="48"
                            height="48"
                          >
                            <circle cx="24" cy="24" r="24" fill="#D9D9D9" />
                          </mask>
                          <g mask="url(#mask0_106_3038)">
                            <circle cx="24" cy="24" r="24" fill="#408F81" />
                            <path
                              d="M16.1999 33.5999C15.7199 33.5999 15.2999 33.4199 14.9399 33.0599C14.5799 32.6999 14.3999 32.2799 14.3999 31.7999V27.5099H16.1999V31.7999H31.7999V27.5099H33.5999V31.7999C33.5999 32.2799 33.4199 32.6999 33.0599 33.0599C32.6999 33.4199 32.2799 33.5999 31.7999 33.5999H16.1999ZM23.0999 29.0099V17.8799L19.4999 21.4799L18.2099 20.1899L23.9999 14.3999L29.7899 20.1899L28.4999 21.4799L24.8999 17.8799V29.0099H23.0999Z"
                              fill="white"
                            />
                          </g>
                        </svg>
                      </label>

                      <input type="file" id="filetype" />
                    </div>
                  </div>
                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault1"
                      />
                      <label className="form-check-label" htmlFor="flexCheckDefault1">
                        Select the escrow company you want to work with
                      </label>
                    </div>
                    <div className="row ps-4">
                      <div className="col pe-0">
                        <button className="btn btn-green  ">
                          <img src={arrow1} alt="" /> ABC Escrow
                        </button>
                      </div>
                      <div className="col pe-0">
                        <button className="btn btn-yellow  ">
                          <img src={arrow2} alt="" /> Angelo Escrow
                        </button>
                      </div>
                      <div className="col pe-0">
                        <button className="btn btn-red  ">
                          <img src={arrow3} alt="" /> Termite Escrow
                        </button>
                      </div>
                    </div>
                  </div>
                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault4"
                      />
                      <label className="form-check-label" htmlFor="flexCheckDefault4">
                        Upload your Termite Inspection Report
                      </label>
                    </div>
                    <div className="upload-file ps-4">
                      <label htmlFor="filetype">
                        {" "}
                        <svg
                          width="48"
                          height="48"
                          viewBox="0 0 48 48"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <mask
                            id="mask0_106_3038"
                            maskUnits="userSpaceOnUse"
                            x="0"
                            y="0"
                            width="48"
                            height="48"
                          >
                            <circle cx="24" cy="24" r="24" fill="#D9D9D9" />
                          </mask>
                          <g mask="url(#mask0_106_3038)">
                            <circle cx="24" cy="24" r="24" fill="#408F81" />
                            <path
                              d="M16.1999 33.5999C15.7199 33.5999 15.2999 33.4199 14.9399 33.0599C14.5799 32.6999 14.3999 32.2799 14.3999 31.7999V27.5099H16.1999V31.7999H31.7999V27.5099H33.5999V31.7999C33.5999 32.2799 33.4199 32.6999 33.0599 33.0599C32.6999 33.4199 32.2799 33.5999 31.7999 33.5999H16.1999ZM23.0999 29.0099V17.8799L19.4999 21.4799L18.2099 20.1899L23.9999 14.3999L29.7899 20.1899L28.4999 21.4799L24.8999 17.8799V29.0099H23.0999Z"
                              fill="white"
                            />
                          </g>
                        </svg>
                      </label>

                      <input type="file" id="filetype" />
                    </div>
                  </div>

                  <div>
                    <div className="form-check my-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value=""
                        id="flexCheckDefault3"
                      />
                      <label className="form-check-label" htmlFor="flexCheckDefault3">
                        Now that you have your general inspection report, you
                        have a good general idea of the condition of the home.
                        You may want to perform a specialized inspection based
                        of some of the listed issues sceen on the report. Keep
                        in mind this is completely optional.
                      </label>
                      <div className="mt-3">
                        <label htmlFor="formGridState" className="form-label">
                          <b> SELECT AN INSPECTION TYPE</b>
                        </label>
                        <select className="form-select" id="formGridState">
                          <option selected>Choose...</option>
                          <option>...</option>
                        </select>
                      </div>
                    </div>
                    <div className="row ps-4">
                      <div className="col pe-0">
                        <button className="btn btn-green  ">
                          <img src={arrow1} alt="" /> ABC Asbestos
                        </button>
                      </div>
                      <div className="col pe-0">
                        <button className="btn btn-yellow  ">
                          <img src={arrow2} alt="" /> Angelo Asbestos Group
                        </button>
                      </div>
                      <div className="col pe-0">
                        <button className="btn btn-red  ">
                          <img src={arrow3} alt="" /> Asbestos Daily
                        </button>
                      </div>
                    </div>
                  </div>
                </Form>
              </div>
            </div>
          </div>
          <div className="col-sm-3">
            <div className="sidebox-right">
              <h1>Key Documnet</h1>
              <div className="side-keydocument">
                <div className="buttonone">
                  <div className="background">
                    <img src={download2} alt="" />
                    <p className="mb-0">SBSA: Statewide Buyer and Seller Advisory</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon2} alt="" />
                  </div>
                </div>
                <div className="buttontwo">
                  <div className="background">
                    <img src={download1} alt="" />
                    <p className="mb-0">SPQ: Seller Property Questionnaire</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon1} alt="" />
                  </div>
                </div>
                <div className="buttonthree">
                  <div className="background">
                    <img src={download} alt="" />
                    <p className="mb-0">TDS: Transfer Disclosure Statement</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon} alt="" />
                  </div>
                </div>
                <div className="buttonone">
                  <div className="background">
                    <img src={download2} alt="" />
                    <p className="mb-0">WCCM: Water Conserving Carbon Monoxide</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon2} alt="" />
                  </div>
                </div>
                <div className="buttontwo">
                  <div className="background">
                    <img src={download1} alt="" />
                    <p className="mb-0">WHSD: Water Heater and Smoke Detector</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon1} alt="" />
                  </div>
                </div>
                <div className="buttonthree">
                  <div className="background">
                    <img src={download} alt="" />
                    <p className="mb-0">EHD: Earthquake Hazards Disclosure</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon} alt="" />
                  </div>
                </div>
                <div className="buttonone">
                  <div className="background">
                    <img src={download2} alt="" />
                    <p className="mb-0">EEBR: Earthquake / Environmental Booklet Receipt</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon2} alt="" />
                  </div>
                </div>
                <div className="buttontwo">
                  <div className="background">
                    <img src={download1} alt="" />
                    <p className="mb-0">LPD: Lead-based Paint Disclosure</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon1} alt="" />
                  </div>
                </div>
                <div className="buttonthree">
                  <div className="background">
                    <img src={download} alt="" />
                    <p className="mb-0">MCA: Market Condition Advisory</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon} alt="" />
                  </div>
                </div>
                <div className="buttonone">
                  <div className="background">
                    <img src={download2} alt="" />
                    <p className="mb-0">Agent Visual Inspection Disclosure</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon2} alt="" />
                  </div>
                </div>
                <div className="buttontwo">
                  <div className="background">
                    <img src={download1} alt="" />
                    <p className="mb-0">Broker / Escrow Relationship Disclosure</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon1} alt="" />
                  </div>
                </div>
                <div className="buttonthree">
                  <div className="background">
                    <img src={download} alt="" />
                    <p className="mb-0">Prelimary Title Report</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon} alt="" />
                  </div>
                </div>
                <div className="buttonone">
                  <div className="background">
                    <img src={download2} alt="" />
                    <p className="mb-0">Statement of Information</p>
                  </div>
                  <div className="upload-button">
                    <img src={uploadicon2} alt="" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Listingdocs;
