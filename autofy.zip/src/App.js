import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import "./Responsive.css";
import Home from "./Components/Home";
import Header from "./Components/Header";
import About from "./Components/About";
import Howitworks from "./Components/Howitworks";
import Blog from "./Components/Blogs";
import Contact from "./Components/Contact";
import Footer from "./Components/Footer";
import BlogDetail from "./Components/BlogDetails";
import Headtop from "./Components/Headtop";
import Faq from "./Components/Faq";

function App() {
  return (
    <>
      {/* <ToastContainer></ToastContainer> */}

      <BrowserRouter>
        <Headtop />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/howitworks" element={<Howitworks />} />
          <Route path="/blogs" element={<Blog />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/faqs" element={<Faq />} />

          <Route path="/blogdetails/:blog_id" element={<BlogDetail />} />

        </Routes>
        <Footer />
      </BrowserRouter>
    </>
  );
}

export default App;
