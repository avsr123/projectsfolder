export const warn1 = require("../Images/Rectangle 68.png");
export const aboutcar = require("../Images/5 1.png");
export const logo = require("../Images/logo.png");
export const review1 = require("../Images/Ellipse 7.png");
export const review2 = require("../Images/Ellipse 7-1.png");
export const review3 = require("../Images/Ellipse 7-2.png");
export const certificate1 = require("../Images/Rectangle 71.png");
export const certificate2 = require("../Images/Rectangle 72.png");
export const logofooter = require("../Images/Group 791.png");

