import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { Modal } from "react-bootstrap";
import axios from "axios";
import Headers from "./Headers";

const Contact = () => {
  const navigate = useNavigate();

  const [first_name, setFirstName] = useState("");
  const [last_name, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [showModal, setShowModal] = useState(false);

  const resetFormFields = () => {
    setFirstName("");
    setLastName("");
    setEmail("");
    setSubject("");
    setMessage("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post(
        `https://autofyus.com/admin/public/api/contact`,
        {
          first_name,
          last_name,
          email,
          subject,
          message,
        }
      );

      if (response.data.status === 1) {
        toast.success("Successful");
        setShowModal(true); // Show the modal
      }
    } catch (error) {
      console.error("An error occurred:", error);
    }
  };

  const handleModalClose = () => {
    setShowModal(false); // Close the modal
    resetFormFields(); // Reset form fields
  };

  return (
    <>
    <Headers />

      <section className="mx-lg-5 mt-lg-5">
        <div className="row m-3">
          <div className="col-lg-5 
 col-md-12">
            <div className="about-box">
              <h4>Contact US</h4>
              <p>
                We're here to assist you with any questions, inquiries, or
                assistance you may need. Feel free to get in touch with us
                through the following contact options:
              </p>
            </div>
            <div className="position-relative mt-lg-5 mt-4">
              <div className="one-line"></div>
              <div className="two-line"></div>
            </div>
          </div>
        </div>
      </section>
      <div className="container mb-5">
        <div className="row pb-5 justify-content-around">
          <div className="col-sm-5 my-5 pt-lg-5">
            <div className="head-box-text mb-5">
              <div>
                <p>Customer Service Phone:</p>
                <h3>Phone Number: <a href="tel:894561230"> (123) 456-7890 </a></h3>
                <h5>
                  Our dedicated customer service team is available to assist you
                  during our business hours. Whether you have questions about
                  our inventory, need support with financing, or require
                  information on our services, we're just a phone call away.
                </h5>
              </div>
            </div>
            <div className="head-box-text mb-5">
              <div>
                <p>Email Support:</p>
                <h3>Email Address:  <a href="mailto:abc@example.com"> info@autofyontario.com </a></h3>
                <h5>
                  You can also reach us via email for inquiries or assistance.
                  Our team will respond promptly to your messages and provide
                  you with the information you need.
                </h5>
              </div>
            </div>
            <div className="head-box-text mb-5">
              <div>
                <h3>Visit Our Locations:</h3>
                <h5>
                  We have multiple convenient locations across Ontario, where
                  you can explore our inventory, schedule a test drive, or speak
                  with our team in person. To find the nearest branch and its
                  address, please visit our [Locations Page](link to your
                  locations page).
                </h5>
              </div>
            </div>
          </div>

          <div className="col-sm-5">
            <form onSubmit={handleSubmit} className="contact-form">
              <div className="head-box-text-1 mb-5">
                <h3 className="mb-lg-4">Submit a Question</h3>
                <p className="mb-lg-5">
                  Submit a question through our contact form below and we'll get
                  back to you as soon as possible.
                </p>
              </div>

              <div className="form-group mb-4">
                <label htmlFor="firstName">First Name</label>
                <input
                  type="text"
                  className="form-control"
                  id="firstName"
                  onChange={(e) => setFirstName(e.target.value)}
                />
              </div>
              <div className="form-group mb-4">
                <label htmlFor="lastName">Last Name</label>
                <input
                  type="text"
                  className="form-control"
                  id="lastName"
                  onChange={(e) => setLastName(e.target.value)}
                />
              </div>
              <div className="form-group mb-4">
                <label htmlFor="email">Email</label>
                <input
                  type="email"
                  className="form-control"
                  id="email"
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div className="form-group mb-4">
                <label htmlFor="helpWith">What can we help you with?</label>
                <input
                  type="text"
                  className="form-control"
                  id="helpWith"
                  onChange={(e) => setSubject(e.target.value)}
                />
              </div>
              <div className="form-group mb-4">
                <label htmlFor="message">Message</label>
                <textarea
                  className="form-control"
                  id="message"
                  rows="4"
                  onChange={(e) => setMessage(e.target.value)}
                ></textarea>
              </div>
              <div className="text-center text-lg-start">
                <button
                  className=""
                  onClick={handleSubmit}
                  type="submit"
                >
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
        <Modal show={showModal} onHide={handleModalClose} centered>
          <Modal.Header closeButton>
            <Modal.Title>Success</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <h4>
              Your information has been recorded, our team will connect with you
              shortly.
            </h4>
          </Modal.Body>
          <Modal.Footer>
            <a
              className="btn btn-success"
              href="/contact"
              onClick={handleModalClose}
            >
              Okay
            </a>
          </Modal.Footer>
        </Modal>
      </div>
    </>
  );
};

export default Contact;
