import axios from "axios";
import React, { useEffect, useState } from "react";
import parse from "html-react-parser";
import Headers from "./Headers";
import { Accordion } from "react-bootstrap";

const Howitworks = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPlaying1, setIsPlaying1] = useState(false);

  const togglePlay1 = () => {
    const videos = document.querySelectorAll(".video-element1");
    videos.forEach((video) => {
      if (video.paused) {
        video.play();
      } else {
        video.pause();
      }
    });

    setIsPlaying1(!isPlaying1);
  };
  const [data1, setdata1] = useState([]);
  const [data4, setdata4] = useState([]);
  const fetchData1 = async () => {
    const response = await axios.get(
      `https://autofyus.com/admin/public/api/howitwork`
    );
    setdata1(response.data.result);
    console.log(response.data.result);
  };

  const fetchData4 = async () => {
    const response = await axios.get(
      "https://autofyus.com/admin/api/how_section"
    );
    setdata4(response.data.result);
    console.log(response.data.result);
  };

  useEffect(() => {
    fetchData1();

    fetchData4();
  }, []);
  return (
    <>
      <Headers />

      <section className="mx-lg-5 mt-lg-5">
        <div className="row">
          <div
            className="col-lg-5 
 col-md-12"
          >
            <div className="about-box">
              <h4>How it Works?</h4>
              <p>
                At Autofy, we've simplified the process of buying and selling
                used cars in Ontario to ensure a smooth and hassle-free
                experience for our customers.
              </p>
            </div>
            <div className="position-relative mt-lg-5 mt-4">
              <div className="one-line"></div>
              <div className="two-line"></div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-lg-5 ">
        <div className="row mb-5">
          <>
            <div className="col-sm-6 mt-lg-5 mt-3  ">
              <Accordion className="how-its-works">
                {data1.map((accordion, index) => (
                  <Accordion.Item eventKey={accordion.id}>
                    <Accordion.Header>{accordion.title}</Accordion.Header>
                    <Accordion.Body>{parse(accordion.content)}</Accordion.Body>
                  </Accordion.Item>
                ))}
              </Accordion>
            </div>
            <div className="col-sm-6" id="how_it_work">
              {data4.map((accordion, index) => (
                <div className="video-container" key={index}>
                  <video className="video-element1" muted playsInline>
                    <source src={accordion.file} type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>

                  <div
                    className={`video-button ${isPlaying ? "pause" : "play"}`}
                    onClick={togglePlay1}
                  >
                    {isPlaying1 ? (
                      <span
                        role="img"
                        aria-label="Pause"
                        className="pause-icon"
                      >
                        &#10074;&#10074;
                      </span>
                    ) : (
                      <span role="img" aria-label="Play" className="play-icon">
                        <svg
                          width="39"
                          height="48"
                          viewBox="0 0 59 68"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M59 34L0.499997 67.775L0.5 0.225007L59 34Z"
                            fill="#ffffff"
                          />
                        </svg>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </>
        </div>
      </section>
    </>
  );
};

export default Howitworks;
