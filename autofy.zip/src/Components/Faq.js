import React, { useEffect, useState } from "react";
import Headers from "./Headers";
import { Accordion } from "react-bootstrap";
import axios from "axios";

const Faq = () => {
  const [faqData, setFaqData] = useState([]);
  useEffect(() => {
    const fetchFaqData = async () => {
      try {
        const response = await axios.get("https://autofyus.com/admin/api/faq");
        setFaqData(response.data.result);
      } catch (error) {
        console.error("Error fetching FAQ data:", error);
      }
    };

    fetchFaqData();
  }, []);
  return (
    <>
      <Headers />

      <section className="mx-lg-5 mt-lg-5 ">
        <div className="row m-3">
          <div className="col-lg-5 
 col-md-12">
            <div className="about-box">
              <h4>FAQ's</h4>
              <p>
                Welcome to the Autofy , Some frequently asked questions (FAQs)
                and their answers
              </p>
            </div>
            <div className="position-relative mt-lg-5 mt-4">
              <div className="one-line"></div>
              <div className="two-line"></div>
            </div>
          </div>
        </div>
      </section>

      <section className="mb-100 frequentquestion">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-sm-10 mt-5">
              <Accordion className="mb-5">
                {faqData.map((faqItem, index) => (
                  <Accordion.Item key={index} eventKey={index.toString()}>
                    <Accordion.Header>{faqItem.title}</Accordion.Header>
                    <Accordion.Body>{faqItem.content}</Accordion.Body>
                  </Accordion.Item>
                ))}
              </Accordion>
              <div className="text-center">
                <a href="/">
                  <button className="viewmore mt-3">View more</button>{" "}
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Faq;
