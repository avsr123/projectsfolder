import React from "react";

const Headtop = () => {
  return (
    <div className="headtop">
      <p>New deals every week.</p>
    </div>
  );
};

export default Headtop;
