import React, { useEffect, useState } from "react";
import { aboutcar } from "./imgUrl";
import aboutautofy1 from "../Images/Group-1.svg";
import aboutautofy2 from "../Images/Group-2.svg";
import aboutautofy3 from "../Images/Group.svg";
import Headers from "./Headers";
import axios from "axios";
import HTMLReactParser from "html-react-parser";
const About = () => {
  const [aboutData, setAboutData] = useState([]);

  useEffect(() => {
    // Fetch data from the API and set it to the 'aboutData' state.
    const fetchData = async () => {
      try {
        const response = await axios.get(
          "https://autofyus.com/admin/api/about"
        );
        setAboutData(response.data.result);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);
  return (
    <>
      <Headers />
      <section className="mx-lg-5 my-lg-5 ">
        <div className="row">
          <div
            className="col-lg-5 col-md-12">
            <div className="about-box">
              <h4>About Us</h4>
              <p>
                Welcome to Autofy, your trusted destination for buying and
                selling used cars in Ontario. At Autofy, we're not just in the
                business of cars; we're in the business of delivering
                exceptional experiences.
              </p>
            </div>
            <div className="position-relative mt-lg-5 mt-4">
              <div className="one-line"></div>
              <div className="two-line"></div>
            </div>
          </div>
        </div>
      </section>

      <section className="mb-100">
        <div className="container">
          {aboutData.map((item, index) => (
            <div className="row justify-content-evenly parase-about">
              {HTMLReactParser(item.content)}
            </div>
          ))}
        </div>
      </section>

      <section className="mb-100 mx-lg-5">
        <div className="row">
          <div className="col-sm-6 mb-5">
            <div className="about-abnner-box-2">
              <div>
                <span>Coming Soon</span>
                <h2 className="mt-2">Financing Options</h2>
                <p className="mt-3">
                  Flexible financing options tailored to your budget and needs.
                </p>
                <button>Learn More</button>
              </div>
            </div>
          </div>
          <div className="col-sm-6 mb-5">
            <div className="about-abnner-box-1">
              <div>
                <h2>Get a Free Car Quote in Minutes</h2>
                <p className="mt-3">
                  No more waiting in line. We bring it to you." This appeals to
                  people who are looking for a convenient and hassle-free
                  shopping experience.
                </p>
                <button>Get A Quote</button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;