import React, { useEffect, useState } from "react";
import choose1 from "../Images/Group 742.svg";
import choose2 from "../Images/Group 743-2.svg";
import choose3 from "../Images/Group 743-5.svg";
import choose4 from "../Images/Group 743.svg";
import choose5 from "../Images/Group 743-3.svg";
import choose6 from "../Images/Group 743-6.svg";
import choose7 from "../Images/Group 743-1.svg";
import choose8 from "../Images/Group 743-4.svg";
import choose9 from "../Images/Group 743-7.svg";
import {
  certificate1,
  certificate2,
  review1,
  review2,
  review3,
  warn1,
} from "./imgUrl";
import OwlCarousel from "react-owl-carousel";
import { Accordion } from "react-bootstrap";
import Header from "./Header";
import axios from "axios";
import CountUp from "react-countup";
import { Link } from "react-router-dom";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";

import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const Home = () => {
  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToScroll: 3,
    slidesToShow: 3, // Number of items to show at once

    responsive: [
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  const [displayedData, setDisplayedData] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [faqData, setFaqData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          "https://autofyus.com/admin/public/api/blogs"
        );
        setDisplayedData(response.data.result.slice(0, 3));
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const response = await axios.get(
          "https://autofyus.com/admin/api/customer_review"
        );
        setReviews(response.data.result); // Assuming the API response is an array of reviews
      } catch (error) {
        console.error("Error fetching reviews:", error);
      }
    };

    fetchReviews();
  }, []);

  useEffect(() => {
    const fetchFaqData = async () => {
      try {
        const response = await axios.get("https://autofyus.com/admin/api/faq");
        setFaqData(response.data.result);
      } catch (error) {
        console.error("Error fetching FAQ data:", error);
      }
    };

    fetchFaqData();
  }, []);

  return (
    <>
      <Header />
      <section className="main-banner mb-100">
        <div className="container-lg">
          <div className="row">
            <div className="col-sm-5">
              <h3 className="mb-5">
                Your Destination for Quality Used Cars in Ontario.
              </h3>
              <button>Find Your Dream Car!</button>
            </div>
          </div>
        </div>
      </section>
      <section className="mb-100">
        <div className="container-lg">
          <h2 className="choose-head">Why Choose Autofy?</h2>
          <div className="row">
            <div className="col-sm-6 col-lg-4 mb-lg-5 mb-3">
              <div className="choose-autofy">
                <div>
                  <img src={choose1} alt="" />
                </div>
                <div>
                  <h4>Quality Selection</h4>
                  <p>
                    Autofy offers a premium selection of used cars, rigorously
                    inspected for quality.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-sm-6 col-lg-4 mb-lg-5 mb-3">
              <div className="choose-autofy">
                <div>
                  <img src={choose2} alt="" />
                </div>
                <div>
                  <h4>Transparent History</h4>
                  <p>
                    We provide comprehensive vehicle history reports for full
                    transparency.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-sm-6 col-lg-4 mb-lg-5 mb-3">
              <div className="choose-autofy">
                <div>
                  <img src={choose3} alt="" />
                </div>
                <div>
                  <h4>Competitive Pricing</h4>
                  <p>
                    Our prices are competitive, offering value without
                    compromising quality.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-sm-6 col-lg-4 mb-lg-5 mb-3">
              <div className="choose-autofy">
                <div>
                  <img src={choose4} alt="" />
                </div>
                <div>
                  <h4>Financing Options</h4>
                  <p>
                    Flexible financing options tailored to your budget and
                    needs.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-sm-6 col-lg-4 mb-lg-5 mb-3">
              <div className="choose-autofy">
                <div>
                  <img src={choose5} alt="" />
                </div>
                <div>
                  <h4>Warranty and Protection</h4>
                  <p>
                    Extra peace of mind with our warranty and protection plans.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-sm-6 col-lg-4 mb-lg-5 mb-3">
              <div className="choose-autofy">
                <div>
                  <img src={choose6} alt="" />
                </div>
                <div>
                  <h4>Dedicated Customer Service</h4>
                  <p>
                    Our team is ready to assist you at every step of your buying
                    journey.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-sm-6 col-lg-4 mb-lg-5 mb-3">
              <div className="choose-autofy">
                <div>
                  <img src={choose7} alt="" />
                </div>
                <div>
                  <h4>Trade-In and Consignment</h4>
                  <p>Easy options for selling your current vehicle.</p>
                </div>
              </div>
            </div>
            <div className="col-sm-6 col-lg-4 mb-lg-5 mb-3">
              <div className="choose-autofy">
                <div>
                  <img src={choose8} alt="" />
                </div>
                <div>
                  <h4>Expert Knowledge</h4>
                  <p>
                    Count on our automotive experts for guidance and advice.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-sm-6 col-lg-4 mb-lg-5 mb-3">
              <div className="choose-autofy">
                <div>
                  <img src={choose9} alt="" />
                </div>
                <div>
                  <h4>Community Trust</h4>
                  <p>Autofy has earned trust within the Ontario community.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mb-100">
        <div className="mx-xl-5">
          <div className="row align-items-center bg-grey">
            <div className="col-lg-6 col-md-12 col-sm-12 px-0 h-100vh">
              <img src={warn1} className="img-fluid mb-4" alt="" />
            </div>
            <div className="col-lg-6 col-md-12 col-sm-12 d-grid px-lg-5 ">
              <div className="warnaty-card">
                <p>Drive with Confidence, Backed by Autofy</p>
                <h2 className="mb-xl-2">Warranty and Protection</h2>
                <h6 className="mb-xl-5">
                  At Autofy, we understand that buying a used car involves trust
                  and peace of mind. That's why we offer comprehensive warranty
                  and protection plans designed to safeguard your investment and
                  provide worry-free ownership.
                </h6>
                <button>Get A Quote</button>
              </div>
              <div className="counter-section mt-lg-5 pe-lg-5 ">
                <div className="row justify-content-between">
                  <div className=" col-xs-4 col-lg-auto col-md-auto col-sm-4">
                    <div></div>
                    <div>
                      <p>Car Delivered</p>
                      <h2>
                        {" "}
                        <CountUp
                          start={0}
                          end={102}
                          duration={2}
                          separator=","
                          decimal="."
                        />
                        +
                      </h2>
                    </div>
                  </div>
                  <div className=" col-xs-4 col-lg-auto col-md-auto col-sm-4">
                    <div>
                      <p>Total Engagement</p>
                      <h2>
                        {" "}
                        <CountUp
                          start={0}
                          end={110}
                          duration={2}
                          separator=","
                          decimal="."
                        />
                        +
                      </h2>
                    </div>
                  </div>
                  <div className=" col-xs-4 col-lg-auto col-md-auto col-sm-4">
                    <div>
                      <p>Successful</p>
                      <h2>
                        {" "}
                        <CountUp
                          start={0}
                          end={92.7}
                          duration={2}
                          separator=","
                          decimal="."
                        />
                        %
                      </h2>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mb-100 mx-lg-5">
        <div className="row align-items-center">
          <div className="col-sm-3 ps-lg-0">
            <div className="review-head pe-lg-5 ">
              <h5>Reviews</h5>
              <p className="mb-1">
                Our team is ready to assist you at every step of your buying
                journey.
              </p>
              <h2 className="mb-3">Great</h2>
              <div className="mb-4">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
              </div>
              <h4>Based on 200 reviews See some of the reviews here</h4>
            </div>
          </div>
          <div className="col-sm-9 px-0">
            <div className="review-box">
              <Slider {...sliderSettings}>
                {reviews.map((review, index) => (
                  <div class="item">
                    <div className="review-user mb-3">
                      <div>
                        <img src={review.image} alt="" />
                      </div>
                      <div>
                        <h5 className="mb-0">{review.name}</h5>
                        <p className="mb-0">{review.place}</p>
                      </div>
                    </div>
                    <p>{review.review}</p>
                    <div className="mb-4">
                      {Array.from({ length: review.rating }, (_, i) => (
                        <i className="fas fa-star" key={i}></i>
                      ))}
                    </div>
                  </div>
                ))}
              </Slider>
            </div>
          </div>
        </div>
      </section>

      <section className="mb-100 bg-box-head py-5 py-lg-0">
        <div className="row mx-lg-5 align-items-center ">
          <div className="col-sm-5 px-lg-0 ps-lg-0">
            {/* React Component */}
            {displayedData.length > 0 && (
              <div className="certifcate-head">
                <a href="/blogs">
                  <div className="row align-items-center  px-lg-0 mb-3 mb-lg-0">
                    <div className="col-sm-6   order-1 order-lg-0 px-0 px-lg-3">
                      <h3 className="mb-3">{displayedData[0].title}</h3>
                      <p>{displayedData[0].content}</p>
                      <a href={`/blogs`} className=" d-lg-none">Read more</a>

                    </div>
                    <div className="col-sm-6 overlay-container px-0">
                      <img
                        src={displayedData[0].blog_image}
                        className="blog-first-image"
                        alt=""
                      />
                      <div className="overlay">
                        <a href={`/blogs`}>Read more</a>
                      </div>
                    </div>
                  </div>
                </a>
              </div>
            )}
          </div>
          <div className="col-sm-7 px-0">
            <div className="row ">
              {displayedData.slice(1).map((item, index) => (
                <div className="col-sm-6 px-lg-3  mb-3" key={index}>
                  <a href={`/blogdetails/${item.blog_id}`}>
                    <div className="creticate-blog-box">
                      <img
                        src={item.blog_image}
                        className="img-fluid mb-4"
                        alt=""
                      />
                      <h6 className="mb-3">{item.title}</h6>
                      <p>{item.content}</p>
                      <a href={`/blogdetails/${item.blog_id}`}>Read more</a>
                    </div>
                  </a>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mb-100 frequentquestion">
        <div className="container-lg">
          <div className="row justify-content-center">
            <div className="col-sm-10">
              <div className="question-box">
                <h2>Here are Most Frequent Questions</h2>
                <p>Some frequently asked questions (FAQs) and their answers</p>
              </div>

              <Accordion className="mb-5">
                {faqData.map((faqItem, index) => (
                  <Accordion.Item key={index} eventKey={index.toString()}>
                    <Accordion.Header>{faqItem.title}</Accordion.Header>
                    <Accordion.Body>{faqItem.content}</Accordion.Body>
                  </Accordion.Item>
                ))}
              </Accordion>
              <div className="text-center">
                <a href="/faqs">
                  {" "}
                  <button className="viewmore mt-3">View more</button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="mb-5 anyquestion">
        <div className="container-lg">
          <div className="row align-items-center ">
            <div className="col">
              <div className="question-box-1">
                <h1>Have Any Question?</h1>
                <p className="mb-0">
                  At Autofy, we're committed to providing you with the best
                  possible service and information.
                </p>
              </div>
            </div>
            <div className="col-sm-6 text-lg-end">
              <div className="question-box-1">
                <button>
                  {" "}
                  <Link to="/contact"> Contact Us</Link>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
