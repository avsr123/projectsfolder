import React from "react";
import Button from "react-bootstrap/Button";
import { logofooter } from "./imgUrl";

const Footer = () => {
  return (
    <>
      <footer className="pt-4">
        <div className="row align-items-center justify-content-between mx-lg-5">
          <div className="  col-xl-6 col-lg-6 col-md-6 col-sm-12">
            <img
              src={logofooter}
              className="footer-logo"
              alt="Image Description"
            />
          </div>
          <div className="  col-xl-5 col-lg-6 col-md-6 col-sm-12 mt-4">
            <ul className="social-link">
              <li>
                <a href="#">Facebook</a>
              </li>
              <li>
                <a href="#">Instagram</a>
              </li>
              <li>
                <a href="#">Twitter</a>
              </li>
              <li>
                <a href="#">Pinterest</a>
              </li>
            </ul>
          </div>
        </div>
        <hr className="my-5" />
        <div className="row justify-content-between mx-lg-5">
          <div className=" col-xl-6  col-lg-7 col-md-6 col-sm-12">
            <div className="row">
              <div className="col-md-6 mb-lg-5 mb-4">
                <div>
                  <p className="mb-1">Head Office Phone</p>
                  <strong className="footer-link">
                    {" "}
                    <a href="tel:894561230"> (123) 456-7890 </a>
                  </strong>
                </div>
              </div>
              <div className="col-md-6 mb-lg-5 mb-4">
                <div>
                  <p className="mb-1">Email</p>
                  <strong className="footer-link">
                    {" "}
                    <a href="mailto:abc@example.com"> mail@mail.com </a>
                  </strong>
                </div>
              </div>
              <div className="col-md-6 mb-lg-5 mb-4">
                <div>
                  <p className="mb-1">Support</p>
                  <strong className="footer-link">
                    {" "}
                    <a href="tel:894561230"> (123) 456-7890 </a>
                  </strong>
                </div>
              </div>
              <div className="col-md-6 mb-lg-5 mb-4">
                <div>
                  <p className="mb-1">Address</p>
                  <strong>
                    1234 Car Street, Ontario City, ON, Canada ZIP: A1B 2C3
                  </strong>
                </div>
              </div>
            </div>
          </div>
          <div className=" col-xl-5  col-lg-5 col-md-6 col-sm-12">
            <div className="mail-list">
              <p>Join Our Mailing List</p>
              <input
                email="email"
                className="form-control mb-3"
                placeholder="Email"
                text="email"
              />
              <a href="/">
                <button> Subscribe</button>
              </a>
            </div>
          </div>
        </div>
        <hr className="my-4" />
        <div className="row pb-4 mx-lg-5">
          <div className="col-xl-7  col-lg-9 col-md col-sm-12">
            <div className="bootm-link">
              <ul className="mb-0">
                <li>
                  <a href="/about">About Autofy</a>
                </li>
                <li>
                  <a href="/howitworks">How it works</a>
                </li>
                <li>
                  <a href="/faqs">FAQs</a>
                </li>
                <li>
                  <a href="/blogs">Blog</a>
                </li>
                <li>
                  <a href="/contact">Contact Us</a>
                </li>
                <li>
                  <a href="#">Privacy policy</a>
                </li>
                <li>
                  <a href="#">Terms & Conditions</a>
                </li>
              </ul>
            </div>
          </div>
          <div className=" col-xl-5  col-lg-3  col-md-auto col-sm-12 text-center text-md-end">
            <a className="copyright" href="mailto:hege@example.com">
              Copyright © 2023 Autofy
            </a>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Footer;
