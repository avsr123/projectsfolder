import React, { useEffect, useState } from "react";
import { logo } from "./imgUrl";
import Navbar from "react-bootstrap/Navbar";
import Nav from "react-bootstrap/Nav";
import Container from "react-bootstrap/Container";
import Image from "react-bootstrap/Image";
import { Link } from "react-router-dom";
import { NavLink } from "react-router-dom";

const Header = () => {
  const [showOffcanvas, setShowOffcanvas] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  const handleToggleOffcanvas = () => {
    setShowOffcanvas(!showOffcanvas);
  };

  const handleOffcanvasLinkClick = () => {
    setShowOffcanvas(false); // Close the off-canvas menu when a link is clicked
  };

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth <= 992) {
        setIsMobile(true);
      } else {
        setIsMobile(false);
        setShowOffcanvas(false);
      }
    };

    window.addEventListener("resize", handleResize);
    handleResize();

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <Navbar expand="lg" className="mx-lg-5 header-home">
      <Container fluid>
        <Navbar.Brand href="/">
          <Image src={logo} alt="" />
        </Navbar.Brand>
        {isMobile ? (
          <Navbar.Toggle
            aria-controls="offcanvasScrolling"
            aria-expanded="false"
            aria-label="Toggle navigation"
            onClick={handleToggleOffcanvas}
          >
            <span className="navbar-toggler-icon"></span>
          </Navbar.Toggle>
        ) : (
          <>
            <Nav className="  ">
              <Nav.Item>
                <Nav.Link
                  as={NavLink}
                  onClick={handleOffcanvasLinkClick}
                  to="/"
                >
                  Get A Quote
                </Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link
                  as={NavLink}
                  onClick={handleOffcanvasLinkClick}
                  to="/howitworks"
                >
                  How It Works
                </Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link
                  as={NavLink}
                  onClick={handleOffcanvasLinkClick}
                  to="/blogs"
                >
                  Blog
                </Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link
                  as={NavLink}
                  onClick={handleOffcanvasLinkClick}
                  to="/about"
                >
                  About Us
                </Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link
                  as={NavLink}
                  onClick={handleOffcanvasLinkClick}
                  to="/"
                >
                  Shop Now
                </Nav.Link>
                <span className="comming-soon">Coming Soon</span>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link
                  as={NavLink}
                  onClick={handleOffcanvasLinkClick}
                  to="/"
                >
                  Finance
                </Nav.Link>
                <span className="comming-soon">Coming Soon</span>
              </Nav.Item>
            </Nav>
            <Nav>
              <Nav.Link as={NavLink} href="#">
                <svg
                  style={{ marginTop: "-8px" }}
                  width="26"
                  height="26"
                  viewBox="0 0 26 26"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M11.8571 17.5184V16.3779C13.35 15.5169 14.5714 13.3757 14.5714 11.2299C14.5714 7.79038 14.5714 5 10.5 5C6.42857 5 6.42857 7.79038 6.42857 11.2299C6.42857 13.3757 7.65 15.5169 9.14286 16.3779V17.5184C4.53762 17.9016 1 20.2231 1 23H20C20 20.2096 16.4624 17.9016 11.8571 17.5184Z"
                    stroke="white"
                    strokeWidth="1.4625"
                    strokeMiterlimit="10"
                  />
                </svg>
                Account
              </Nav.Link>
            </Nav>
          </>
        )}
        <Navbar.Offcanvas
          placement="end"
          scroll
          backdrop={false}
          className="headerhomebox"
          show={showOffcanvas}
          target="#offcanvasScrolling"
          aria-labelledby="offcanvasScrollingLabel"
          onHide={() => setShowOffcanvas(false)}
        >
          <div className="text-end py-3">
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="offcanvas"
              aria-label="Close"
              onClick={handleOffcanvasLinkClick}
            ></button>
          </div>
          <Nav className="me-auto mb-2 mb-lg-0">
            <Nav.Item>
              <Nav.Link as={NavLink} onClick={handleOffcanvasLinkClick} to="/">
                Get A Quote
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link
                as={NavLink}
                onClick={handleOffcanvasLinkClick}
                to="/howitworks"
              >
                How It Works
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link
                as={NavLink}
                onClick={handleOffcanvasLinkClick}
                to="/blogs"
              >
                Blog
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link
                as={NavLink}
                onClick={handleOffcanvasLinkClick}
                to="/about"
              >
                About Us
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link as={NavLink} onClick={handleOffcanvasLinkClick} to="/">
                Shop Now
              </Nav.Link>
              <span className="comming-soon">Coming Soon</span>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link as={NavLink} onClick={handleOffcanvasLinkClick} to="/">
                Finance
              </Nav.Link>
              <span className="comming-soon">Coming Soon</span>

            </Nav.Item>
          </Nav>
        </Navbar.Offcanvas>
      </Container>
    </Navbar>
  );
};

export default Header;
