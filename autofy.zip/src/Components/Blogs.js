import axios from "axios";
import React, { useEffect, useState } from "react";
import Headers from "./Headers";

const Blog = () => {
  const [data, setData] = useState([]);
  const [displayedData, setDisplayedData] = useState([]);
  const [showAll, setShowAll] = useState(false);

  const fetchData = async () => {
    const response = await axios.get(
      `https://autofyus.com/admin/public/api/blogs`
    );
    setData(response.data.result);
  };

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    if (showAll) {
      setDisplayedData(data);
    } else {
      setDisplayedData(data.slice(0, 9));
    }
  }, [data, showAll]);

  const handleViewMore = () => {
    setShowAll(true);
  };

  return (
    <div>
      <Headers />

      <section className="mx-lg-5 mt-lg-5 ">
        <div className="row m-3">
          <div className="col-lg-5 col-md-12">
            <div className="about-box">
              <h4>Blogs</h4>
              <p>
                Welcome to the Autofy Blog, your go-to source for all things
                related to buying, selling, and owning used cars in Ontario. Our
                blog is designed to provide you with valuable insights, tips,
                and expert advice to make your automotive journey as smooth and
                enjoyable as possible. Explore our latest articles below:
              </p>
            </div>
            <div className="position-relative mt-lg-5 mt-4">
              <div className="one-line"></div>
              <div className="two-line"></div>
            </div>
          </div>
        </div>
      </section>
      <section className="mx-lg-5 mb-100">
        <div className="row justify-content-between ">
          <div className="col-sm-6 mt-5 pt-lg-5 pe-lg-5 mb-5 ">
            {displayedData.length > 0 && ( // Check if there is at least one blog to display
              <a href={`/blogdetails/${displayedData[0].blog_id}`}>
                <div className="creticate-blog-box post-stic ">
                  <div className="row align-items-center ">
                    <div className="col-sm-6 order-1 order-lg-0">
                      <h6 className="mb-3">{displayedData[0].title}</h6>
                      <p>{displayedData[0].content}</p>
                      <a href={`/blogdetails/${displayedData[0].blog_id}`}>
                        Read more
                      </a>
                    </div>
                    <div className="col-sm-6">
                      <img
                        src={displayedData[0].blog_image}
                        className="blog-first-image mb-4"
                        alt=""
                      />
                    </div>
                  </div>
                </div>
              </a>
            )}
          </div>
          <div className="col-sm-6">
            <div className="row">
              {displayedData.slice(1).map((category, index) => (
                <div className="col-sm-6 mb-5" key={index}>
                  <a href={`/blogdetails/${category.blog_id}`}>
                    <div className="creticate-blog-box">
                      <img
                        src={category.blog_image}
                        className="img-fluid mb-4"
                        alt=""
                      />
                      <h6 className="mb-3">{category.title}</h6>
                      <p>{category.content}</p>
                      <a href={`/blogdetails/${category.blog_id}`}>Read more</a>
                    </div>
                  </a>
                </div>
              ))}
            </div>
            {!showAll && (
              <div className="mt-3">
                <button className="load-more" onClick={handleViewMore}>
                  Load more
                </button>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Blog;