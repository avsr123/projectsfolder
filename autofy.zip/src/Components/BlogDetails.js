import React, { useState, useEffect } from "react";
import axios from "axios";
import parse from "html-react-parser";
import { Link, useParams } from "react-router-dom";
import Headers from "./Headers";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

function BlogDetail() {
  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToScroll: 4,
    slidesToShow: 4, // Number of items to show at once

    responsive: [
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };

  const id = useParams();

  const [data, setdata] = useState([]);
  const [data1, setdata1] = useState([]);

  const fetchData = async () => {
    const response = await axios.post(
      `https://autofyus.com/admin/public/api/blog_detail?blog_id=${id.blog_id}`
    );
    setdata(response.data.result);
  };

  const fetchData1 = async () => {
    const response = await axios.get(
      `https://autofyus.com/admin/public/api/blogs`
    );
    setdata1(response.data.result);
  };

  useEffect(() => {
    fetchData();
    fetchData1();
  }, []);

  return (
    <>
      <Headers />
      <div className="container mt-5 mb-100">
        {data.map((details) => (
          <div key={details.blog_detail_id}>
            <h1 className="text-center fw-bold">{details.title}</h1>
            <img
              className="w-full py-5 h-80 rounded-30"
              src={details.blog_image}
              alt=""
            />
            <p className="detilas-cotant">{parse(details.content)}</p>
          </div>
        ))}
      </div>
      <div className="mt-5 pt-5 mb-100">
        <h1 className="text-center pb-5 fw-bold">Other Blogs</h1>
        <div className="container">
          <Slider {...sliderSettings}>
            {data1.map((category, index) => (
              <a href={`/blogdetails/${category.blog_id}`}>
                <div className="creticate-blog-box mx-3">
                  <img
                    src={category.blog_image}
                    className="img-fluid mb-4"
                    alt=""
                    style={{
                      height: "300px",
                      width: "-webkit-fill-available",
                      objectFit: "cover",
                    }}
                  />
                  <h6 className="mb-3">{category.title}</h6>
                  <p>{category.content}</p>
                  <a href={`/blogdetails/${category.blog_id}`}>Read more</a>
                </div>
              </a>
            ))}
          </Slider>
        </div>
      </div>
    </>
  );
}

export default BlogDetail;
