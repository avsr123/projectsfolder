import { Container } from "react-bootstrap";
import Table from "react-bootstrap/Table";

function Candidatesforparticularrole() {
  return (
    <Container>
      <h1 className="head-text mt-4 mb-5">Candidates for role ML engineer</h1>
      <section className="mb-5">
        <p className="para-text">Recommended</p>
        <Table className="table-candidte-recommended">
          <thead>
            <tr>
              <th>Full name</th>
              <th>Email</th>
              <th>CV (structured)</th>
              <th> CV (file)</th>
              <th>Score</th>
              <th>Features</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Vlad Rogov</td>
              <td>vladrogov@gmail.com</td>
              <td>Open</td>
              <td>Download</td>
              <td>85</td>
              <td>3y. experience in ML | M. Tech | PyTorch | LLM | AWS |</td>
            </tr>
            <tr>
              <td>Candidate 2</td>
            </tr>
            <tr>
              <td>Candidate 3</td>
            </tr>
          </tbody>
        </Table>
      </section>
      <section className="disabled">
        <p className="para-text">Not recommended</p>
        <Table className="table-candidte-recommended">
          <thead>
            <tr>
              <th>Full name</th>
              <th>Email</th>
              <th>CV (structured)</th>
              <th> CV (file)</th>
              <th>Score</th>
              <th>Features</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Vlad Rogov</td>
              <td>vladrogov@gmail.com</td>
              <td>Open</td>
              <td>Download</td>
              <td>85</td>
              <td>3y. experience in ML | M. Tech | PyTorch | LLM | AWS |</td>
            </tr>
            <tr>
              <td>Candidate 2</td>
            </tr>
            <tr>
              <td>Candidate 3</td>
            </tr>
          </tbody>
        </Table>
      </section>
    </Container>
  );
}

export default Candidatesforparticularrole;
