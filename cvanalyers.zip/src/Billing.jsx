import React from "react";
import { Container } from "react-bootstrap";

const Billing = () => {
  return (
    <>
      <Container>
        <div className="billing-box">
          <div>
            <h2>Current balance: 10 tokens</h2>
            <p>It costs 1 token to process one CV </p>
          </div>
          <div>
            <h2>How many tokens do you want to add?</h2>
            <input type="text" value={50} />
          </div>
          <div>
            <h2>It will cost you</h2>
            <input type="text" value={25.0} />
          </div>
          <div>
            <h3>Stripe integration should be here</h3>
          </div>
        </div>
      </Container>
    </>
  );
};

export default Billing;
