import React, { useState, useEffect } from "react";
import { auth, googleProvider } from "./firebase";
import { signInWithPopup, signOut, onAuthStateChanged } from "firebase/auth";
import { Button, Container, Dropdown, Nav } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

const Header = ({ onLoginStatusChange }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState("");
  const [userPhotoURL, setUserPhotoURL] = useState("");

  const navigate = useNavigate()

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setUserName(user.displayName);
        setUserPhotoURL(user.photoURL);
        setIsLoggedIn(true);
        onLoginStatusChange(true); // Pass login status to parent
      } else {
        setUserName("");
        setUserPhotoURL("");
        setIsLoggedIn(false);
        onLoginStatusChange(false); // Pass login status to parent
      }
    });

    return () => unsubscribe();
  }, [onLoginStatusChange]);

  const handleGoogleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      setUserName(result.user.displayName);
      setUserPhotoURL(result.user.photoURL);
      setIsLoggedIn(true);
      onLoginStatusChange(true); // Pass login status to parent
      alert("Logged in with Google successfully!");
    } catch (error) {
      alert("Error logging in with Google: " + error.message);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setUserName("");
      setUserPhotoURL("");
      setIsLoggedIn(false);
      onLoginStatusChange(false); // Pass login status to parent
      alert("Logged out successfully!");
      navigate("/")
      
    } catch (error) {
      alert("Error logging out: " + error.message);
    }
  };

  return (

    <div className="">
    <Container>
      <div className="d-flex justify-content-end py-3">
        {isLoggedIn && (
          <Nav className="align-items-center">
            <Nav.Link className="nav-button" href="/">Home</Nav.Link>
            <Nav.Link className="nav-button" href="#jobs">Jobs</Nav.Link>
            <Nav.Link href="/uploadnewcv" className="btn btn-success-analyse me-3">
              Upload new CVs <span>10 tokens</span>
            </Nav.Link>
          </Nav>
        )}
        <div className="d-flex align-items-center">
          {isLoggedIn ? (
            <Dropdown>
              <Dropdown.Toggle
                variant="success"
                id="dropdown-basic"
                style={{
                  backgroundColor: "transparent",
                  border: "none",
                  padding: 0,
                }}
              >
                {userPhotoURL ? (
                  <img
                    src={userPhotoURL}
                    alt="Profile"
                    style={{ width: 50, height: 50, borderRadius: "50%" }}
                  />
                ) : (
                  <div
                    style={{
                      width: 50,
                      height: 50,
                      backgroundColor: "#ccc",
                      borderRadius: "50%",
                    }}
                  ></div>
                )}
              </Dropdown.Toggle>

              <Dropdown.Menu align="end">
                <Dropdown.ItemText>{userName}</Dropdown.ItemText>
                <Dropdown.Item onClick={handleLogout}>Logout</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          ) : (
            <Button variant="white" onClick={handleGoogleLogin}>
              Google sign
            </Button>
          )}
        </div>
      </div>
    </Container>
    </div>
  );
};

export default Header;
