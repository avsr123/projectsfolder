// src/firebase.js
import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBOOHQ29yzxoHZmt8MChmkXdNgJI8Dcs2Y",
  authDomain: "cvuploding.firebaseapp.com",
  projectId: "cvuploding",
  storageBucket: "cvuploding.appspot.com",
  messagingSenderId: "500382352809",
  appId: "1:500382352809:web:ccd77b0edb40f9de5970b8",
  measurementId: "G-QTY2VN8KPB"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

// Initialize Google provider
const googleProvider = new GoogleAuthProvider();

export { auth, db, storage, googleProvider };
