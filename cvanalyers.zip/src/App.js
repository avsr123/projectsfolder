import React, { useState } from "react";
import { BrowserRouter, Route, Routes, Switch } from "react-router-dom";
import Header from "./Header";
import CvEvaluator from "./CvEvaluator";
import Candidatesforparticularrole from "./Candidatesforparticularrole";
import "./App.css";
import UploadNewCV from "./UploadNewCV";
import Billing from "./Billing";
const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLoginStatusChange = (status) => {
    setIsLoggedIn(status);
  };

  return (
    <BrowserRouter>
      <div className="App">
        <Header onLoginStatusChange={handleLoginStatusChange} />
        <Routes>
          <Route
            exact
            path="/"
            element={
              <CvEvaluator
                isLoggedIn={isLoggedIn}
                onLogin={(user) => handleLoginStatusChange(!!user)}
              />
            }
          />

          <Route path="/candidates" element={<Candidatesforparticularrole />} />
          <Route path="/uploadnewcv" element={<UploadNewCV />} />
          <Route path="/billing" element={<Billing />} />

        </Routes>
      </div>
    </BrowserRouter>
  );
};

export default App;
