import React, { useState } from "react";
import {
  Container,
  Row,
  Col,
  Button,
  Modal,
  Form,
  Spinner,
} from "react-bootstrap";
import { auth, googleProvider } from "./firebase";
import { signInWithPopup } from "firebase/auth";
import { useNavigate } from "react-router-dom";

const CvEvaluator = ({ isLoggedIn, onLogin }) => {
  const [showJobDescModal, setShowJobDescModal] = useState(false);
  const [showCVUploadModal, setShowCVUploadModal] = useState(false);
  const [jobDescription, setJobDescription] = useState("");
  const [cvFiles, setCvFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [tokenValue, setTokenValue] = useState(10); // Initial token value
  const [jobDescError, setJobDescError] = useState(false); // State for minimum length error
  const navigate = useNavigate();

  // Handle job description input change
  const handleJobDescChange = (e) => {
    const text = e.target.value;
    if (text.length >= 300) {
      setJobDescription(text);
      setJobDescError(false); // Clear error when length requirement is met
    } else {
      setJobDescription(text);
      setJobDescError(true); // Show error when length requirement is not met
    }
  };

  // Handle CV file upload
  const handleCvFileChange = (e) => {
    const files = Array.from(e.target.files);
    // Filter files to allow only PDF and DOC files
    const allowedTypes = [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ];
    const filteredFiles = files.filter((file) =>
      allowedTypes.includes(file.type)
    );
    setCvFiles((prevFiles) => [...prevFiles, ...filteredFiles]);

    // Decrease token value based on number of files uploaded
    setTokenValue((prevTokenValue) => prevTokenValue - filteredFiles.length);
  };

  // Handle analyze button click
  const handleAnalyzeClick = async () => {
    if (!isLoggedIn) {
      try {
        const result = await signInWithPopup(auth, googleProvider);
        onLogin(result.user); // Update login status
        alert("Logged in with Google successfully!");
      } catch (error) {
        alert("Error logging in with Google: " + error.message);
        return;
      }
    }

    // Check if job description meets length requirement and CV files are uploaded
    if (jobDescription.length >= 300 && cvFiles.length > 0) {
      setLoading(true);
      // Simulate analysis delay
      setTimeout(() => {
        setLoading(false);
        alert("Analysis complete!");
        navigate("/candidates");
      }, 10000);
    } else {
      alert(
        "Please provide a job description with at least 300 characters and upload at least one CV."
      );
    }
  };

  return (
    <Container
      fluid
      className="d-flex flex-column align-items-center justify-content-center cv-evaluator"
    >
      <Row className="text-center justify-content-between">
        <Col sm={4}>
          <h1>Evaluate a CV of a candidate with AI</h1>
        </Col>
        <Col sm={6}>
          <Row>
            <Col className="d-flex flex-column align-items-center">
              {/* Button for job description */}
              <Button
                variant={jobDescription ? "success-gradient" : "secondary"}
                size="lg"
                className="mb-3"
                onClick={() => setShowJobDescModal(true)}
              >
                {jobDescription
                  ? "Job Description Pasted!"
                  : "Paste your job description"}
              </Button>
              {/* Button for CV upload */}
              <Button
                variant={cvFiles.length > 0 ? "success-gradient" : "secondary"}
                size="lg"
                className="mb-3"
                onClick={() => setShowCVUploadModal(true)}
              >
                {cvFiles.length > 0
                  ? `${cvFiles.length} CV(s) Uploaded!`
                  : "Upload Some CV"}
              </Button>
              {/* Analyze button */}
              <Button
                variant="success-analyse"
                size="lg"
                onClick={handleAnalyzeClick}
                disabled={jobDescription.length < 300 || cvFiles.length === 0}
              >
                {loading ? <Spinner animation="border" size="sm" /> : "Analyze"}{" "}
                <span> ({tokenValue} tokens)</span>
              </Button>
            </Col>
          </Row>
        </Col>
      </Row>

      {/* Job Description Modal */}
      <Modal
        show={showJobDescModal}
        size="lg"
        onHide={() => setShowJobDescModal(false)}
        centered
      >
        <Modal.Body>
          <Form>
            <Form.Group controlId="jobDescription">
              <Form.Control
                as="textarea"
                rows={10}
                value={jobDescription}
                onChange={handleJobDescChange}
                placeholder="Insert your job description here. You don't need to worry about the layout or structure. Just include the essence of the job, tasks, deliverables, requirements, qualifications, skills, etc."
                isInvalid={jobDescError} // Highlight input if there's an error
              />
              {jobDescError && (
                <Form.Control.Feedback type="invalid">
                  Please write at least 300 characters.
                </Form.Control.Feedback>
              )}
              {/* <small>{jobDescription.length}/300 characters</small> */}
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer className="justify-content-center">
          <Button variant="dark" onClick={() => setShowJobDescModal(false)}>
            Confirm
          </Button>
          <Button
            variant="secondary"
            onClick={() => setShowJobDescModal(false)}
          >
            Cancel
          </Button>
        </Modal.Footer>
      </Modal>

      {/* CV Upload Modal */}
      <Modal
        show={showCVUploadModal}
        size="lg"
        onHide={() => setShowCVUploadModal(false)}
        centered
      >
        <Modal.Body>
          <Form className="upload-cv-form">
            <Form.Group controlId="cvFile">
              <label htmlFor="upload-file" className="custom-file-upload">
                <i className="bi bi-mic-fill"></i> Open files
              </label>
              <Form.Control
                id="upload-file"
                type="file"
                accept=".pdf,.doc,.docx"
                multiple
                onChange={handleCvFileChange}
                style={{ display: "none" }}
              />
              <div>
                {cvFiles.map((file, index) => (
                  <p className="mt-3" key={index}>{file.name}</p>
                ))}
              </div>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer className="justify-content-center">
          <Button variant="dark" onClick={() => setShowCVUploadModal(false)}>
            Confirm
          </Button>
          <Button
            variant="secondary"
            onClick={() => setShowCVUploadModal(false)}
          >
            Cancel
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
};

export default CvEvaluator;
