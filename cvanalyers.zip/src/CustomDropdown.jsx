import React, { useState, useRef, useEffect } from "react";

const CustomDropdown = ({ defaultOption, onSelect, onSelectNewRole }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedOption, setSelectedOption] = useState(defaultOption);
  const dropdownRef = useRef(null);

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const selectOption = (role) => {
    setSelectedOption(role);
    setIsOpen(false);
    onSelect(role); // Notify parent component of selection
    if (role === "New role") {
      onSelectNewRole(); // Notify parent component of selecting "New role"
    }
  };

  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div className="dropdown1" ref={dropdownRef}>
      <div className="dropdown-btn" onClick={toggleDropdown}>
        {selectedOption}
        <span className={`dropdown-arrow ${isOpen ? "open" : ""}`}>
          {isOpen ? (
            <svg
              width="12"
              height="7"
              viewBox="0 0 12 7"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                opacity="0.8"
                d="M11 5.8728L6 0.872803L1 5.8728"
                stroke="black"
                strokeWidth="1.4"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          ) : (
            <svg
              width="13"
              height="7"
              viewBox="0 0 13 7"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                opacity="0.8"
                d="M1.65576 1.66797L6.80186 5.92402L11.948 1.66797"
                stroke="black"
                strokeWidth="1.4"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          )}
        </span>
      </div>
      {isOpen && (
        <div className="dropdown-content">
          <div onClick={() => selectOption("New role")}>New role</div>
          <div onClick={() => selectOption("ML Engineer")}>ML Engineer</div>
          <div onClick={() => selectOption("Product Manager")}>
            Product Manager
          </div>
          <div onClick={() => selectOption("IT Staff")}>IT Staff</div>
        </div>
      )}
    </div>
  );
};

export default CustomDropdown;
