// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDSxK7CgvMM2u5ZYa8Z9QUafwy8bWl7XCM",
  authDomain: "foodwaste-d2ede.firebaseapp.com",
  projectId: "foodwaste-d2ede",
  storageBucket: "foodwaste-d2ede.appspot.com",
  messagingSenderId: "996766946684",
  appId: "1:996766946684:web:e12e0ff95c5b78c49700f9",
  measurementId: "G-KMXDMBBNQK"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);