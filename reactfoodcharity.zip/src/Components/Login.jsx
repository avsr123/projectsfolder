import React from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const Login = () => {
const formik = useFormik({
    initialValues: {
      userName: "",
      password: "",
      role: "",
    },
    validationSchema: Yup.object({
      userName: Yup.string().required("Required"),
      password: Yup.string().required("Required"),
      role: Yup.string().required("Required").oneOf(["donor", "organization"], "Invalid role"),
    }),

    onSubmit: async (values) => {
      try {
        const endpoint = values.role === "donor" ? "/api/login" : "/api/organizations/login";
        const response = await axios.post(`http://192.168.0.23:4000${endpoint}`, {
          userName: values.userName,
          password: values.password,
        });
        const { token, role } = response.data;
        localStorage.setItem("token", token);
        localStorage.setItem("role", role);
        console.log('login', response.data);
        toast.success("Login successful");
        window.location.href = "/home";
      } 
      catch (error) {
        console.log('error', error);
        toast.error(error.response?.data?.message || "Login failed: Invalid email or password");
      }
    },
  });

  return (
    <section className="register-form">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-sm-12 col-lg-6 hvr-float-shadow">
            <form className="ulockd-reg-form text-center" onSubmit={formik.handleSubmit}>
            
              <div className="form-group">
                <select
                  name="role"
                  className="payment-time-selection form-select"
                  
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.role}>
                  <option value="select">role</option>
                  <option value="donor">Donor</option>
                  <option value="organization">Organization</option>
                </select>
                {formik.touched.role && formik.errors.role ? (
                  <div className="text-danger">{formik.errors.role}</div>
                ) : null}
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  id="exampleInputNamexa"
                  placeholder="userName"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.userName}
                  name="userName"
                />
                {formik.touched.userName && formik.errors.userName ? (
                  <div className="text-danger">{formik.errors.userName}</div>
                ) : null}
              </div>
              <div className="form-group">
                <input
                  type="password"
                  className="form-control"       
                  placeholder="Password"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.password}
                  name="password"
                />
                {formik.touched.password && formik.errors.password ? (
                  <div className="text-danger">{formik.errors.password}</div>
                ) : null}
              </div>
              <div className="form-group text-center">
                <button type="submit" className="btn btn-default ulockd-btn-thm2">
                  Login
                </button>
              </div>
              <div className="form-group text-center">
                {formik.values.role === "organization" ? (
                  <Link
                    className="btn btn-default ulockd-btn-thm2"
                    to="/orgForgetPassword"
                  >
                    Org Password
                  </Link>
                ) : (
                  <>
                    <Link
                      to="/ForgetPassword"
                      className="btn btn-default ulockd-btn-thm2"
                    >
                      {" "}
                      Forgot Password
                    </Link>
                  </>
                )}
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Login;

















































// import React, { useState } from "react";
// import axios from "axios";
// import { Link, useNavigate } from "react-router-dom";
// import { toast } from "react-toastify";
// // import addNotification from "react-push-notification";

// const Login = () => {
//   const navigate = useNavigate();
//   const [state, setState] = useState({
//     userName: "",
//     password: "",
//     role: "",
//   });
//   console.log("8989", state.role);

//   const handelSubmit = async (e) => {
//     e.preventDefault();
//     console.log("state", state.userName, state.password);
//     if (state.role === "donor")
//       try {
//         const response = await axios.post(
//           "http://192.168.0.23:4000/api/login",
//           {
//             userName: state.userName,
//             password: state.password,
//           }
//         );

//         const token = response.data.token;
//         const role = response.data.role;

//         console.log("token", token);

//         localStorage.setItem("token", token);
//         localStorage.setItem("role", role);

//         console.log('login',response.data);
//         toast.success("Login successful");
//         window.location.href = "/home";
//       } catch (error) {
//         console.log('676',error);
//         toast.error("Login failed: Invalid email or password");
//       }
//     else if (state.role === "organization") {
//       try {
//         const response = await axios.post(
//           "http://192.168.0.23:4000/api/organizations/login",
//           {
//             userName: state.userName,
//             password: state.password,
//           }
//         );
//         const token = response.data.token;
//         const role = response.data.role;
//         localStorage.setItem("token", token);
//         localStorage.setItem("role", role);
//         console.log("878", response);
//         console.log(response.data);
//         toast.success("Login successful");
//         window.location.href = "/home";
//       } catch (error) {
//         console.log('111',error.response.data.message);
//         toast.error(error.response.data.message);
//       }
//     }
//   };

//   return (
//     <>
//       <section className="register-form">
//         <div className="container">
//           <div class="row justify-content-center">
//             <div class="col-sm-12 col-lg-6 hvr-float-shadow">
//               <form class="ulockd-reg-form text-center" onSubmit={handelSubmit}>
//                 <h3></h3>
//                 <p className="mb-0">Join our community today:</p>
//                 <h2 className="mb-5">Login</h2>

//                 <div class="form-group">
//                   <select
//                     name="pts"
//                     className="payment-time-selection"
//                     class="form-select"
//                     onChange={(e) =>
//                       setState({ ...state, role: e.target.value })
//                     }
//                   >
//                     <option value="select">role</option>
//                     <option value="donor">Donor</option>
//                     <option value="organization">Organization</option>
//                   </select>
//                 </div>
//                 <div class="form-group">
//                   <input
//                     type="text"
//                     class="form-control"
//                     id="exampleInputNamexa"
//                     placeholder="userName"
//                     onChange={(e) =>
//                       setState({ ...state, userName: e.target.value })
//                     }
//                   />
//                 </div>
//                 <div class="form-group">
//                   <input
//                     type="password"
//                     class="form-control"
//                     placeholder="Password"
//                     onChange={(e) =>
//                       setState({ ...state, password: e.target.value })
//                     }
//                   />
//                 </div>

//                 <div class="form-group text-center">
//                   <button type="submit" class="btn btn-default ulockd-btn-thm2">
//                     Login
//                   </button>
//                 </div>
//                 <div className="form-group text-center">
//                   {state.role === "organization" ? (
//                     <Link
//                       className="btn btn-default ulockd-btn-thm2"
//                       to="/orgForgetPassword"
//                     >
//                       Org Password
//                     </Link>
//                   ) : (
//                     <>
//                       <Link
//                         to="/ForgetPassword"
//                         className="btn btn-default ulockd-btn-thm2"
//                       >
//                         {" "}
//                         Forgot Password
//                       </Link>
//                     </>
//                   )}
//                 </div>
//               </form>
//             </div>
//           </div>
//         </div>
//       </section>
//     </>
//   );
// };

// export default Login;
