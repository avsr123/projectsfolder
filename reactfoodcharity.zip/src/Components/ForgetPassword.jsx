import React, { useState } from "react";
import axios from "axios";

const ForgetPassword = () => {
  const [state, setState] = useState({
    email: "",
  });
  const handelsubmit = async () => {
     let tokens;

    try {
      tokens = localStorage.getItem("token");
      const response = await axios.post(
        "http://192.168.0.23:4000/api/reset-password",
        state,
        {
         headers: {
            Authorization: `${tokens}`,
           },
         }
      );

      console.log("11", response);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <div className="register-form">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-sm-12 col-lg-6 hvr-float-shadow">
            <div className="ulockd-reg-form text-center">
              <h3 className="mb-4">
                <span className="flaticon-house-key"></span> Forget Password
              </h3>

              <div className="form-group text-center">
                <input
                  type="email"
                  className="form-control"
                  placeholder="enter ur email"
                  onChange={(e) =>
                    setState({ ...state, email: e.target.value })
                  }
                />
              </div>
              <button
                type="button"
                className="btn btn-default ulockd-btn-thm2"
                onClick={handelsubmit}
              >
                submit
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForgetPassword;
