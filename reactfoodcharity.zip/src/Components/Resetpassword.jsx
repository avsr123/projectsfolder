import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";

const Resetpassword = () => {
  const [state, setState] = useState({
    newPassword: "",
    confirmPassword: "",
  });
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const token = searchParams.get("token");

  console.log("token", token);

  useEffect(() => {
    console.log("Token from URL:", token);
  }, [token]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://192.168.0.23:4000/api/update-password",
        {
          newPassword: state.newPassword,
          confirmPassword: state.confirmPassword,
          token: token,
        }
      );

      // Handle the API response here (e.g., show a success message)
      console.log(response.data);
    } catch (error) {
      // Handle errors (e.g., show an error message)
      console.log(error);
    }
  };

  return (
    <>
      <div className="register-form">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-sm-12 col-lg-6 hvr-float-shadow">
              <div className="ulockd-reg-form text-center">
                <h3 className="mb-4">
                  <span className="flaticon-house-key"></span> Reset Orginaztion
                  Password
                </h3>
                <form onSubmit={handleSubmit}>
                  <div className="form-group">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Enter your new password"
                      value={state.newPassword}
                      onChange={(e) =>
                        setState({ ...state, newPassword: e.target.value })
                      }
                    />
                  </div>
                  <div className="form-group">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Enter your confirmPassword"
                      value={state.confirmPassword}
                      onChange={(e) =>
                        setState({ ...state, confirmPassword: e.target.value })
                      }
                    />
                  </div>

                  <button className="btn btn-default ulockd-btn-thm2" type="submit">Submit</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Resetpassword;
