import React, { useState, useEffect } from "react";
import axios from "axios";

const FoodsList = () => {
  const [foods, setFoods] = useState([]);
  const role = localStorage.getItem("role");

  const [requestQuantities, setRequestQuantities] = useState({});

  const handleQuantityChange = (foodItemId, quantity) => {
    setRequestQuantities((prevQuantities) => ({
      ...prevQuantities,
      [foodItemId]: quantity,
    }));
  };

  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem("token");

      try {
        const response = await axios.get("http://192.168.0.23:4000/api/foods", {
          headers: {
            Authorization: `${token}`,
          },
        });
        setFoods(response.data.data);
        console.log("response.data.data", response.data.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);
  const sendRequest = async (food) => {
    const token = localStorage.getItem("token");

    try {
      const response = await axios.post(
        "http://192.168.0.23:4000/api/requests",
        {
          items: food.food.map((foodItem) => ({
            itemID: foodItem._id,
            quantity: requestQuantities[foodItem._id] || foodItem.quantity,
            unit: foodItem.unit,
          })),
          foodID: food._id,
          donorID: food.donorID,
          locationID: food.location._id,
        },
        {
          headers: {
            Authorization: `${token}`,
          },
        }
      );

      console.log("Request sent successfully:", response.data);
    } catch (error) {
      console.error("Error sending request:", error);
    }
  };
  return (
    <div>
      <h1>Foods List</h1>
      <div className="row mx-0">
        {foods &&
          foods.map((food, index) => (
            <div className="col-sm-3" key={index}>
              <ul>
                <li>
                  <b> Expiration Date:</b> {food.expirationDate}
                </li>
                <li>
                  <b>donorID:</b> {food.donorID}
                </li>
                <li>
                  <b>Food_ID:</b> {food._id}
                </li>
                <li>
                  <b>location_id:</b> {food.location._id}
                </li>
                <li>
                  <b>Pickup Availability:</b> {food.pickupAvailability}
                </li>
                <li>
                  <b>address1:</b> {food.location.address1}
                </li>
                <li>
                  <b>address2:</b> {food.location.address2},
                </li>
                <li>
                  <b>city:</b> {food.location.city},
                </li>
                <li>
                  <b>state:</b> {food.location.state}
                </li>
                <li>
                  <b>pincode:</b> {food.location.pincode}
                </li>
                {food.food.map((foodItem, foodIndex) => (
                  <>
                    <hr />
                    <li key={foodIndex}>
                      <b> food_name: </b> {foodItem.food_name}
                    </li>
                    <li>
                      <b> quantity: </b> {foodItem.quantity}
                    </li>

                    <li>
                      <b> quantity: </b>{" "}
                      <input
                        type="number"
                        value={requestQuantities[foodItem._id] || ""}
                        onChange={(e) =>
                          handleQuantityChange(foodItem._id, e.target.value)
                        }
                      />
                    </li>

                    <li>
                      <b> unit: </b> {foodItem.unit}
                    </li>
                    <li>
                      <b> Items_id: </b> {foodItem._id}
                    </li>
                  </>
                ))}
              </ul>
              {role === "donor" ? null : (
                <button
                  className="btn btn-warning"
                  onClick={() => sendRequest(food)}
                >
                  Send Request
                </button>
              )}
            </div>
          ))}
      </div>
    </div>
  );
};

export default FoodsList;
