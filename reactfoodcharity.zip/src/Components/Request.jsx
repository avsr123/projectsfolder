import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
// import addNotification from "react-push-notification";

const Request = () => {
  const [foods, setFoods] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get(
          "http://192.168.0.23:4000/api/requests",
          {
            headers: {
              Authorization: `${token}`,
            },
          }
        );
       
              //  addNotification({
              //   message: "I hope you got the quantity",
                
              //   title: "Warning",
              //   subtitle: "This is a subtitle",
              //     duration: 100000, 
              //    closeButton: 'Go away',
              //    vibrate: 2 ,
              //    silent: false,
              //   theme: "darkblue",
              //   native: true,
              //  });
        setFoods(response.data.data);
        console.log("Fetched Data?????:", response.data.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const handleAccept = async (receiverId, requestId) => {
    try {
      const token = localStorage.getItem("token");
      const statusObject = {
        status: "accept",
      };

      await axios.patch(
        `http://192.168.0.23:4000/api/requests/${requestId}`,
        statusObject,
        {
          headers: {
            Authorization: `${token}`,
          },
        }
      );

      alert("Request Accepted successfully!");
    } catch (error) {
      console.error("Error accepting request:", error);
    }
  };

  const handleChatButtonClick = (roomId, receiverID) => {
    // Navigate to the chat page with the roomId and receiverID as parameters
    navigate(`/chatApp/${roomId}`, { state: { receiverID } });
  };

  return (
    <div>
      <div>
        <h2>Fetched Data</h2>
        <div className="row">
          {foods?.map((item) => (
            <div key={item?._id} className="col-sm-3 hvr-float-shadow">
              <div className="ulockd-reg-form ">
                <strong>Status:</strong>
                <span className="badge-success"> {item?.status} </span> <br />
                <strong>Request ID:</strong> {item?._id} <br />
                <strong>Room ID:</strong> {item?.roomId} <br />
                <strong>Donor ID:</strong> {item?.donorID} <br />
                <strong>Receiver ID:</strong> {item?.receiverID} <br />
                <strong>Food Details:</strong> {item?.foodID?.food[0].food_name}
                - {item?.items[0].quantity} {item?.foodID?.food[0].unit}

                {/* [
    {
        "itemID": "6576f85e89203026b9c7cae8",
        "quantity": "4",
        "unit": "itm",
        "_id": "6576f97d89203026b9c7cc0e"
    }
] */}
                {/* <br />
                <strong>Location Details:</strong> {item?.locationID.address1},
                {item?.locationID.city}, {item?.locationID.state} <br /> */}
                <br />
                <strong>Status:</strong> {item?.status} <br />
                <strong>Created At:</strong> {item?.createdAt} <br />
                <strong>Updated At:</strong> {item?.updatedAt} <br />
                <strong>Receiver Name:</strong> {item?.receiverDetail.name}
                <br />
                {item?.status === "accept" ? (
                  <button
                    className="btn btn-success"
                    onClick={() =>
                      handleChatButtonClick(item?.roomId, item.receiverID)
                    }
                  >
                    Chat
                  </button>
                ) : (
                  <button
                    className="btn btn-success"
                    onClick={() => handleAccept(item.receiverID, item._id)}
                  >
                    Accept
                  </button>
                )}
                {/* <button
                className="btn btn-success"
                onClick={() => handleAccept(item.requestId, item._id)}
              >
                Accept
              </button> */}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Request;
