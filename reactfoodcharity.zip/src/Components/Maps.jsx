import React from 'react';
import ReactMapGL, { Marker } from 'react-map-gl';

const Maps = () => {
  const [viewport, setViewport] = React.useState({
    width: '100%',
    height: 400,
    latitude: 37.7749,
    longitude: -122.4194,
    zoom: 13,
  });

  return (
    <ReactMapGL
      {...viewport}
      mapboxApiAccessToken="pk.eyJ1IjoiYXNoaXNoYm94IiwiYSI6ImNscTNsZXlxdTBkamwya280b3VyZnd3bTkifQ.V0YL9Jz-msu85FjPhH2Riw"
      onViewportChange={(newViewport) => setViewport(newViewport)}
    >
      <Marker latitude={37.7749} longitude={-122.4194} offsetLeft={-20} offsetTop={-10}>
        <div>Your location</div>
      </Marker>
    </ReactMapGL>
  );
};

export default Maps; 
