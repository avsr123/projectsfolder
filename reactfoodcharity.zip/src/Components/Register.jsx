import React from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";

const Register = () => {
  const navigate = useNavigate();
  const formik = useFormik({
    initialValues: {
      userName: "",
      name: "",
      email: "",
      password: "",
      mobile: "",
      role: "",
      about: "",
      mission: "",
      serviceArea: "",
      address1: "",
      address2: "",
      state: "",
      city: "",
      country: "",
      pincode: "",
      pic: null,
    },
    validationSchema: Yup.object({
      userName: Yup.string().required("User Name is required"),
      name: Yup.string().required("Name is required"),
      email: Yup.string()
        .email("Invalid email address")
        .required("Email is required"),
      password: Yup.string().required("Password is required"),
      mobile: Yup.string().required("Mobile number is required"),
      role: Yup.string().required("Role is required"),
      about: Yup.string(),
      mission: Yup.string(),
      serviceArea: Yup.string(),
      address1: Yup.string(),
      address2: Yup.string(),
      state: Yup.string(),
      city: Yup.string(),
      country: Yup.string(),
      pincode: Yup.string(),
      pic: Yup.mixed().required("Profile picture is required"),
    }),
    onSubmit: async (values) => {
      try {
        console.log("Form Values:", values);

        const formData = new FormData();
        formData.append("userName", values.userName);
        formData.append("name", values.name);
        formData.append("email", values.email);
        formData.append("password", values.password);
        formData.append("mobile", values.mobile);
        formData.append("role", values.role);
        formData.append("pic", values.pic);

        // Append other fields based on the role
        if (values.role === "organization") {
          formData.append("about", values.about);
          formData.append("mission", values.mission);
          formData.append("serviceArea", values.serviceArea);
          formData.append("address1", values.address1);
          formData.append("address2", values.address2);
          formData.append("state", values.state);
          formData.append("city", values.city);
          formData.append("country", values.country);
          formData.append("pincode", values.pincode);
        }

        const apiUrl =
          values.role === "organization"
            ? "http://192.168.0.23:4000/api/organizations/register"
            : "http://192.168.0.23:4000/api/register";

        // Use axios.post directly, no need for await here
        const response = await axios.post(apiUrl, formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });

        const token = response.data.token;
        localStorage.setItem("token", token);
        toast.success("Registration successful");
        console.log(response.data);
        navigate("/");
      } catch (error) {
        console.error("Registration failed:", error);

        if (
          error.response &&
          error.response.data &&
          error.response.data.message &&
          error.response.data.message.mobile
        ) {
          toast.error(
            `Registration failed: ${error.response.data.message.mobile}`
          );
        } else {
          console.error("Error object:", error);
          toast.error("Registration failed. Please try again later.");
        }
      }
    },
  });

  const handleChange = (e) => {
    console.log("Field changed:", e.target.name, e.target.value);
    formik.handleChange(e);
  };

  return (
    <>
      <section className="register-form">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-sm-12 col-lg-6 hvr-float-shadow">
              <form
                className="ulockd-reg-form text-center"
                onSubmit={formik.handleSubmit}
                encType="multipart/form-data"
              >
                <div className="row">
                  <div className="col-sm-6">
                    <div className="form-group">
                      <input
                        type="file"
                        className="form-control"
                        id="exampleInputUserName"
                        name="pic"
                        onChange={(e) => {
                          formik.handleChange(e);
                          formik.setFieldValue("pic", e.currentTarget.files[0]);
                        }}
                        onBlur={formik.handleBlur}
                      />
                      {formik.touched.pic && formik.errors.pic && (
                        <div className="error">{formik.errors.pic}</div>
                      )}
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="form-group">
                      <select
                        name="role"
                        className="payment-time-selection  form-select"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.role}
                      >
                        <option value="select">Select</option>
                        <option value="donor">Donor</option>
                        <option value="organization">Organization</option>
                        <option value="individual">Individual</option>
                      </select>
                      {formik.touched.role && formik.errors.role && (
                        <div className="error">{formik.errors.role}</div>
                      )}
                    </div>
                  </div>
                  {/* Add similar blocks for other form fields */}

                  <div className="col-sm-6">
                    <div className="form-group">
                      <input
                        type="text"
                        className="form-control"
                        id="exampleInputUserName"
                        name="userName" // Add the name attribute
                        placeholder="User Name"
                        onChange={handleChange} // Use the handleChange function
                        onBlur={formik.handleBlur}
                        value={formik.values.userName}
                      />
                      {formik.touched.userName && formik.errors.userName && (
                        <div className="error">{formik.errors.userName}</div>
                      )}
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="form-group">
                      <input
                        type="text"
                        className="form-control"
                        id="exampleInputNamexa"
                        name="name"
                        placeholder="Name"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.name}
                      />
                      {formik.touched.name && formik.errors.name && (
                        <div className="error">{formik.errors.name}</div>
                      )}
                    </div>
                  </div>

                  <div className="col-sm-6">
                    <div className="form-group">
                      <input
                        type="email"
                        className="form-control"
                        name="email"
                        id="exampleInputNamexa"
                        placeholder="Email"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.email}
                      />
                      {formik.touched.email && formik.errors.email && (
                        <div className="error">{formik.errors.email}</div>
                      )}
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="form-group">
                      <input
                        type="text"
                        className="form-control"
                        name="password"
                        id="exampleInputNamexa"
                        placeholder="Password"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.password}
                      />
                      {formik.touched.password && formik.errors.password && (
                        <div className="error">{formik.errors.password}</div>
                      )}
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="form-group">
                      <input
                        type="text"
                        className="form-control"
                        name="mobile"
                        id="exampleInputNamexa"
                        placeholder="Mobile"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.mobile}
                      />
                      {formik.touched.mobile && formik.errors.mobile && (
                        <div className="error">{formik.errors.mobile}</div>
                      )}
                    </div>
                  </div>
                  {formik.values.role === "organization" && (
                    <>
                      <div className="col-sm-6">
                        <div className="form-group">
                          <input
                            type="text"
                            className="form-control"
                            id="exampleInputNamexa"
                            name="about"
                            placeholder="About"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.about}
                          />
                          {formik.touched.mobile && formik.errors.about && (
                            <div className="error">{formik.errors.about}</div>
                          )}
                        </div>
                      </div>
                      <div className="col-sm-6">
                        <div className="form-group">
                          <input
                            type="text"
                            className="form-control"
                            id="exampleInputNamexa"
                            name="mission"
                            placeholder="mission"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.mission}
                          />
                          {formik.touched.mission && formik.errors.mission && (
                            <div className="error">{formik.errors.mission}</div>
                          )}
                        </div>
                      </div>
                      <div className="col-sm-6">
                        <div className="form-group">
                          <input
                            type="text"
                            className="form-control"
                            name="serviceArea"
                            id="exampleInputNamexa"
                            placeholder="Servicearea"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.serviceArea}
                          />
                          {formik.touched.serviceArea &&
                            formik.errors.serviceArea && (
                              <div className="error">
                                {formik.errors.serviceArea}
                              </div>
                            )}
                        </div>
                      </div>

                      <div className="col-sm-6">
                        <div className="form-group">
                          <input
                            type="text"
                            className="form-control"
                            id="exampleInputNamexa"
                            name="address1"
                            placeholder="Address1"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.address1}
                          />
                          {formik.touched.address1 &&
                            formik.errors.address1 && (
                              <div className="error">
                                {formik.errors.address1}
                              </div>
                            )}
                        </div>
                      </div>
                      <div className="col-sm-6">
                        <div className="form-group">
                          <input
                            type="text"
                            name="address2"
                            className="form-control"
                            id="exampleInputNamexa"
                            placeholder="Address2"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.address2}
                          />
                          {formik.touched.address2 &&
                            formik.errors.address2 && (
                              <div className="error">
                                {formik.errors.address2}
                              </div>
                            )}
                        </div>
                      </div>
                      <div className="col-sm-6">
                        <div className="form-group">
                          <input
                            type="text"
                            name="state"
                            className="form-control"
                            id="exampleInputNamexa"
                            placeholder=" State"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.state}
                          />
                          {formik.touched.state && formik.errors.state && (
                            <div className="error">{formik.errors.state}</div>
                          )}
                        </div>
                      </div>
                      <div className="col-sm-6">
                        <div className="form-group">
                          <input
                            type="text"
                            className="form-control"
                            id="exampleInputNamexa"
                            placeholder="City"
                            name="city"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.city}
                          />
                          {formik.touched.city && formik.errors.city && (
                            <div className="error">{formik.errors.city}</div>
                          )}
                        </div>
                      </div>
                      <div className="col-sm-6">
                        <div className="form-group">
                          <input
                            type="text"
                            className="form-control"
                            id="exampleInputNamexa"
                            name="country"
                            placeholder="Country"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.country}
                          />
                          {formik.touched.country && formik.errors.country && (
                            <div className="error">{formik.errors.country}</div>
                          )}
                        </div>
                      </div>
                      <div className="col-sm-6">
                        <div className="form-group">
                          <input
                            type="text"
                            name="pincode"
                            className="form-control"
                            id="exampleInputNamexa"
                            placeholder="Pincode"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.pincode}
                          />
                          {formik.touched.pincode && formik.errors.pincode && (
                            <div className="error">{formik.errors.pincode}</div>
                          )}
                        </div>
                      </div>
                    </>
                  )}
                </div>

                <div className="form-group text-center">
                  <button
                    type="submit"
                    className="btn btn-default ulockd-btn-thm2"
                  >
                    Sign Me Up
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Register;

// import React, { useState } from "react";
// import axios from "axios";
// import { useNavigate } from "react-router-dom";
// import { ToastContainer, toast } from "react-toastify";

// const Register = () => {
//   const navigate = useNavigate();
//   const [state, setState] = useState({
//     userName: "",
//     name: " ",
//     email: "",
//     password: "",
//     mobile: "",
//     role: "",
//     about: "",
//     mission: "",
//     serviceArea: "",
//     address1: "",
//     address2: "",
//     state: "",
//     city: "",
//     country: "",
//     pincode: "",
//   });
//   const handelSubmit = async (e) => {
//     e.preventDefault();
//     console.log("state", state.userName, state.password);
//   if (state.role === "individual" || state.role === "donor") {
//       try {
//         const response = await axios.post(
//           "http://192.168.0.23:4000/api/register",
//           {
//             userName: state.userName,
//             name: state.name,
//             password: state.password,
//             email: state.email,
//             mobile: state.mobile,
//             role: state.role,
//           }
//         );

//         const token = response.data.token;
//         console.log("token", token);

//         localStorage.setItem("token", token);
//         toast.success("Registration successful");
//         navigate("/");

//         console.log(response.data);
//       } catch (error) {
//         console.error('222', error);

//         if (error.response && error.response.data && error.response.data.message && error.response.data.message.mobile) {
//           toast.error(`Registration failed: ${error.response.data.message.mobile}`);
//         } else {
//           // Log the entire error object for further analysis
//           console.error('Error object:', error);
//           toast.error("Registration failed. Please try again later.");
//         }
//       }
//     } else if (state.role === "organization") {
//       try {
//         const response = await axios.post(
//           "http://192.168.0.23:4000/api/organizations/register",
//           {
//             userName: state.userName,
//             name: state.name,
//             password: state.password,
//             email: state.email,
//             mobile: state.mobile,
//             about: state.mobile,
//             mission: state.about,
//             serviceArea: state.serviceArea,
//             address1: state.address1,
//             address2: state.address2,
//             state: state.state,
//             city: state.city,
//             country: state.country,
//             pincode: state.pincode,
//           }
//         );
//         toast.success("Registration successful");
//         navigate("/");

//         console.log("878", response);
//       } catch (error) {
//         console.error("Organization registration failed:", error);
//         if(error.response && error.response.data && error.response.data.message && error.response.data.message.mobile ) {
//           toast.error(`Organization registration failed: ${error.response.data.message.mobile}`);
//         } else {
//           // Log the entire error object for further analysis
//           console.error('Error object:', error);
//           toast.error("Organization registration failed. Please try again later.");
//         }
//       }
//     }
//   };

//   // const handelSubmit = async (e) => {
//   //   e.preventDefault();
//   //   console.log("state", state.userName, state.password);
//   //   if (state.role === "individual" || state.role === "donor")
//   //     try {
//   //       const response = await axios.post(
//   //         "http://192.168.0.23:4000/api/register",
//   //         {
//   //           userName: state.userName,
//   //           name: state.name,
//   //           password: state.password,
//   //           email: state.email,
//   //           mobile: state.mobile,
//   //           role: state.role,
//   //         }
//   //       );

//   //       const token = response.data.token;
//   //       console.log("token", token);

//   //       localStorage.setItem("token", token);
//   //       toast.success("Registration successful");
//   //       navigate("/");

//   //       console.log(response.data);
//   //     } catch (error) {
//   //       console.log('222',error.response.data.message.mobile);
//   //       toast.error(error.response.data.message.mobile);
//   //       // toast.error(error.response.data.message.mobile);
//   //     }
//   //   else if (state.role === "organization") {
//   //     try {
//   //       const response = await axios.post(
//   //         "http://192.168.0.23:4000/api/organizations/register",
//   //         {
//   //           userName: state.userName,
//   //           name: state.name,
//   //           password: state.password,
//   //           email: state.email,
//   //           mobile: state.mobile,
//   //           about: state.mobile,
//   //           mission: state.about,
//   //           serviceArea: state.serviceArea,
//   //           address1: state.address1,
//   //           address2: state.address2,
//   //           state: state.state,
//   //           city: state.city,
//   //           country: state.country,
//   //           pincode: state.pincode,
//   //         }
//   //       );
//   //       toast.success("Registration successful");
//   //       navigate("/");

//   //       console.log("878", response);
//   //     }
//   //     catch (error) {
//   //     console.error("Organization registration failed:", error.response.data.message);
//   //     toast.error("Organization registration failed. Please try again later.");

//   //       toast.error(error);
//   //     }
//   //   }
//   // };

//   return (
//     <>
//       <section className="register-form">
//         <div className="container">
//           <div className="row justify-content-center">
//             <div className="col-sm-12 col-lg-6 hvr-float-shadow">
//               <form
//                 className="ulockd-reg-form text-center"
//                 onSubmit={handelSubmit}
//               >
//                 <h3>
//                   <span className="flaticon-house-key"></span> Register
//                 </h3>
//                 <p className="mb-5">Join our community today:</p>

//                 <div className="row">
//                   <div className="col-sm-6">
//                     <div className="form-group">
//                       <select
//                         name="pts"
//                         className="payment-time-selection"
//                         class="form-select"
//                         onChange={(e) =>
//                           setState({ ...state, role: e.target.value })
//                         }
//                       >
//                         <option value="select">select</option>
//                         <option value="donor">Donor</option>
//                         <option value="organization">Organization</option>
//                         <option value="individual">Individual</option>
//                       </select>
//                     </div>
//                   </div>
//                   <div className="col-sm-6">
//                     <div className="form-group">
//                       <input
//                         type="text"
//                         className="form-control"
//                         id="exampleInputNamexa"
//                         placeholder="User Name"
//                         onChange={(e) =>
//                           setState({ ...state, userName: e.target.value })
//                         }
//                       />
//                     </div>
//                   </div>
//                   <div className="col-sm-6">
//                     <div className="form-group">
//                       <input
//                         type="text"
//                         className="form-control"
//                         id="exampleInputNamexb"
//                         placeholder=" Name"
//                         onChange={(e) =>
//                         setState({ ...state, name: e.target.value })
//                         }
//                       />
//                     </div>
//                   </div>
//                   <div className="col-sm-6">
//                     <div className="form-group">
//                       <input
//                         type="email"
//                         className="form-control"
//                         id="exampleInputEmailx"
//                         placeholder="Email"
//                         onChange={(e) =>
//                           setState({ ...state, email: e.target.value })
//                         }
//                       />
//                     </div>
//                   </div>
//                   <div className="col-sm-6">
//                     <div className="form-group">
//                       <input
//                         type="password"
//                         className="form-control"
//                         placeholder="Password"
//                         onChange={(e) =>
//                           setState({ ...state, password: e.target.value })
//                         }
//                       />
//                     </div>
//                   </div>
//                   <div className="col-sm-6">
//                     <div className="form-group">
//                       <input
//                         type="number"
//                         className="form-control"
//                         placeholder="mob number"
//                         onChange={(e) =>
//                           setState({ ...state, mobile: e.target.value })
//                         }
//                       />
//                     </div>
//                   </div>
//                 </div>

//                 {state.role == "organization" && (
//                   <div className="row">
//                     <div className="col-sm-6">
//                       <div className="form-group">
//                         <input
//                           type="text"
//                           className="form-control"
//                           placeholder="about"
//                           onChange={(e) =>
//                             setState({ ...state, about: e.target.value })
//                           }
//                         />
//                       </div>
//                     </div>
//                     <div className="col-sm-6">
//                       <div className="form-group">
//                         <input
//                           type="text"
//                           className="form-control"
//                           placeholder="mission"
//                           onChange={(e) =>
//                             setState({ ...state, mission: e.target.value })
//                           }
//                         />
//                       </div>
//                     </div>
//                     <div className="col-sm-6">
//                       <div className="form-group">
//                         <input
//                           type="text"
//                           className="form-control"
//                           placeholder="serviceArea"
//                           onChange={(e) =>
//                             setState({
//                               ...state,
//                               serviceArea: e.target.value,
//                             })
//                           }
//                         />
//                       </div>
//                     </div>
//                     <div className="col-sm-6">
//                       <div className="form-group">
//                         <input
//                           type="text"
//                           className="form-control"
//                           placeholder=" address1"
//                           onChange={(e) =>
//                             setState({ ...state, address1: e.target.value })
//                           }
//                         />
//                       </div>
//                     </div>
//                     <div className="col-sm-6">
//                       <div className="form-group">
//                         <input
//                           type="text"
//                           className="form-control"
//                           placeholder="address2:"
//                           onChange={(e) =>
//                             setState({ ...state, address2: e.target.value })
//                           }
//                         />
//                       </div>
//                     </div>
//                     <div className="col-sm-6">
//                       <div className="form-group">
//                         <input
//                           type="text"
//                           className="form-control"
//                           placeholder="state"
//                           onChange={(e) =>
//                             setState({ ...state, state: e.target.value })
//                           }
//                         />
//                       </div>
//                     </div>

//                     <div className="col-sm-6">
//                       <div className="form-group">
//                         <input
//                           type="text"
//                           className="form-control"
//                           placeholder="city"
//                           onChange={(e) =>
//                             setState({ ...state, city: e.target.value })
//                           }
//                         />
//                       </div>
//                     </div>
//                     <div className="col-sm-6">
//                       <div className="form-group">
//                         <input
//                           type="text"
//                           className="form-control"
//                           placeholder="country"
//                           onChange={(e) =>
//                             setState({ ...state, country: e.target.value })
//                           }
//                         />
//                       </div>
//                     </div>
//                     <div className="col-sm-6">
//                       <div className="form-group">
//                         <input
//                           type="text"
//                           className="form-control"
//                           placeholder="pincode"
//                           onChange={(e) =>
//                             setState({ ...state, pincode: e.target.value })
//                           }
//                         />
//                       </div>
//                     </div>
//                   </div>
//                 )}

//                 <div className="form-group text-center">
//                   <button
//                     type="submit"
//                     className="btn btn-default ulockd-btn-thm2"
//                   >
//                     Sign Me Up
//                   </button>
//                 </div>
//               </form>
//             </div>
//           </div>
//         </div>
//       </section>
//     </>
//   );
// };

// export default Register;
