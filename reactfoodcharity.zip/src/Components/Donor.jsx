import React, { useEffect } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const validationSchema = Yup.object().shape({
  food: Yup.array().of(
    Yup.object().shape({
      food_name: Yup.string().required("Food name is required"),
      quantity: Yup.number()
        .required("Quantity is required")
        .positive("Quantity must be positive"),
      unit: Yup.string().required("Unit is required"),
    })
  ),
  expirationDate: Yup.string().required("Expiration date is required"),
  pickupAvailability: Yup.string().required("Pickup availability is required"),
  address1: Yup.string().required("Address 1 is required"),
  address2: Yup.string().required("Address 2 is required"),
  state: Yup.string().required("State is required"),
  pincode: Yup.string().required("Pincode is required"),
  country: Yup.string().required("country is required"),
  country: Yup.string().required("country is required"),

  // Add validations for other fields
});

const Donor = () => {
  const navigate = useNavigate();

  const formik = useFormik({
    initialValues: {
      food: [
        {
          food_name: "",
          quantity: 0,
          unit: "",
        },
      ],
      expirationDate: "",
      pickupAvailability: "",
      address1: "",
      address2: "",
      state: "",
      city: "",
      country: "",
      pincode: "",
      latitude: "",
      longitude: "",
    },
    onSubmit: async (values) => {
      try {
        const tokens = localStorage.getItem("token");
        const response = await axios.post(
          "http://192.168.0.23:4000/api/foods",
          values,
          {
            headers: {
              Authorization: `${tokens}`,
            },
          }
        );
        toast.success("Add item successful");
        console.log(response);

        navigate("/");
      } catch (error) {
        toast.error(`Registration failed: ${error.response.data.message.city}`);

        console.error(error);
      }
    },
    validationSchema: validationSchema,
  });

  const getCurrentLocation = () => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        formik.setFieldValue("latitude", position.coords.latitude.toString());
        formik.setFieldValue("longitude", position.coords.longitude.toString());
      },
      (error) => {
        console.error("Error getting location:", error);
      }
    );
  };

  useEffect(() => {
    getCurrentLocation();
  }, []);















  return (
    <div>
      <section className="register-form">
        {/* Your existing JSX code */}
        <form
          className="ulockd-reg-form text-center"
          onSubmit={formik.handleSubmit}
        >
          {/* Your form inputs and buttons */}
          {formik.values.food.map((item, index) => (
            <div key={index}>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Food Name"
                  name={`food[${index}].food_name`}
                  value={formik.values.food[index].food_name}
                  onChange={formik.handleChange}
                />
                {formik.touched.food &&
                  formik.errors.food &&
                  formik.errors.food[index] && (
                    <div className="error-message">
                      {formik.errors.food[index].food_name}
                    </div>
                  )}
              </div>
              <div className="form-group">
                <input
                  type="number"
                  className="form-control"
                  placeholder="Quantity"
                  name={`food[${index}].quantity`}
                  value={formik.values.food[index].quantity}
                  onChange={formik.handleChange}
                />
                {formik.touched.food &&
                  formik.errors.food &&
                  formik.errors.food[index] && (
                    <div className="error-message">
                      {formik.errors.food[index].quantity}
                    </div>
                  )}
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Unit"
                  name={`food[${index}].unit`}
                  value={formik.values.food[index].unit}
                  onChange={formik.handleChange}
                />
                {formik.touched.food &&
                  formik.errors.food &&
                  formik.errors.food[index] && (
                    <div className="error-message">
                      {formik.errors.food[index].unit}
                    </div>
                  )}
              </div>
              <button
                type="button"
                onClick={() => formik.arrayHelpers.remove(index)}
              >
                Remove Food
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={() =>
              formik.arrayHelpers.push({ food_name: "", quantity: 0, unit: "" })
            }
          >
            Add Food
          </button>
          {/* Other form inputs */}
          <div className="form-group">
            <input
              type="text"
              className="form-control"
              placeholder="Expiration Date"
              name="expirationDate"
              value={formik.values.expirationDate}
              onChange={formik.handleChange}
            />
            {formik.touched.expirationDate && formik.errors.expirationDate && (
              <div className="error-message">
                {formik.errors.expirationDate}
              </div>
            )}
          </div>
          <div className="form-group">
            <input
              type="text"
              name="pickupAvailability"
              className="form-control"
              placeholder="PickupAvailability"
              value={formik.values.pickupAvailability}
              onChange={formik.handleChange}
            />
            {formik.touched.pickupAvailability &&
              formik.errors.pickupAvailability && (
                <div className="error-message">
                  {formik.errors.pickupAvailability}
                </div>
              )}
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control"
              placeholder=" Address1"
              name="address1"
              value={formik.values.address1}
              onChange={formik.handleChange}
            />
            {formik.touched.address1 && formik.errors.address1 && (
              <div className="error-message">{formik.errors.address1}</div>
            )}
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control"
              placeholder=" Address2"
              name="address2"
              value={formik.values.address2}
              onChange={formik.handleChange}
            />
            {formik.touched.address2 && formik.errors.address2 && (
              <div className="error-message">{formik.errors.address2}</div>
            )}
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control"
              placeholder=" State"
              name="state"
              value={formik.values.state}
              onChange={formik.handleChange}
            />
            {formik.touched.state && formik.errors.state && (
              <div className="error-message">{formik.errors.state}</div>
            )}
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control"
              placeholder="City"
              name="city"
              value={formik.values.city}
              onChange={formik.handleChange}
            />
            {formik.touched.city && formik.errors.city && (
              <div className="error-message">{formik.errors.city}</div>
            )}
          </div>

          <div className="form-group">
            <input
              type="text"
              className="form-control"
              placeholder=" Country"
              name="country"
              value={formik.values.country}
              onChange={formik.handleChange}
            />
            {formik.touched.country && formik.errors.country && (
              <div className="error-message">{formik.errors.country}</div>
            )}
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control"
              placeholder="pincode"
              name="pincode"
              value={formik.values.pincode}
              onChange={formik.handleChange}
            />
            {formik.touched.pincode && formik.errors.pincode && (
              <div className="error-message">{formik.errors.pincode}</div>
            )}
          </div>

          <div className="form-group">
            <input
              type="text"
              className="form-control"
              placeholder="Latitude"
              name="latitude"
              value={formik.values.latitude}
              onChange={formik.handleChange}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control"
              placeholder="Longitude}"
              name="longitude}"
              value={formik.values.longitude}
              onChange={formik.handleChange}
            />
          </div>

          {/* Submit button */}
          <div className="form-group text-center">
            <button type="submit" className="btn btn-default ulockd-btn-thm2">
              Submit
            </button>
          </div>
        </form>
      </section>
    </div>
  );
};

export default Donor;

// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import { useNavigate } from "react-router-dom";
// import { toast } from "react-toastify";

// const Donor = () => {
//   const navigate = useNavigate();
//   const [food, setFood] = useState({
//     food: [
//       {
//         food_name: "",
//         quantity: 0,
//         unit: "",
//       },
//     ],
//     expirationDate: "",
//     pickupAvailability: "",
//     address1: "",
//     address2: "",
//     state: "",
//     city: "",
//     country: "",
//     pincode: "",
//     latitude: "",
//     longitude: "",
//   });

//   const handleFoodChange = (index, key, value) => {
//     const updatedFood = [...food.food];
//     updatedFood[index][key] = value;
//     setFood({ ...food, food: updatedFood });
//   };

//   const handleFoodAdd = () => {
//     setFood({
//       ...food,
//       food: [
//         ...food.food,
//         {
//           food_name: "",
//           quantity: 0,
//           unit: "",
//         },
//       ],
//     });
//   };

//   const handleFoodRemove = (index) => {
//     const updatedFood = [...food.food];
//     updatedFood.splice(index, 1);
//     setFood({ ...food, food: updatedFood });
//   };

//   const getCurrentLocation = () => {
//     navigator.geolocation.getCurrentPosition(
//       (position) => {
//         setFood({
//           ...food,
//           latitude: position.coords.latitude.toString(),
//           longitude: position.coords.longitude.toString(),
//         });
//       },
//       (error) => {
//         console.error("Error getting location:", error);
//       }
//     );
//   };

//   useEffect(() => {
//     getCurrentLocation();
//   }, []); // Empty dependency array to run the effect only once

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     let tokens;

//     try {
//       tokens = localStorage.getItem("token");
//       const response = await axios.post(
//         "http://192.168.0.23:4000/api/foods",
//         food,
//         {
//           headers: {
//             Authorization: `${tokens}`,
//           },
//         }
//       );
//       toast.success("Add item successful");
//       console.log('7878',response);

//       navigate("/");

//     } catch (error) {
//       console.log(error);
//     }
//   };
//   return (
//     <div>
//       <section className="register-form">
//         <div className="container">
//           <div className="row justify-content-center mx-0">
//             <div className="col-sm-12 col-lg-6 hvr-float-shadow">
//               <form
//                 className="ulockd-reg-form text-center"
//                 onSubmit={handleSubmit}
//               >
//                 <h3>
//                   <span className="flaticon-house-key"></span> Food
//                 </h3>

//                 {food.food.map((item, index) => (
//                   <div key={index}>
//                     <div className="form-group">
//                       <input
//                         type="text"
//                         className="form-control"
//                         placeholder="Food Name"
//                         value={item.food_name}
//                         onChange={(e) =>
//                           handleFoodChange(index, "food_name", e.target.value)
//                         }
//                       />
//                     </div>
//                     <div className="form-group">
//                       <input
//                         type="number"
//                         className="form-control"
//                         placeholder="Quantity"
//                         value={item.quantity}
//                         onChange={(e) =>
//                           handleFoodChange(index, "quantity", e.target.value)
//                         }
//                       />
//                     </div>
//                     <div className="form-group">
//                       <input
//                         type="text"
//                         className="form-control"
//                         placeholder="Unit"
//                         value={item.unit}
//                         onChange={(e) =>
//                           handleFoodChange(index, "unit", e.target.value)
//                         }
//                       />
//                     </div>
//                     <button
//                       type="button"
//                       onClick={() => handleFoodRemove(index)}
//                     >
//                       Remove Food
//                     </button>
//                   </div>
//                 ))}

//                 <button type="button" onClick={handleFoodAdd}>
//                   Add Food
//                 </button>
//                 <p>Add Food </p>

//                 <div className="form-group">
//                   <input
//                     type="text"
//                     className="form-control"
//                     placeholder="expirationDate"
//                     onChange={(e) =>
//                       setFood({ ...food, expirationDate: e.target.value })
//                     }
//                   />
//                 </div>
//                 <div className="form-group">
//                   <input
//                     type="text"
//                     className="form-control"
//                     placeholder="pickupAvailability"
//                     onChange={(e) =>
//                       setFood({ ...food, pickupAvailability: e.target.value })
//                     }
//                   />
//                 </div>
//                 <div className="form-group">
//                   <input
//                     type="text"
//                     className="form-control"
//                     placeholder=" address1"
//                     onChange={(e) =>
//                       setFood({ ...food, address1: e.target.value })
//                     }
//                   />
//                 </div>
//                 <div className="form-group">
//                   <input
//                     type="text"
//                     className="form-control"
//                     placeholder=" address2"
//                     onChange={(e) =>
//                       setFood({ ...food, address2: e.target.value })
//                     }
//                   />
//                 </div>
//                 <div className="form-group">
//                   <input
//                     type="text"
//                     className="form-control"
//                     placeholder="state"
//                     onChange={(e) =>
//                       setFood({ ...food, state: e.target.value })
//                     }
//                   />
//                 </div>
//                 <div className="form-group">
//                   <input
//                     type="text"
//                     className="form-control"
//                     placeholder="  state"
//                     onChange={(e) => setFood({ ...food, city: e.target.value })}
//                   />
//                 </div>
//                 <div className="form-group">
//                   <input
//                     type="text"
//                     className="form-control"
//                     placeholder="  country"
//                     onChange={(e) =>
//                       setFood({ ...food, country: e.target.value })
//                     }
//                   />
//                 </div>
//                 <div className="form-group">
//                   <input
//                     type="text"
//                     className="form-control"
//                     placeholder="  pincode"
//                     onChange={(e) =>
//                       setFood({ ...food, pincode: e.target.value })
//                     }
//                   />
//                 </div>
//                 {/* <div className="form-group">
//                   <input
//                     type="text"
//                     className="form-control"
//                     placeholder="  latitude"
//                     onChange={(e) =>
//                       setFood({ ...food, latitude: e.target.value })
//                     }
//                   />
//                 </div>
//                 <div className="form-group">
//                   <input
//                     type="text"
//                     className="form-control"
//                     placeholder="  longitude"
//                     onChange={(e) =>
//                       setFood({ ...food, longitude: e.target.value })
//                     }
//                   />
//                 </div> */}
//                 <div className="form-group">
//                   <input
//                     type="text"
//                     className="form-control"
//                     placeholder="Latitude"
//                     value={food.latitude}
//                     readOnly
//                     onChange={(e) =>
//                       setFood({ ...food, latitude: e.target.value })
//                     }
//                   />
//                 </div>
//                 <div className="form-group">
//                   <input
//                     type="text"
//                     className="form-control"
//                     placeholder="Longitude"
//                     value={food.longitude}
//                     readOnly
//                     onChange={(e) =>
//                       setFood({ ...food, longitude: e.target.value })
//                     }
//                   />
//                 </div>
//                 <div className="form-group text-center">
//                   <button type="submit" className="btn btn-default ulockd-btn-thm2">
//                     Submit
//                   </button>
//                 </div>
//               </form>
//             </div>
//           </div>
//         </div>
//       </section>
//     </div>
//   );
// };

// export default Donor;
