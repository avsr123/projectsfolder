import React, { useState, useEffect } from "react";
import axios from "axios";
import Donor from './Donor'
import { Link } from "react-router-dom";



const Home = () => {
  const [foods, setFoods] = useState([]);
  const role = localStorage.getItem("role");

  const [requestQuantities, setRequestQuantities] = useState({});

  const handleQuantityChange = (foodItemId, quantity) => {
    setRequestQuantities((prevQuantities) => ({
      ...prevQuantities,
      [foodItemId]: quantity,
    }));
  };

  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem("token");

      try {
        const response = await axios.get("http://192.168.0.23:4000/api/foods", {
          headers: {
            Authorization: `${token}`,
          },
        });
        setFoods(response.data.data);
        console.log("response.data.data", response.data.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);
  const sendRequest = async (food) => {
    const token = localStorage.getItem("token");

    try {
      const response = await axios.post(
        "http://192.168.0.23:4000/api/requests",
        {
          items: food.food.map((foodItem) => ({
            itemID: foodItem._id,
            quantity: requestQuantities[foodItem._id] || foodItem.quantity,
            unit: foodItem.unit,
          })),
          foodID: food._id,
          donorID: food.donorID,
          locationID: food.location._id,
        },
        {
          headers: {
            Authorization: `${token}`,
          },
        }
      );

      console.log("Request sent successfully:", response.data);
    } catch (error) {
      console.error("Error sending request:", error);
    }
  };


 
  return (
    <div>
      <h1>Foods List</h1>
    
      <div className="row mx-0">
      
        {foods &&
          foods.map((food, index) => (
            <div className="col-sm-3" key={index}>
              <ul>
                <li>
                  <b> Expiration Date:</b> {food.expirationDate}
                </li>
                <li>
                  <b>donorID:</b> {food.donorID}
                </li>
                <li>
                  <b>Food_ID:</b> {food._id}
                </li>
                <li>
                  <b>location_id:</b> {food.location._id}
                </li>
                <li>
                  <b>Pickup Availability:</b> {food.pickupAvailability}
                </li>
                <li>
                  <b>address1:</b> {food.location.address1}
                </li>
                <li>
                  <b>address2:</b> {food.location.address2},
                </li>
                <li>
                  <b>city:</b> {food.location.city},
                </li>
                <li>
                  <b>state:</b> {food.location.state}
                </li>
                <li>
                  <b>pincode:</b> {food.location.pincode}
                </li>
                {food.food.map((foodItem, foodIndex) => (
                  <>
                    <hr />
                    <li key={foodIndex}>
                      <b> food_name: </b> {foodItem.food_name}
                    </li>
                    <li>
                      <b> quantity: </b> {foodItem.quantity}
                    </li>

                    <li>
                      <b> quantity: </b>{" "}
                      <input
                        type="number"
                        value={requestQuantities[foodItem._id] || ""}
                        onChange={(e) =>
                          handleQuantityChange(foodItem._id, e.target.value)
                        }
                      />
                    </li>

                    <li>
                      <b> unit: </b> {foodItem.unit}
                    </li>
                    <li>
                      <b> Items_id: </b> {foodItem._id}
                    </li>
                  </>
                ))}
              </ul>
              {role === "donor" ? null : (
                <button
                  className="btn btn-warning"
                  onClick={() => sendRequest(food)}
                >
                  Send Request
                </button>
              )}
            </div>
          ))}
      </div>
    </div>
  );
};

export default Home;










// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import { Link } from "react-router-dom";
// import addNotification from "";



// const Home = () => {
//   const [foods, setFoods] = useState([]);
//   const role = localStorage.getItem("role");

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const token = localStorage.getItem("token");
//         const response = await axios.get("http://192.168.0.23:4000/api/foods", {
//           headers: {
//             Authorization: `${token}`,
//           },
//         });
//         console.log('12',response)
//         setFoods(response.data.data);
//         console.log(response.data.data);
//       } catch (error) {
//         console.error("Error fetching data:", error);
//       }
//     };

//     fetchData();
//   }, []);



// useEffect(()=>{
//   if(foods.length <1){
//     addNotification({
//             message: "you have Food request",
//              title: "Warning",
//              subtitle: "This is a subtitle",
//               duration: 100000, 
//              closeButton: 'Go away',
//              vibrate: 2 ,
//              silent: false,
//              theme: "darkblue",
//            native: true,
//            });

//   }
// },[])


// const sendRequest = async (foodID, donorID, locationID) => {
//     try {
//       const token = localStorage.getItem("token");
//       const response = await axios.post(
//         "http://192.168.0.23:4000/api/requests",
//         {
//           foodID,
//           donorID,
//           locationID,
//         },
//         {
//           headers: {
//             Authorization: `${token}`,
//           },
//         }
//       );

//       // Handle the response as needed

//       console.log('3434',response)
//       console.log("Request sent successfully:", response.data);
//     } catch (error) {
//       console.error("Error sending request:", error);
//     }
//   };

// return (
//     <div className="px-3 my-5">
//       <div className="d-flex align-items-center justify-content-between">
//         <h1>Food List</h1>
//         <Link to={"/donar"} className="btn btn-warning">
//           Add Food
//         </Link>
//       </div>
//       <div className="my-4 text-end">
//         {role !== "donor" ? (
//           <Link to={"/response"} className="btn btn-success">
//             Check reponse
//           </Link>
//         ) : (
//           <Link to={"/request"} className="btn btn-success">
//             Check Request
//           </Link>
//         )}
//       </div>
//       <div className="row mx-0">
//         {foods &&
//           foods.map((food, index) => (
//             <div className="mb-5 col-sm-3 hvr-float-shadow" key={index}>
//               <div className="ulockd-reg-form">
//                 <p>
//                   <b> Expiration Date:</b> {food.expirationDate}
//                 </p>
//                 <p>
//                   <b>donorID:</b> {food.donorID}
//                 </p>
//                 <p>
//                   <b>Food_ID:</b> {food._id}
//                 </p>
//                 <p>
//                   <b>location_id:</b> {food.location._id}
//                 </p>
//                 <p>
//                   <b>Pickup Availability:</b> {food.pickupAvailability}
//                 </p>
//                 <p>
//                   <b>address1:</b> {food.location.address1}
//                 </p>
//                 <p>
//                   <b>address2:</b> {food.location.address2},
//                 </p>
//                 <p>
//                   <b>city:</b> {food.location.city},
//                 </p>
//                 <p>
//                   <b>state:</b> {food.location.state}
//                 </p>
//                 <p>
//                   <b>pincode:</b> {food.location.pincode}
//                 </p>

//                 {food.food.map((foodItem, foodIndex) => (
//                   <p key={foodIndex}>
//                     {" "}
//                     <b> Food: </b> {foodItem.food_name}
//                   </p>
//                 ))}
//                 <button
//                   className="btn btn-warning"
//                   onClick={() =>
//                     sendRequest(food._id, food.donorID, food.location._id)
//                   }
//                   disabled={role === "donor"} // Disable the button for donors
//                 >
//                   Send Request
//                 </button>
//               </div>
//             </div>
//           ))}
//       </div>
//     </div>
//   );
// };

// export default Home;

















// import React, { useEffect } from "react";
// import addNotification from "react-push-notification";
// import { Navigate } from "react-router-dom";
// import { toast } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";

// const Tt = () => {
//   const buttonClick = () => {
//     addNotification({
//       message: "This is a very long message",
//       onClick: () => Navigate('fsfsd'),
//       title: "Warning",
//       subtitle: "This is a subtitle",
//        duration: 100000, 
//       closeButton: 'Go away',
//       vibrate: 2 ,
//       silent: false,
//       theme: "darkblue",
//       native: true,
//     });
//   };

//   return (
//     <div>
//       <button onClick={buttonClick} className="button">
//         Hello world.
//       </button>
//     </div>
//   );
// };

// export default Tt;
