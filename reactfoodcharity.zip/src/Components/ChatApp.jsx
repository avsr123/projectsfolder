import axios from "axios";
import React, { useState, useEffect } from "react";
import io from "socket.io-client";
import { useParams, useLocation } from "react-router-dom";

const socket = io("http://192.168.0.23:4000", {
  autoConnect: true,
});

const ChatApp = () => {
  const [personalMessage, setPersonalMessage] = useState("");
  const [messages, setMessages] = useState([]);
  const [me, setMe] = useState("");
  const { roomId } = useParams();
  console.log("roomId", roomId);
  const token = localStorage.getItem("token");
  const location = useLocation();
  const receiverID = location.state?.receiverID || null;
  console.log("receiverID", receiverID);

  useEffect(() => {
    axios
      .get("http://192.168.0.23:4000/api/me", {
        headers: {
          "Content-Type": "application/json",
          Authorization: `${token}`,
        },
      })
      .then((response) => {
        setMe(response.data);
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }, [token]);

  useEffect(() => {
    socket.emit("join-room", roomId);

    socket.on("message recieved", (message) => {
      setMessages([...messages, message]);
    });

    return () => {
      socket.emit("leave-room", roomId);
      socket.off("personal-message");
    };
  }, [roomId, messages]);

  const sendPersonalMessage = () => {
    const message = {
      senderName: me.name,
      senderID: me._id,
      receiverId: receiverID,
      message: personalMessage,
    };

    console.log("message", message);

    socket.emit("personal-message", roomId, message);

    setPersonalMessage("");
  };

  return (
    <div className="container">
      <div className="chat-container">
        <div className="user-info">
          <h3>Name: {me?.name}</h3>
        </div>
        <div className="chat-output">
          {messages.map((message, index) => (
            <div
              key={index}
              className={
                message.senderID === me._id ? "message-left" : "message-right"
              }
            >
              <p>{message.message}</p>
            </div>
          ))}
        </div>
        <div className="chat-input">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendPersonalMessage();
            }}
          >
            <input
              type="text"
              value={personalMessage}
              onChange={(e) => setPersonalMessage(e.target.value)}
              placeholder="Type your message..."
            />
            <button type="submit">Send</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ChatApp;
