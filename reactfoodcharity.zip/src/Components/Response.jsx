import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const Response = () => {
  const [foods, setFoods] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get(
          "http://192.168.0.23:4000/api/send/requests",
          {
            headers: {
              Authorization: `${token}`,
            },
          }
        );
        setFoods(response.data.data);
        console.log("Fetched Data:", response.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const handleChatButtonClick = (roomId, receiverID) => {
    // Navigate to the chat page with the roomId and receiverID as parameters
    navigate(`/chatApp/${roomId}`, { state: { receiverID } });
  };
  return (
    <div className="row">
      {" "}
      {foods.map((item) => (
        <div key={item._id} className="col-sm-3 col-sm-3 hvr-float-shadow">
          <div className="ulockd-reg-form ">
            <strong>Status:</strong>{" "}
            <span className="badge-success"> {item.status} </span> <br />
            <strong>Request ID:</strong> {item._id} <br />
            <strong>Room ID:</strong> {item?.roomId} <br />
            <strong>Donor ID:</strong> {item.donorID} <br />
            <strong>Receiver ID:</strong> {item.receiverID} <br />
            {/* <strong>Food Details:</strong> {item?.foodID?.food[0]?.food_name} -{" "}
            {item?.foodID?.food[0].quantity} {item?.foodID?.food[0]?.unit}{" "}
            <br /> */}
            <strong>Location Details:</strong> {item?.locationID?.address1},{" "}
            {item?.locationID?.city}, {item?.locationID?.state} <br />
            <strong>Status:</strong> {item.status} <br />
            <strong>Created At:</strong> {item.createdAt} <br />
            <strong>Updated At:</strong> {item.updatedAt} <br />
            {/* <strong>Receiver Name:</strong> {item.receiverDetail.name} <br /> */}
            <hr />
            {item?.status === "accept" ? (
         
              <button
                className="btn btn-success"
                onClick={() =>
                  handleChatButtonClick(item?.roomId, item.receiverID)
                }
              >
                Chat
              </button>
            ) : (
              <button className="btn btn-success" disabled>
                Start Chat
              </button>
            )}
        
          </div>
        </div>
      ))}
    </div>
  );
};

export default Response;
