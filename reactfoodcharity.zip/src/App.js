import React from "react";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import Header from "./Components/Header";
import Home from "./Components/Home";
import Login from "./Components/Login";
import Register from "./Components/Register";
import Donor from "./Components/Donor";
import Request from "./Components/Request";
import Response from "./Components/Response";
import ChatApp from "./Components/ChatApp";
import "./App.css";
import ForgetPassword from "./Components/ForgetPassword";
import OrgForgetpassword from "./Components/OrgForgetpassword";
import Resetpassword from "./Components/Resetpassword";
import OrgRestpassword from "./Components/OrgRestpassword";
import Review from "./Components/Review";
import Maps from "./Components/Maps";


function App() {
  const role = localStorage.getItem("role");
  const isAuthenticated = !!role; // Check if the user is authenticated

  return (
    <>
      <ToastContainer />
      <BrowserRouter>
        {isAuthenticated && <Header />} {/* Conditionally render Header */}
        <Routes>
          {isAuthenticated ? (
            <>
              <Route path="/home" element={<Home />} />
              <Route path="/donar" element={<Donor />} />
              <Route path="/review" element= {<Review/>}/>
              <Route path="/request" element={<Request />} />
              <Route path="/response" element={<Response />} />
              <Route path="/maps" element={<Maps />} />

              <Route
                path="/chatApp/:roomId"
                element={<ChatApp role={role} />}
              />
              <Route path="/*" element={<Navigate to="/home" />} />
            </>
          ) : (
            <>
              <Route path="/" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/forgetPassword" element={<ForgetPassword />} />
              <Route
                path="/orgForgetPassword"
                element={<OrgForgetpassword/>}
              />
              <Route path="/reset-password" element={<Resetpassword/>}/>
             
                 <Route exact path="/organizations/reset-password" element={<OrgRestpassword/>}></Route>

              {/* <Route path="/*" element={<Navigate to="/" />} /> */}
            </>
          )}
        </Routes>
      </BrowserRouter>
    </>
   
  );
}

export default App;
